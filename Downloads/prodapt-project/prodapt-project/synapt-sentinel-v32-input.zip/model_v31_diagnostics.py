"""V3.1: label-level cross-capture failure analysis; no production artifact writes."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from model_pipeline import FEATURE_COLUMNS, load_sample
from model_v3_experiment import threshold_at_fpr, anomaly_percentile, metrics


def label_breakdown(labels, scores, cut, train_labels):
    labels = np.asarray(labels, dtype=str)
    scores = np.asarray(scores, dtype=float)
    output = {}
    for label in sorted(set(labels)):
        mask = labels == label
        vals = scores[mask]
        detected = int(np.count_nonzero(vals >= cut))
        output[label] = {
            'rows': int(mask.sum()), 'flagged': detected,
            'flag_rate': detected / len(vals),
            'score_p10': float(np.percentile(vals, 10)),
            'score_median': float(np.median(vals)),
            'score_p90': float(np.percentile(vals, 90)),
            'unseen_in_training': label != 'BENIGN' and label not in train_labels,
        }
    return output


def run(paths, output, per_class=3000, benign_cap=5000, trees=60, seed=42, fpr_budget=.05):
    paths = [Path(p) for p in paths]
    if len(paths) < 3 or len({p.name for p in paths}) != len(paths):
        raise ValueError('Provide at least three uniquely named capture files')
    if not 0 < fpr_budget < 1 or min(per_class, benign_cap, trees) < 1:
        raise ValueError('Invalid sampling, tree count, or FPR budget')
    captures = []
    for held in paths:
        train, _ = load_sample([p for p in paths if p != held], per_class, benign_cap, seed=seed)
        test, _ = load_sample([held], per_class, benign_cap, seed=seed+1)
        conflicts = train.groupby('__key__')['__label__'].nunique()
        train = train.loc[~train['__key__'].isin(conflicts[conflicts > 1].index)].drop_duplicates('__key__').copy()
        seen = set(train['__key__'])
        overlap = int(test['__key__'].isin(seen).sum())
        test = test.loc[~test['__key__'].isin(seen)].drop_duplicates('__key__').copy()
        y = (train['__label__'] != 'BENIGN').astype(int)
        yt = (test['__label__'] != 'BENIGN').astype(int)
        entry = {'held_out_capture': held.name, 'removed_overlap': overlap,
                 'train_rows': len(train), 'test_rows': len(test)}
        if not len(test) or y.nunique() < 2 or y.value_counts().min() < 8:
            entry['status'] = 'insufficient_data'
            captures.append(entry)
            continue
        fit, val = train_test_split(np.arange(len(train)), test_size=.25, stratify=y, random_state=seed)
        x, xt = train[FEATURE_COLUMNS], test[FEATURE_COLUMNS]
        supervised = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('model', ExtraTreesClassifier(n_estimators=trees, min_samples_leaf=2,
                                           class_weight='balanced', random_state=seed, n_jobs=-1))])
        supervised.fit(x.iloc[fit], y.iloc[fit])
        sv = supervised.predict_proba(x.iloc[val])[:, 1]
        st = supervised.predict_proba(xt)[:, 1]
        vy = y.iloc[val].to_numpy()
        scut = threshold_at_fpr(sv[vy == 0], fpr_budget)
        benign_fit = x.iloc[fit][y.iloc[fit] == 0]
        imputer = SimpleImputer(strategy='median')
        bx = imputer.fit_transform(benign_fit)
        anomaly = IsolationForest(n_estimators=100, contamination='auto', random_state=seed, n_jobs=-1)
        anomaly.fit(bx)
        av_raw = -anomaly.decision_function(imputer.transform(x.iloc[val]))
        at_raw = -anomaly.decision_function(imputer.transform(xt))
        ref = av_raw[vy == 0]
        av = anomaly_percentile(av_raw, ref)
        at = anomaly_percentile(at_raw, ref)
        acut = threshold_at_fpr(av[vy == 0], fpr_budget)
        # Diagnostic OR rule; not tuned on test, and may violate FPR budget.
        or_predictions = (st >= scut) | (at >= acut)
        labels = test['__label__'].astype(str).to_numpy()
        train_attack_labels = set(train.loc[y == 1, '__label__'].astype(str))
        missed_supervised = (yt.to_numpy() == 1) & (st < scut)
        rescued = missed_supervised & (at >= acut)
        entry.update({
            'status': 'evaluated', 'unseen_attack_labels': sorted(set(labels) - train_attack_labels - {'BENIGN'}),
            'supervised': metrics(yt, st, scut), 'anomaly': metrics(yt, at, acut),
            'or_rule': metrics(yt, or_predictions.astype(float), .5),
            'rescued_missed_attacks_by_anomaly': int(rescued.sum()),
            'supervised_by_label': label_breakdown(labels, st, scut, train_attack_labels),
            'anomaly_by_label': label_breakdown(labels, at, acut, train_attack_labels),
            'or_by_label': label_breakdown(labels, or_predictions.astype(float), .5, train_attack_labels),
            'validation_thresholds': {'supervised': float(scut), 'anomaly': float(acut)},
        })
        captures.append(entry)
        print(f'{held.name}: supervised={entry["supervised"]["recall"]}, anomaly={entry["anomaly"]["recall"]}, OR={entry["or_rule"]["recall"]}, OR_FPR={entry["or_rule"]["fpr"]}', flush=True)
    report = {'methodology': 'Leave-one-capture-out, sampled, exact-feature duplicate exclusion',
              'notes': ['OR rule is diagnostic, not a deployable 5% FPR operating point',
                        'Thresholds selected on training-side validation benign flows only',
                        'Held-out capture is never used to select thresholds',
                        'Training-side validation may share capture artifacts with training',
                        'Sampling changes attack prevalence and rare attack estimates are unstable',
                        'Benign-only IsolationForest is not a guaranteed unknown-attack detector'],
              'settings': {'per_class': per_class, 'benign_cap': benign_cap, 'trees': trees,
                           'seed': seed, 'fpr_budget': fpr_budget}, 'captures': captures}
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', nargs='+', required=True, type=Path)
    parser.add_argument('--output', default=str(Path(__file__).resolve().parent / 'artifacts' / 'model_v31_diagnostics' / 'evaluation.json'))
    parser.add_argument('--per-class', type=int, default=3000)
    parser.add_argument('--benign-cap', type=int, default=5000)
    parser.add_argument('--trees', type=int, default=60)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--fpr-budget', type=float, default=.05)
    args = parser.parse_args()
    run(args.csv, args.output, args.per_class, args.benign_cap, args.trees, args.seed, args.fpr_budget)
    print('Saved:', args.output)
