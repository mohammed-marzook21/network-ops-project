"""Experimental leave-one-capture-out intrusion detection. Never changes production artifacts.

Thresholds and fusion weights are selected exclusively on training-side validation data.
Scores and fixed-FPR budgets are evaluated on excluded capture files without retuning.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from model_pipeline import load_sample, FEATURE_COLUMNS


def metrics(y, score, threshold):
    y = np.asarray(y, dtype=int)
    score = np.asarray(score, dtype=float)
    tn, fp, fn, tp = map(int, confusion_matrix(y, score >= threshold, labels=[0, 1]).ravel())
    both = len(np.unique(y)) == 2
    return dict(rows=len(y), attacks=int(y.sum()), benign=int((y == 0).sum()),
                roc_auc=float(roc_auc_score(y, score)) if both else None,
                average_precision=float(average_precision_score(y, score)) if both else None,
                recall=tp / (tp + fn) if tp + fn else None,
                fpr=fp / (fp + tn) if fp + tn else None,
                tn=tn, fp=fp, fn=fn, tp=tp, threshold=float(threshold))


def threshold_at_fpr(benign_scores, budget):
    """Conservative empirical threshold; ties may make achieved FPR lower than budget."""
    s = np.asarray(benign_scores, dtype=float)
    if len(s) == 0 or not np.isfinite(s).all():
        raise ValueError('Finite benign validation scores are required')
    if not 0 <= budget < 1:
        raise ValueError('FPR budget must be in [0,1)')
    # Using a strict greater-than cutoff via nextafter ensures ties don't overshoot.
    k = int(np.floor(budget * len(s)))
    sorted_desc = np.sort(s)[::-1]
    if k == 0:
        return float(np.nextafter(sorted_desc[0], np.inf))
    return float(np.nextafter(sorted_desc[k], np.inf)) if k < len(s) else float(np.nextafter(sorted_desc[-1], -np.inf))


def anomaly_percentile(raw, reference):
    """Higher values indicate more anomalous traffic, using benign validation reference."""
    ref = np.sort(np.asarray(reference, dtype=float))
    return np.searchsorted(ref, np.asarray(raw, dtype=float), side='right') / len(ref)


def run(paths, output, per_class=3000, benign_cap=5000, trees=60, seed=42, fpr_budget=.05):
    paths = [Path(p) for p in paths]
    if len(paths) < 3 or len({p.name for p in paths}) != len(paths):
        raise ValueError('Provide at least 3 uniquely named capture files')
    if trees < 5 or per_class < 1 or benign_cap < 1:
        raise ValueError('Invalid training limits')
    results = []
    for held in paths:
        train_df, _ = load_sample([p for p in paths if p != held], per_class, benign_cap, seed=seed)
        test_df, _ = load_sample([held], per_class, benign_cap, seed=seed + 1)
        conflict = train_df.groupby('__key__')['__label__'].nunique()
        train_df = train_df.loc[~train_df['__key__'].isin(conflict[conflict > 1].index)].drop_duplicates('__key__').copy()
        seen = set(train_df['__key__'])
        overlap = int(test_df['__key__'].isin(seen).sum())
        test_df = test_df.loc[~test_df['__key__'].isin(seen)].drop_duplicates('__key__').copy()
        y = (train_df['__label__'] != 'BENIGN').astype(int)
        yt = (test_df['__label__'] != 'BENIGN').astype(int)
        entry = dict(held_out_capture=held.name, train_rows=len(train_df), test_rows=len(test_df),
                     removed_overlap=overlap, unseen_attack_labels=sorted(set(test_df.loc[yt == 1, '__label__']) - set(train_df.loc[y == 1, '__label__'])))
        if len(test_df) == 0 or y.nunique() != 2 or y.value_counts().min() < 8:
            entry['status'] = 'insufficient_data'; results.append(entry); continue
        fit_idx, val_idx = train_test_split(np.arange(len(y)), test_size=.25, stratify=y, random_state=seed)
        x, xt = train_df[FEATURE_COLUMNS], test_df[FEATURE_COLUMNS]
        model = Pipeline([('impute', SimpleImputer(strategy='median')),
                          ('clf', ExtraTreesClassifier(n_estimators=trees, min_samples_leaf=2,
                                                       class_weight='balanced', random_state=seed, n_jobs=-1))])
        model.fit(x.iloc[fit_idx], y.iloc[fit_idx])
        val_supervised = model.predict_proba(x.iloc[val_idx])[:, 1]
        test_supervised = model.predict_proba(xt)[:, 1]
        benign_fit = x.iloc[fit_idx][y.iloc[fit_idx] == 0]
        imputer = SimpleImputer(strategy='median')
        bx = imputer.fit_transform(benign_fit)
        detector = IsolationForest(n_estimators=100, contamination='auto', random_state=seed, n_jobs=-1)
        detector.fit(bx)
        val_anomaly_raw = -detector.decision_function(imputer.transform(x.iloc[val_idx]))
        test_anomaly_raw = -detector.decision_function(imputer.transform(xt))
        val_y = y.iloc[val_idx].to_numpy()
        benign_reference = val_anomaly_raw[val_y == 0]
        val_anomaly = anomaly_percentile(val_anomaly_raw, benign_reference)
        test_anomaly = anomaly_percentile(test_anomaly_raw, benign_reference)
        # Select fusion coefficient on training-side validation data, not test capture.
        candidates = [0., .25, .5, .75, 1.]
        options = []
        for alpha in candidates:
            val_fused = (1 - alpha) * val_supervised + alpha * val_anomaly
            cut = threshold_at_fpr(val_fused[val_y == 0], fpr_budget)
            options.append((float(np.mean(val_fused[val_y == 1] >= cut)), -alpha, alpha, cut))
        _, _, alpha, fusion_cut = max(options)
        supervised_cut = threshold_at_fpr(val_supervised[val_y == 0], fpr_budget)
        anomaly_cut = threshold_at_fpr(val_anomaly[val_y == 0], fpr_budget)
        test_fused = (1 - alpha) * test_supervised + alpha * test_anomaly
        entry.update(status='evaluated', fpr_budget=fpr_budget, selected_anomaly_weight=alpha,
                     supervised=metrics(yt, test_supervised, supervised_cut),
                     anomaly=metrics(yt, test_anomaly, anomaly_cut),
                     fusion=metrics(yt, test_fused, fusion_cut),
                     validation_fusion_recall=next(o[0] for o in options if o[2] == alpha))
        results.append(entry)
        print(f'{held.name}: supervised_recall={entry["supervised"]["recall"]} fusion_recall={entry["fusion"]["recall"]} fusion_fpr={entry["fusion"]["fpr"]}', flush=True)
    report = dict(methodology='leave-one-capture-out, sampled, exact-feature-duplicate exclusion',
                  note='No threshold or fusion tuning on held-out captures; validation is within training captures.',
                  limitations=['Not independent-network evaluation', 'FPR budgets are selected on training-side validation only and may not transfer',
                               'Sampling distorts attack prevalence', 'Near duplicates and capture artifacts may remain',
                               'Fusion scores are not calibrated probabilities', 'Rare classes have insufficient support'],
                  settings=dict(per_class=per_class, benign_cap=benign_cap, trees=trees, seed=seed, fpr_budget=fpr_budget),
                  captures=results)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', nargs='+', required=True, type=Path)
    p.add_argument('--output', default=str(Path(__file__).resolve().parent / 'artifacts' / 'model_v3_experiment' / 'evaluation.json'))
    p.add_argument('--per-class', type=int, default=3000)
    p.add_argument('--benign-cap', type=int, default=5000)
    p.add_argument('--trees', type=int, default=60)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--fpr-budget', type=float, default=.05)
    a = p.parse_args()
    run(a.csv, a.output, a.per_class, a.benign_cap, a.trees, a.seed, a.fpr_budget)
    print('Saved:', a.output)
