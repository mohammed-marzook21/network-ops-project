"""Bounded-memory CIC-IDS2017 training with duplicate-disjoint row evaluation.

Evaluation is within-corpus only, NOT independent-capture validation. Models
must never be interpreted as proof of compromise or calibrated risk.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import (classification_report, confusion_matrix, balanced_accuracy_score,
                             f1_score, average_precision_score, roc_auc_score, precision_recall_fscore_support)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

FEATURE_COLUMNS = ['Destination Port','Flow Duration','Total Fwd Packets','Total Backward Packets',
                   'Flow Bytes/s','Flow Packets/s','Fwd Packet Length Mean','Bwd Packet Length Mean',
                   'Flow IAT Mean','Flow IAT Std','SYN Flag Count','ACK Flag Count']
LABEL_COLUMN = 'Label'
LABEL_ALIASES = {'web attack � brute force':'Web Attack Brute Force',
                 'web attack � xss':'Web Attack XSS',
                 'web attack � sql injection':'Web Attack Sql Injection'}

def canonical_columns(df):
    df=df.copy()
    df.columns=[str(c).strip().replace('\ufeff','') for c in df.columns]
    return df

def clean_label(s):
    s=str(s).strip()
    key=re.sub(r'\s+',' ',s).lower()
    if key in LABEL_ALIASES:return LABEL_ALIASES[key]
    if key.startswith('web attack'):
        if 'sql injection' in key:return 'Web Attack Sql Injection'
        if 'brute force' in key:return 'Web Attack Brute Force'
        if 'xss' in key:return 'Web Attack XSS'
    return s

def _row_key(values):
    # Identical numeric vectors share one partition even if labels conflict.
    return hashlib.blake2b(np.asarray(values,dtype='<f8').tobytes(),digest_size=16).hexdigest()

def load_sample(paths, per_class=20000, benign_cap=50000, chunksize=25000, seed=42):
    """Deterministic per-class reservoir sampling, bounded by class caps.

    Reservoirs are per class, so rare attacks are retained without loading full CSVs.
    """
    if per_class<10 or benign_cap<10:raise ValueError('Sampling caps must be >=10')
    rng=np.random.default_rng(seed)
    reservoirs={}; seen=Counter(); source_counts=Counter(); bad_numeric=Counter()
    paths=[Path(p) for p in paths]
    if not paths:raise ValueError('Provide at least one CSV')
    for path in paths:
        if not path.is_file():raise FileNotFoundError(path)
        for chunk in pd.read_csv(path,chunksize=chunksize,low_memory=False,encoding_errors='replace'):
            chunk=canonical_columns(chunk)
            required=FEATURE_COLUMNS+[LABEL_COLUMN]
            missing=[c for c in required if c not in chunk]
            if missing:raise ValueError(f'{path.name}: missing {missing}')
            x=chunk[FEATURE_COLUMNS].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
            bad_numeric[path.name]+=int(x.isna().sum().sum())
            y=chunk[LABEL_COLUMN].map(clean_label)
            source_counts[path.name]+=len(chunk)
            arr=x.to_numpy(dtype='float64')
            for row,label in zip(arr,y):
                if not label or label.lower()=='nan':continue
                seen[label]+=1
                cap=benign_cap if label.upper()=='BENIGN' else per_class
                reservoir=reservoirs.setdefault(label,[])
                item=(row.copy(),path.name)
                if len(reservoir)<cap:reservoir.append(item)
                else:
                    j=int(rng.integers(0,seen[label]))
                    if j<cap:reservoir[j]=item
    records=[]
    for label,items in reservoirs.items():
        for row,source in items:records.append((row,label,source))
    if not records:raise ValueError('No usable labeled rows')
    data=pd.DataFrame(np.stack([r[0] for r in records]),columns=FEATURE_COLUMNS)
    data['__label__']=[r[1] for r in records]
    data['__capture__']=[r[2] for r in records]
    data['__key__']=[_row_key(r[0]) for r in records]
    return data,{'raw_rows_by_capture':dict(source_counts),'raw_labels':dict(seen),
                 'sampled_labels':dict(Counter(data['__label__'])),
                 'nonfinite_or_missing_cells_by_capture':dict(bad_numeric),
                 'sampling_method':'per-class reservoir; rows may be sampled from same attack campaign'}

def _split_disjoint(data,seed):
    # Exact duplicates never cross partitions. Conflicting-label vectors removed.
    conflicts=data.groupby('__key__')['__label__'].nunique()
    conflicted=set(conflicts[conflicts>1].index)
    clean=data.loc[~data['__key__'].isin(conflicted)].drop_duplicates('__key__').reset_index(drop=True)
    key_labels=clean[['__key__','__label__']]
    counts=key_labels['__label__'].value_counts()
    # Too-small classes cannot have statistically meaningful 3-way splits.
    eligible=counts[counts>=6].index
    excluded=counts[counts<6].to_dict()
    clean=clean[clean['__label__'].isin(eligible)].reset_index(drop=True)
    if clean['__label__'].nunique()<2:raise ValueError('Need >=2 labels with >=6 unique feature vectors each')
    tr_idx,rest_idx=train_test_split(np.arange(len(clean)),test_size=.30,
        stratify=clean['__label__'],random_state=seed)
    val_idx,te_idx=train_test_split(rest_idx,test_size=.50,
        stratify=clean.iloc[rest_idx]['__label__'],random_state=seed)
    return clean,tr_idx,val_idx,te_idx,{'conflicting_label_keys_removed':len(conflicted),
                                       'classes_excluded_for_insufficient_unique_rows':excluded,
                                       'unique_rows_after_deduplication':len(clean)}

def _metrics(y,p):
    return {'balanced_accuracy':float(balanced_accuracy_score(y,p)),
            'macro_f1':float(f1_score(y,p,average='macro',zero_division=0)),
            'weighted_f1':float(f1_score(y,p,average='weighted',zero_division=0)),
            'class_report':classification_report(y,p,output_dict=True,zero_division=0)}

def train(paths,output,test_size=.15,seed=42,per_class=20000,benign_cap=50000,
          trees=120,importance_rows=1000):
    if abs(test_size-.15)>1e-8:raise ValueError('Fixed 70/15/15 partitions; test_size must be 0.15')
    data,audit=load_sample(paths,per_class,benign_cap,seed=seed)
    data,tr,va,te,split_audit=_split_disjoint(data,seed)
    x=data[FEATURE_COLUMNS]
    y=data['__label__']
    binary=(y!='BENIGN').astype(int)
    if binary.iloc[tr].nunique()!=2:raise ValueError('Need benign and attack examples in training')
    multiclass=Pipeline([('impute',SimpleImputer(strategy='median')),
                         ('model',ExtraTreesClassifier(n_estimators=trees,min_samples_leaf=2,
                          class_weight='balanced',n_jobs=-1,random_state=seed))])
    binary_clf=Pipeline([('impute',SimpleImputer(strategy='median')),
                         ('model',ExtraTreesClassifier(n_estimators=trees,min_samples_leaf=2,
                          class_weight='balanced',n_jobs=-1,random_state=seed+1))])
    multiclass.fit(x.iloc[tr],y.iloc[tr])
    binary_clf.fit(x.iloc[tr],binary.iloc[tr])
    # Threshold selected ONLY on validation data, never on the test set.
    val_prob=binary_clf.predict_proba(x.iloc[va])[:,list(binary_clf.classes_).index(1)]
    thresholds=np.linspace(.05,.95,91)
    val_f1=[f1_score(binary.iloc[va],val_prob>=t,zero_division=0) for t in thresholds]
    threshold=float(thresholds[int(np.argmax(val_f1))])
    test_prob=binary_clf.predict_proba(x.iloc[te])[:,list(binary_clf.classes_).index(1)]
    test_binary=(test_prob>=threshold).astype(int)
    benign_x=x.iloc[tr][binary.iloc[tr]==0]
    anomaly_pre=SimpleImputer(strategy='median')
    benign_train=anomaly_pre.fit_transform(benign_x)
    rng=np.random.default_rng(seed)
    if len(benign_train)>30000:
        benign_train=benign_train[rng.choice(len(benign_train),30000,replace=False)]
    anomaly=IsolationForest(n_estimators=150,contamination='auto',n_jobs=-1,random_state=seed)
    anomaly.fit(benign_train)
    anomaly_scores=-anomaly.decision_function(anomaly_pre.transform(x.iloc[te]))
    truth=binary.iloc[te].to_numpy()
    multiclass_preds=multiclass.predict(x.iloc[te])
    importance_sample=x.iloc[te].sample(n=min(importance_rows,len(te)),random_state=seed)
    importance_labels=y.loc[importance_sample.index]
    importance=permutation_importance(multiclass,importance_sample,importance_labels,
         scoring='f1_macro',n_repeats=2,random_state=seed,n_jobs=1)
    labels=sorted(y.unique())
    fp=int(((test_binary==1)&(truth==0)).sum());tn=int(((test_binary==0)&(truth==0)).sum())
    report={'methodology':'sampled within-corpus, exact-duplicate-disjoint 70/15/15 train/validation/test',
            'training_rows':len(tr),'validation_rows':len(va),'test_rows':len(te),
            'classes':labels,'features':FEATURE_COLUMNS,'data_audit':audit,'split_audit':split_audit,
            'multiclass':_metrics(y.iloc[te],multiclass_preds),
            'confusion_matrix':{'labels':labels,'values':confusion_matrix(y.iloc[te],multiclass_preds,labels=labels).tolist()},
            'binary':{**_metrics(truth,test_binary),'decision_threshold':threshold,
                      'roc_auc':float(roc_auc_score(truth,test_prob)),
                      'average_precision':float(average_precision_score(truth,test_prob)),
                      'false_positive_rate':fp/(fp+tn) if fp+tn else None},
            'anomaly':{'roc_auc':float(roc_auc_score(truth,anomaly_scores)),
                       'average_precision':float(average_precision_score(truth,anomaly_scores)),
                       'score_is_probability':False},
            'explainability':{'method':'held-out permutation importance (global, sampled)',
                'importance':dict(sorted(zip(FEATURE_COLUMNS,map(float,importance.importances_mean)),key=lambda z:-z[1]))},
            'limitations':['Same-corpus random partitions are not independent attack-campaign validation',
                           'Exact duplicates removed but correlated flows and near duplicates may remain',
                           'Class imbalance and extremely rare classes limit per-class conclusions',
                           'Binary probabilities are uncalibrated; anomaly scores are not probabilities',
                           'No source/destination IP, flow ID, or timestamps in input CSVs',
                           'Cross-capture generalization has NOT been measured by this pipeline']}
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    artifact={'classifier':multiclass,'binary_classifier':binary_clf,'binary_threshold':threshold,
              'anomaly_preprocessor':anomaly_pre,'anomaly_model':anomaly,
              'features':FEATURE_COLUMNS,'classes':labels,'evaluation':report}
    joblib.dump(artifact,output/'models.joblib')
    (output/'evaluation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

def predict(artifact,flows):
    if not flows:raise ValueError('At least one flow required')
    if len(flows)>100:raise ValueError('At most 100 flows per request')
    x=canonical_columns(pd.DataFrame(flows))
    for col in artifact['features']:
        if col not in x:raise ValueError(f'Missing required numeric feature: {col}')
    x=x[artifact['features']].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
    if x.isna().all(axis=1).any():raise ValueError('At least one valid numeric feature required per flow')
    labels=artifact['classifier'].predict(x)
    anomaly=-artifact['anomaly_model'].decision_function(artifact['anomaly_preprocessor'].transform(x))
    binary_model=artifact.get('binary_classifier')
    probabilities=binary_model.predict_proba(x)[:,list(binary_model.classes_).index(1)] if binary_model is not None else [None]*len(x)
    threshold=artifact.get('binary_threshold',.5)
    return [{'attack_type':str(label),'anomaly_score':float(score),
             'is_anomalous':bool(score>0),'anomaly_score_is_probability':False,
             'intrusion_score':float(prob) if prob is not None else None,
             'intrusion_score_is_calibrated':False,
             'predicted_intrusion':bool(prob>=threshold) if prob is not None else None,
             'requires_analyst_review':True}
            for label,score,prob in zip(labels,anomaly,probabilities)]

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--csv',nargs='+',required=True,type=Path)
    parser.add_argument('--output',default=str(Path(__file__).resolve().parent/'artifacts'/'models'))
    parser.add_argument('--per-class',type=int,default=20000)
    parser.add_argument('--benign-cap',type=int,default=50000)
    parser.add_argument('--trees',type=int,default=120)
    parser.add_argument('--seed',type=int,default=42)
    args=parser.parse_args()
    print(json.dumps(train(args.csv,args.output,seed=args.seed,per_class=args.per_class,
                           benign_cap=args.benign_cap,trees=args.trees),indent=2))
