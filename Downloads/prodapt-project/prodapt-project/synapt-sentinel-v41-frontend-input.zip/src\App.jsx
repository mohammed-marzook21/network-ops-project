import { useCallback, useEffect, useRef, useState } from 'react'
import IncidentCharts from './IncidentCharts'
import KnowledgeGraph from './KnowledgeGraph'
import './App.css'

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000'
const PAGES = [
  { id: 'overview', label: 'Overview', icon: 'grid', description: 'Operational snapshot' },
  { id: 'incidents', label: 'Incident Explorer', icon: 'layers', description: 'Flows and evidence' },
  { id: 'investigate', label: 'AI Investigation', icon: 'spark', description: 'Synapt.AI workspace' },
  { id: 'response', label: 'Response Center', icon: 'shield', description: 'Analyst-guided actions' },
  { id: 'reports', label: 'Reports', icon: 'file', description: 'Export investigation records' },
]
const ICON_PATHS = {
  grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
  layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/></>,
  spark: <><path d="m12 3 1.9 6.1L20 11l-6.1 1.9L12 19l-1.9-6.1L4 11l6.1-1.9L12 3Z"/><path d="m19 17 .7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7L19 17Z"/></>,
  shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></>,
  file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  arrow: <><path d="M5 12h14m-6-6 6 6-6 6"/></>,
  chevron: <><path d="m9 18 6-6-6-6"/></>,
  activity: <><path d="M3 12h4l3-8 4 16 3-8h4"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  down: <><path d="M12 3v12m-5-5 5 5 5-5M5 18v3h14v-3"/></>,
  alert: <><path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 3h.01"/></>,
  check: <><path d="m5 12 4 4L19 6"/></>,
  menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
  close: <><path d="M5 5 19 19M19 5 5 19"/></>,
  terminal: <><rect x="2" y="3" width="20" height="18" rx="2"/><path d="m6 8 4 4-4 4m7 0h5"/></>,
  filter: <><path d="M4 5h16l-6 7v6l-4 2v-8Z"/></>,
}
function Icon({ name, size = 19, className = '' }) {
  return <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{ICON_PATHS[name] || ICON_PATHS.activity}</svg>
}
function initialPage() { const hash = window.location.hash.replace('#/', ''); return PAGES.some((p) => p.id === hash) ? hash : 'overview' }
function Panel({ children, className = '', ...props }) { return <section className={`panel ${className}`} {...props}>{children}</section> }
function SectionTitle({ kicker, title, description, right }) { return <div className="section-heading"><div><span className="eyebrow">{kicker}</span><h2>{title}</h2>{description && <p>{description}</p>}</div>{right && <div className="heading-action">{right}</div>}</div> }
function EmptyState({ title, message }) { return <div className="empty-state"><Icon name="layers" size={27}/><h3>{title}</h3><p>{message}</p></div> }
function Status({ children, kind = 'info' }) { return <div role={kind === 'danger' ? 'alert' : 'status'} className={`status status-${kind}`}>{kind === 'danger' || kind === 'warning' ? <Icon name="alert" size={17} /> : <Icon name="activity" size={17}/>}<span>{children}</span></div> }
function formatNumber(n) { return typeof n === 'number' ? n.toLocaleString() : n ?? '—' }
function statTotal(items) { return items.reduce((sum, item) => sum + (Number(item.record_count) || 0), 0) }

export default function App() {
  const [page, setPage] = useState(initialPage)
  const [menuOpen, setMenuOpen] = useState(false)
  const [incidents, setIncidents] = useState([])
  const [catalogError, setCatalogError] = useState('')
  const [catalogLoading, setCatalogLoading] = useState(true)
  const [selectedId, setSelectedId] = useState('')
  const [incident, setIncident] = useState(null)
  const [loadingIncident, setLoadingIncident] = useState(false)
  const [incidentError, setIncidentError] = useState('')
  const [localAnalysis, setLocalAnalysis] = useState(null)
  const [loadingLocal, setLoadingLocal] = useState(false)
  const [localError, setLocalError] = useState('')
  const [recommendations, setRecommendations] = useState(null)
  const [loadingRecommendations, setLoadingRecommendations] = useState(false)
  const [recommendationsError, setRecommendationsError] = useState('')
  const [analysis, setAnalysis] = useState(null)
  const [customQuestion, setCustomQuestion] = useState('')
  const [loadingAI, setLoadingAI] = useState(false)
  const [aiError, setAiError] = useState('')
  const [notice, setNotice] = useState('')
  const [questions, setQuestions] = useState([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All types')
  const requestCounter = useRef(0)
  const aiController = useRef(null)
  const selectedRef = useRef('')
  const pageRef = useRef(null)

  const navigate = useCallback((next) => { window.location.hash = `/${next}`; setPage(next); setMenuOpen(false); window.scrollTo({ top: 0, behavior: 'instant' }) }, [])
  useEffect(() => { const handle = () => setPage(initialPage()); window.addEventListener('hashchange', handle); return () => window.removeEventListener('hashchange', handle) }, [])
  useEffect(() => {
    const section = pageRef.current
    if (!section) return
    section.classList.remove('page-enter')
    void section.offsetWidth
    section.classList.add('page-enter')
  }, [page])
  useEffect(() => {
    const controller = new AbortController()
    async function load() {
      try {
        const response = await fetch(`${API_BASE}/api/incidents/dataset`, { signal: controller.signal })
        if (!response.ok) throw new Error(`Incident catalog returned HTTP ${response.status}`)
        const data = await response.json()
        const items = Array.isArray(data.incidents) ? data.incidents : []
        setIncidents(items)
        setSelectedId((previous) => previous || items[0]?.incident_id || '')
      } catch (err) { if (err.name !== 'AbortError') setCatalogError(err.message || 'Could not load incident catalog') }
      finally { if (!controller.signal.aborted) setCatalogLoading(false) }
    }
    load()
    return () => controller.abort()
  }, [])
  useEffect(() => {
    selectedRef.current = selectedId
    requestCounter.current += 1
    aiController.current?.abort()
    aiController.current = null
    setLoadingAI(false); setAnalysis(null); setNotice(''); setAiError(''); setCustomQuestion(''); setQuestions([])
    setIncident(null); setLocalAnalysis(null); setRecommendations(null)
    setIncidentError(''); setLocalError(''); setRecommendationsError('')
    if (!selectedId) return
    const controller = new AbortController()
    async function get(url) { const response = await fetch(url, { signal: controller.signal }); if (!response.ok) throw new Error(`HTTP ${response.status}`); return response.json() }
    async function loadIncident() {
      setLoadingIncident(true)
      try { const data = await get(`${API_BASE}/api/incidents/dataset/${encodeURIComponent(selectedId)}`); if (!data.success || data.incident?.incident_id !== selectedId) throw new Error('Invalid incident response'); setIncident(data.incident) }
      catch (err) { if (err.name !== 'AbortError') setIncidentError(err.message || 'Incident evidence unavailable') }
      finally { if (!controller.signal.aborted) setLoadingIncident(false) }
    }
    async function loadLocal() {
      setLoadingLocal(true)
      try { const data = await get(`${API_BASE}/api/incidents/dataset/${encodeURIComponent(selectedId)}/local-analysis`); if (!data.success || data.analysis?.incident_id !== selectedId) throw new Error('Invalid local analysis response'); setLocalAnalysis(data.analysis) }
      catch (err) { if (err.name !== 'AbortError') setLocalError(err.message || 'Local statistics unavailable') }
      finally { if (!controller.signal.aborted) setLoadingLocal(false) }
    }
    async function loadRecommendations() {
      setLoadingRecommendations(true)
      try { const data = await get(`${API_BASE}/api/incidents/dataset/${encodeURIComponent(selectedId)}/recommendations`); if (!data.success || data.recommendations?.incident_id !== selectedId) throw new Error('Invalid recommendations response'); setRecommendations(data.recommendations) }
      catch (err) { if (err.name !== 'AbortError') setRecommendationsError(err.message || 'Recommendations unavailable') }
      finally { if (!controller.signal.aborted) setLoadingRecommendations(false) }
    }
    loadIncident(); loadLocal(); loadRecommendations()
    return () => controller.abort()
  }, [selectedId])

  async function analyzeIncident(custom = '') {
    if (!incident || loadingAI || selectedRef.current !== incident.incident_id) return
    const currentId = incident.incident_id
    const myRequest = ++requestCounter.current
    const controller = new AbortController()
    aiController.current?.abort(); aiController.current = controller
    setLoadingAI(true); setAiError(''); setNotice(''); setAnalysis(null)
    const prompt = [
      `Find incident ${currentId} from CIC-IDS2017.`,
      `Its dataset attack label is ${incident.attack_type}.`,
      custom ? `Answer this analyst question: ${custom}` : 'Analyze the incident and identify relevant evidence.',
      `Identify evidence specifically belonging to ${currentId}.`,
      'Cite its source document and flow measurements.',
      'Do not substitute evidence from synthetic incident INC-001.',
      'If the incident is not indexed, state that it is unavailable.',
    ].join(' ')
    setQuestions((history) => [{ incidentId: currentId, text: custom || 'Analyze incident', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }, ...history].slice(0, 6))
    try {
      const response = await fetch(`${API_BASE}/api/incidents/analyze`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: prompt }), signal: controller.signal })
      if (!response.ok) throw new Error(`Backend returned HTTP ${response.status}`)
      const data = await response.json()
      if (!data.success || !data.analysis) throw new Error('No incident analysis returned')
      if (myRequest !== requestCounter.current || selectedRef.current !== currentId) return
      const matchingSources = (Array.isArray(data.analysis.sources) ? data.analysis.sources : []).filter((source) => typeof source.text === 'string' && source.text.includes(currentId))
      if (!matchingSources.length) {
        setNotice(`Synapt.AI returned no source evidence identifying ${currentId}. Its response is not displayed as verified analysis of this CIC-IDS2017 incident.`)
        return
      }
      setAnalysis({ ...data.analysis, sources: matchingSources })
    } catch (err) { if (err.name !== 'AbortError' && myRequest === requestCounter.current) setAiError(err.message || 'AI analysis failed') }
    finally { if (myRequest === requestCounter.current) { setLoadingAI(false); aiController.current = null } }
  }

  const chosen = incidents.find((item) => item.incident_id === selectedId)
  const current = incident?.incident_id === selectedId ? incident : null
  const local = localAnalysis?.incident_id === selectedId ? localAnalysis : null
  const response = recommendations?.incident_id === selectedId ? recommendations : null
  const categories = ['All types', ...new Set(incidents.map((item) => item.attack_type).filter(Boolean))]
  const filtered = incidents.filter((item) => (category === 'All types' || item.attack_type === category) && `${item.incident_id} ${item.attack_type}`.toLowerCase().includes(search.toLowerCase()))
  const currentPage = PAGES.find((item) => item.id === page) || PAGES[0]
  const activeFlows = current?.flows?.length || 0
  const attackFamilies = new Set(incidents.map((item) => item.attack_type).filter(Boolean)).size
  const reportBase = current ? `${API_BASE}/api/incidents/dataset/${encodeURIComponent(current.incident_id)}/report` : ''
  const changeIncident = (id) => { selectedRef.current = id; requestCounter.current += 1; aiController.current?.abort(); setSelectedId(id) }
  const goIncident = (id, target = 'incidents') => { changeIncident(id); navigate(target) }

  const incidentSelector = <label className="context-picker"><span>ACTIVE CASE</span><select aria-label="Select incident" value={selectedId} disabled={!incidents.length} onChange={(event) => changeIncident(event.target.value)}>{incidents.length === 0 && <option value="">No incidents loaded</option>}{incidents.map((item) => <option key={item.incident_id} value={item.incident_id}>{item.incident_id} · {item.attack_type}</option>)}</select></label>

  return <div className="app-shell">
    {menuOpen && <button className="mobile-overlay" onClick={() => setMenuOpen(false)} aria-label="Close navigation"/>}
    <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
      <div className="brand"><div className="brand-symbol"><Icon name="shield" size={23}/></div><div><div className="brand-name">synapt<span>sentinel</span></div><div className="brand-caption">SECURITY INTELLIGENCE</div></div></div>
      <div className="sidebar-group-label">WORKSPACE</div>
      <nav aria-label="Primary navigation" className="side-nav">{PAGES.map((item) => <button type="button" key={item.id} className={`nav-link ${page === item.id ? 'active' : ''}`} onClick={() => navigate(item.id)} aria-current={page === item.id ? 'page' : undefined}><Icon name={item.icon}/><span>{item.label}</span>{page === item.id && <i/>}</button>)}</nav>
      <div className="sidebar-spacer"/>
      <div className="sidebar-system"><div className="system-heading"><span className="pulse-dot"/> LOCAL WORKSPACE</div><p>CIC-IDS2017 sampled evidence</p><div className="system-row"><span>Incident records</span><strong>{incidents.length || '—'}</strong></div><div className="system-row"><span>Automation</span><strong>Advisory only</strong></div></div>
      <div className="sidebar-footer"><div className="sidebar-avatar">SS</div><div><strong>Analyst workspace</strong><span>Prototype environment</span></div></div>
    </aside>
    <div className="workspace">
      <header className="topbar"><div className="topbar-left"><button className="mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Open navigation"><Icon name="menu"/></button><span className="topbar-crumb">WORKSPACE</span><Icon name="chevron" size={14}/><strong>{currentPage.label}</strong></div><div className="topbar-right"><span className="topbar-dataset"><span className="tiny-dot"/> CIC-IDS2017 / LOCAL EVIDENCE</span><div className="top-avatar">SS</div></div></header>
      <main ref={pageRef} className="workspace-content page-enter" key={page}>
        {catalogError && <Status kind="danger">Unable to load incident catalog: {catalogError}. Confirm your FastAPI backend is running.</Status>}
        {page === 'overview' && <>
          <div className="hero-panel"><div className="hero-copy"><div className="hero-kicker"><span className="pulse-dot"/> INVESTIGATION WORKSPACE <span className="hero-separator">/</span> CIC-IDS2017</div><h1>Clarity in the<br/><span>critical moments.</span></h1><p>Explore network-flow evidence, investigate attack classifications, and prepare analyst-reviewed responses—inside one focused security workspace.</p><button className="primary-button" onClick={() => navigate('incidents')}>Explore incidents <Icon name="arrow" size={18}/></button></div><div className="hero-visual" aria-hidden="true"><div className="radar radar-a"/><div className="radar radar-b"/><div className="radar radar-c"/><div className="radar-core"><Icon name="shield" size={40}/></div><div className="visual-caption">EVIDENCE / NOT LIVE TELEMETRY</div></div></div>
          <div className="metric-grid"><Metric icon="layers" label="Incident records" value={catalogLoading ? '…' : incidents.length} note="Prepared investigation cases"/><Metric icon="activity" label="Dataset-labeled flows" value={catalogLoading ? '…' : formatNumber(statTotal(incidents))} note="Across prepared records"/><Metric icon="filter" label="Attack categories" value={attackFamilies || '—'} note="Distinct dataset labels"/><Metric icon="shield" label="Response execution" value="None" note="Analyst approval required"/></div>
          <div className="content-grid content-grid-wide"><Panel className="overview-list"><SectionTitle kicker="CASE QUEUE" title="Explore investigations" description="Prepared cases from sampled CIC-IDS2017 evidence." right={<button className="text-button" onClick={() => navigate('incidents')}>View all <Icon name="arrow" size={16}/></button>}/><div className="case-list">{incidents.slice(0, 6).map((item) => <button className="case-row" key={item.incident_id} onClick={() => goIncident(item.incident_id)}><div className="case-icon"><Icon name="activity" size={18}/></div><div className="case-name"><strong>{item.incident_id}</strong><span>{item.attack_type}</span></div><span className="case-count">{formatNumber(item.record_count)} flows</span><Icon name="chevron" size={17}/></button>)}{!incidents.length && <EmptyState title="No cases yet" message="Start the backend to load incident data."/>}</div></Panel><Panel className="insight-panel"><SectionTitle kicker="METHODOLOGY" title="Evidence-first analysis"/><div className="insight-line"><span className="insight-number">01</span><div><strong>Examine the signals</strong><p>Review labeled network flows and descriptive local measurements.</p></div></div><div className="insight-line"><span className="insight-number">02</span><div><strong>Validate AI context</strong><p>Show Synapt.AI findings only when sources identify the selected incident.</p></div></div><div className="insight-line"><span className="insight-number">03</span><div><strong>Prepare a response</strong><p>Document recommendations without executing containment automatically.</p></div></div><button className="outline-button full-button" onClick={() => navigate('investigate')}>Open AI workspace <Icon name="arrow" size={16}/></button></Panel></div>
        </>}
        {page === 'incidents' && <>
          <PageHeader eyebrow="EVIDENCE / EXPLORE" title="Incident Explorer" description="Search the prepared incident catalog, review sampled flows, and investigate traffic patterns."/>
          <Panel className="explorer-panel"><div className="explorer-toolbar"><div className="search-field"><Icon name="search" size={18}/><input aria-label="Search incidents" placeholder="Search by case ID or attack type..." value={search} onChange={(event) => setSearch(event.target.value)}/></div><div className="filter-field"><Icon name="filter" size={17}/><select aria-label="Filter attack type" value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((name) => <option key={name}>{name}</option>)}</select></div><span className="result-count">{filtered.length} cases</span></div><div className="explorer-list">{filtered.map((item) => <button key={item.incident_id} className={`explorer-item ${selectedId === item.incident_id ? 'selected' : ''}`} onClick={() => changeIncident(item.incident_id)}><div className="case-icon"><Icon name="layers" size={17}/></div><span><strong>{item.incident_id}</strong><small>{item.attack_type}</small></span><span className="flow-badge">{formatNumber(item.record_count)} labeled flows</span><Icon name="chevron" size={17}/></button>)}{filtered.length === 0 && <EmptyState title="No matching incidents" message="Try a different search or filter."/>}</div></Panel>
          <div className="section-spacer"/>{current && <div className="case-context"><div><span className="eyebrow">SELECTED CASE</span><h2>{current.incident_id} <span className="case-type">/ {current.attack_type}</span></h2></div><button className="outline-button" onClick={() => navigate('investigate')}>Investigate with AI <Icon name="arrow" size={16}/></button></div>}
          {incidentError && <Status kind="danger">{incidentError}</Status>}{loadingIncident && <Status>Loading selected incident…</Status>}
          <div className="metric-grid metric-grid-three"><Metric icon="activity" label="Sampled flow records" value={current ? activeFlows : '—'} note="Shown in evidence table"/><Metric icon="shield" label="Assessed severity" value={current?.severity || 'Unassessed'} note="No automated severity assignment"/><Metric icon="layers" label="Dataset attack label" value={current?.attack_type || chosen?.attack_type || '—'} note="Label, not proof of compromise"/></div>
          <Panel><SectionTitle kicker="RAW EVIDENCE" title="Flow-level records" description={current?.summary || 'Select a case to inspect its local evidence.'}/>{current?.flows?.length ? <div className="table-scroll"><table className="evidence-table"><thead><tr>{['Flow ID','Destination port','Duration (µs)','Forward packets','Backward packets','Dataset label'].map((header) => <th key={header}>{header}</th>)}</tr></thead><tbody>{current.flows.map((flow, i) => <tr key={flow.flow_id || i}><td className="mono strong-cell">{flow.flow_id || `Flow ${i + 1}`}</td><td>{flow.destination_port ?? '—'}</td><td>{formatNumber(flow.flow_duration)}</td><td>{formatNumber(flow.total_forward_packets)}</td><td>{formatNumber(flow.total_backward_packets)}</td><td><span className="table-tag">{flow.label ?? '—'}</span></td></tr>)}</tbody></table></div> : !loadingIncident && <EmptyState title="No flow data" message="Choose an incident to view sampled evidence."/>}</Panel>
          <IncidentCharts incident={current}/>
          <Panel className="analysis-panel"><SectionTitle kicker="LOCAL ANALYTICS" title="Flow statistics" description="Computed from the selected sample without sending data to Synapt.AI."/>{loadingLocal && <Status>Calculating local flow statistics…</Status>}{localError && <Status kind="danger">{localError}</Status>}{local && <><div className="micro-metrics"><div><span>Sample size</span><strong>{local.sample_size}</strong></div><div><span>Average duration</span><strong>{local.statistics?.average_flow_duration_microseconds == null ? '—' : `${(local.statistics.average_flow_duration_microseconds / 1e6).toFixed(2)} s`}</strong></div><div><span>Forward packets</span><strong>{formatNumber(local.statistics?.total_forward_packets)}</strong></div><div><span>Backward packets</span><strong>{formatNumber(local.statistics?.total_backward_packets)}</strong></div></div><div className="content-grid"><div><h3>Observations</h3><ul className="detail-list">{(local.observations || []).map((entry, i) => <li key={i}>{entry}</li>)}</ul><h3>Common destination ports</h3><ul className="detail-list">{(local.statistics?.common_destination_ports || []).map((entry, i) => <li key={i}>Port {entry.port}: {entry.count} sampled flows</li>)}</ul></div><div><h3>Evidence limitations</h3><ul className="detail-list">{(local.limitations || []).map((entry, i) => <li key={i}>{entry}</li>)}</ul><p className="fine-print">Descriptive analysis only · Severity unassessed · No AI confidence assigned</p></div></div></>}</Panel>
        </>}
        {page === 'investigate' && <>
          <PageHeader eyebrow="INTELLIGENCE / WORKSPACE" title="AI Investigation" description="Ask incident-specific questions and review only source-matched Synapt.AI results."/>
          <div className="content-grid ai-layout"><div className="stack"><Panel className="ai-compose"><div className="panel-topline"><span className="eyebrow">ACTIVE INVESTIGATION</span><span className="status-chip"><span className="tiny-dot"/> SOURCE MATCH REQUIRED</span></div>{incidentSelector}<h2>What would you like to investigate?</h2><p>Queries reference the selected case automatically. Sources must identify the case before AI output is shown as verified analysis.</p><label className="field-label" htmlFor="ai-question">YOUR QUESTION</label><textarea id="ai-question" className="question-input" value={customQuestion} onChange={(event) => setCustomQuestion(event.target.value)} maxLength={1000} rows={5} placeholder="e.g. What evidence supports this attack label, and what should an analyst investigate next?" disabled={!current || loadingAI}/><div className="composer-bottom"><span>{customQuestion.length} / 1000</span><div className="action-pair"><button className="outline-button" disabled={!current || loadingAI} onClick={() => analyzeIncident()}>One-click analysis</button><button className="primary-button" disabled={!current || loadingAI || !customQuestion.trim()} onClick={() => analyzeIncident(customQuestion.trim())}>{loadingAI ? 'Investigating…' : 'Ask Synapt.AI'}<Icon name="arrow" size={16}/></button></div></div></Panel>
          {aiError && <Status kind="danger">{aiError}</Status>}{notice && <Status kind="warning">{notice}</Status>}{loadingAI && <Panel className="loading-panel"><div className="loader"/> Checking Synapt.AI for incident-specific sources…</Panel>}{analysis && <Panel><div className="panel-topline"><span className="eyebrow">SOURCE-MATCHED RESULT</span><span className="verified-tag"><Icon name="check" size={15}/> Incident ID found in source text</span></div><SectionTitle title="Investigation summary"/><p className="answer-text">{analysis.answer || 'No narrative response available.'}</p><div className="content-grid"><div><h3>Indicators</h3>{analysis.indicators?.length ? <ul className="detail-list">{analysis.indicators.map((item, index) => <li key={index}><strong>{item.name}</strong>{item.description && <p>{item.description}</p>}</li>)}</ul> : <p className="muted">No indicators returned.</p>}</div><div><h3>Suggested mitigations</h3>{analysis.mitigations?.length ? <ul className="detail-list">{analysis.mitigations.map((item, index) => <li key={index}><strong>{item.name}</strong><p>{item.requires_approval ? 'Analyst approval required' : 'Review before implementation'}{item.control_type ? ` · ${item.control_type}` : ''}</p></li>)}</ul> : <p className="muted">No mitigations returned.</p>}</div></div><h3>Supporting source extracts ({analysis.sources?.length || 0})</h3>{analysis.sources?.map((source, index) => <details className="source-card" key={index}><summary>Evidence source {index + 1}{source.score != null && ` · Relevance ${Math.round(source.score * 100)}%`}</summary><pre>{source.text}</pre></details>)}<h3>Knowledge graph</h3><KnowledgeGraph graph={analysis.knowledge_graph}/><p className="fine-print">The matching incident ID is a basic source filter, not independent verification of every claim. No mitigation actions are executed.</p></Panel>}{!analysis && !loadingAI && !notice && !aiError && <Panel><EmptyState title="Your investigation starts here" message="Run an incident analysis or ask a custom question. Source-matched results will appear in this workspace."/></Panel>}</div>
          <div className="stack"><Panel className="side-panel"><SectionTitle kicker="CASE CONTEXT" title="Selected evidence"/>{current ? <><div className="context-row"><span>Incident ID</span><strong>{current.incident_id}</strong></div><div className="context-row"><span>Attack label</span><strong>{current.attack_type}</strong></div><div className="context-row"><span>Sampled flows</span><strong>{activeFlows}</strong></div><div className="context-row"><span>Severity</span><strong>{current.severity || 'Unassessed'}</strong></div><button className="text-button" onClick={() => navigate('incidents')}>View dataset evidence <Icon name="arrow" size={16}/></button></> : <p className="muted">Select an incident to begin.</p>}</Panel><Panel className="side-panel"><SectionTitle kicker="QUERY ACTIVITY" title="This session"/>{questions.length ? questions.map((entry, index) => <div className="history-item" key={`${entry.time}-${index}`}><div className="history-mark"><Icon name="terminal" size={16}/></div><div><strong>{entry.text}</strong><span>{entry.incidentId} · {entry.time}</span></div></div>) : <p className="muted">No queries yet for this case. Session activity appears here.</p>}</Panel><Panel className="side-panel safety-panel"><Icon name="shield" size={22}/><h3>Evidence guardrail</h3><p>Unmatched or synthetic INC-001 content is not displayed as verified CIC-IDS2017 incident analysis.</p><p>Synapt.AI knowledge-pack ingestion remains pending external verification.</p></Panel></div></div>
        </>}
        {page === 'response' && <>
          <PageHeader eyebrow="OPERATIONS / RESPONSE" title="Response Center" description="Structured investigation steps and advisory actions. Analyst authorization is always required before disruptive changes."/>
          <Panel className="selection-panel"><div><span className="eyebrow">CURRENT CASE</span><h3>{selectedId || 'Choose an incident'}</h3></div>{incidentSelector}</Panel>
          {loadingRecommendations && <Status>Loading response guidance…</Status>}{recommendationsError && <Status kind="danger">{recommendationsError}</Status>}
          <div className="metric-grid metric-grid-three"><Metric icon="shield" label="Execution status" value={response?.execution_status || 'Not executed'} note="No automated containment"/><Metric icon="check" label="Authorization" value={response?.requires_analyst_approval ? 'Required' : 'Review needed'} note="Human-in-the-loop workflow"/><Metric icon="layers" label="Evidence basis" value={response?.evidence_status || 'Not verified'} note="Dataset-label-derived guidance"/></div>
          {response ? <><Panel className="playbook-intro"><span className="eyebrow">SELECTED RESPONSE PLAYBOOK</span><h2>{response.playbook || 'General investigation'}</h2><p>{response.disclaimer || 'Dataset labels alone do not confirm compromise. No actions have been executed.'}</p></Panel><div className="content-grid"><Panel><SectionTitle kicker="01 / INVESTIGATE" title="Investigation steps" description="Review evidence before determining impact."/><div className="step-list">{(response.investigation_steps || []).map((step, index) => <div className="step-item" key={index}><span>{String(index + 1).padStart(2, '0')}</span><p>{step}</p></div>)}</div></Panel><Panel><SectionTitle kicker="02 / DECIDE" title="Recommended actions" description="Proposed next steps, not executed controls."/><div className="step-list">{(response.recommendations || []).map((step, index) => <div className="step-item" key={index}><span>{String(index + 1).padStart(2, '0')}</span><p>{step}</p></div>)}</div></Panel></div><Status kind="warning">{response.requires_analyst_approval ? 'Analyst approval is required before any disruptive response action.' : 'Review all proposed actions before implementation.'} Synapt Sentinel does not execute containment.</Status></> : !loadingRecommendations && <Panel><EmptyState title="No response guidance loaded" message="Select an incident to view its response playbook."/></Panel>}
        </>}
        {page === 'reports' && <>
          <PageHeader eyebrow="DOCUMENTATION / EXPORT" title="Investigation Reports" description="Generate downloadable incident records directly from the existing FastAPI report endpoints."/>
          <Panel className="selection-panel"><div><span className="eyebrow">REPORT SUBJECT</span><h3>{selectedId || 'Choose an incident'}</h3></div>{incidentSelector}</Panel><div className="report-layout"><Panel className="report-preview"><div className="report-sheet"><div className="report-sheet-top"><div className="report-insignia"><Icon name="shield" size={23}/></div><span>CYBERSECURITY INVESTIGATION / DATASET EVIDENCE</span></div><div className="report-rule"/><span className="eyebrow">INVESTIGATION REPORT</span><h2>{current?.incident_id || 'Select an incident'}</h2><p className="report-subtitle">{current?.attack_type || 'Awaiting dataset evidence'}</p><div className="report-keyvalues"><div><span>DATA SOURCE</span><strong>{current?.source || '—'}</strong></div><div><span>SAMPLED FLOWS</span><strong>{current?.record_count ?? '—'}</strong></div><div><span>SEVERITY</span><strong>{current?.severity || 'Unassessed'}</strong></div></div><h3>Case synopsis</h3><p>{current?.summary || 'Choose an incident to populate the report preview.'}</p><div className="report-footnote">Dataset-derived evidence · No confirmed compromise · Analyst review required</div></div></Panel><div className="stack"><Panel><SectionTitle kicker="EXPORT FORMATS" title="Download report" description="Files are generated by the backend for the active incident."/><a className={`download-option ${!current ? 'download-disabled' : ''}`} href={current ? reportBase : undefined} download={`${selectedId}_report.md`} onClick={(event) => { if (!current) event.preventDefault() }}><span className="download-icon"><Icon name="file"/></span><span><strong>Markdown report</strong><small>Portable, editable investigation summary</small></span><Icon name="down" size={19}/></a><a className={`download-option ${!current ? 'download-disabled' : ''}`} href={current ? `${reportBase}/pdf` : undefined} download={`${selectedId}_report.pdf`} onClick={(event) => { if (!current) event.preventDefault() }}><span className="download-icon"><Icon name="file"/></span><span><strong>PDF report</strong><small>Presentation-ready incident documentation</small></span><Icon name="down" size={19}/></a></Panel><Panel className="safety-panel"><Icon name="alert" size={22}/><h3>Report scope</h3><p>Exports contain locally prepared CIC-IDS2017 evidence and advisory analysis. No source or destination IPs are inferred where unavailable.</p></Panel></div></div>
        </>}
        <footer className="workspace-footer"><span>SYNAPT / SENTINEL</span><span>Prepared CIC-IDS2017 evidence · Prototype environment · No automated containment</span></footer>
      </main>
    </div>
  </div>
}
function Metric({ icon, label, value, note }) { return <div className="metric-card"><div className="metric-top"><span>{label}</span><div className="metric-icon"><Icon name={icon} size={18}/></div></div><strong className="metric-value">{value}</strong><span className="metric-note">{note}</span></div> }
function PageHeader({ eyebrow, title, description }) { return <div className="page-header"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div> }
