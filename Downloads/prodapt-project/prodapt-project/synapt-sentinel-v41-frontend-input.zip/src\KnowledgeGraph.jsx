
import { useCallback, useMemo, useState } from 'react'
import dagre from '@dagrejs/dagre'

import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  MarkerType,
  Position,
  Panel,
} from '@xyflow/react'

import '@xyflow/react/dist/style.css'

const COLORS = {
  Incident: '#dc2626',
  AttackType: '#7c3aed',
  AttackFamily: '#9333ea',
  Indicator: '#0891b2',
  IPAddress: '#2563eb',
  Port: '#d97706',
  Mitigation: '#16a34a',
  Document: '#475569',
  Chunk: '#64748b',
}

const CATEGORY_ORDER = [
  'Incident',
  'AttackType',
  'AttackFamily',
  'Indicator',
  'IPAddress',
  'Port',
  'Mitigation',
  'Document',
  'Chunk',
]

const NODE_WIDTH = 220
const NODE_HEIGHT = 86

const PANEL_STYLE = {
  background: '#0f172a',
  border: '1px solid #334155',
  borderRadius: 12,
  padding: 20,
  color: '#e2e8f0',
}

const BUTTON_STYLE = {
  background: '#1e293b',
  border: '1px solid #475569',
  borderRadius: 8,
  padding: '9px 14px',
  color: '#e2e8f0',
  cursor: 'pointer',
  fontWeight: 600,
}

function prettyLabel(value) {
  return String(value ?? 'Unknown')
    .replaceAll('_', ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
}

function getEntityName(node) {
  const properties = node.properties || {}

  return String(
    properties.name ||
    properties.filename ||
    properties.title ||
    properties.value ||
    node.name ||
    node.label ||
    node.node_id ||
    'Unknown entity'
  )
}

function getSeverityColor(severity) {
  const value = String(severity || '').toLowerCase()

  if (value === 'critical') return '#ef4444'
  if (value === 'high') return '#fb7185'
  if (value === 'medium') return '#fbbf24'
  if (value === 'low') return '#4ade80'

  return '#cbd5e1'
}

function formatValue(value) {
  if (value === null || value === undefined || value === '') {
    return 'Not available'
  }

  if (typeof value === 'object') {
    return JSON.stringify(value, null, 2)
  }

  return String(value)
}

function formatConfidence(value) {
  const number = Number(value)

  if (!Number.isFinite(number)) {
    return 'Not available'
  }

  const percentage = number <= 1 ? number * 100 : number

  return `${Math.round(percentage)}%`
}

function getCategoryIndex(category) {
  const index = CATEGORY_ORDER.indexOf(category)
  return index === -1 ? CATEGORY_ORDER.length : index
}

function createLayout(nodes, edges, direction = 'TB') {
  const layoutGraph = new dagre.graphlib.Graph()

  layoutGraph.setDefaultEdgeLabel(() => ({}))

  layoutGraph.setGraph({
    rankdir: direction,
    ranksep: 110,
    nodesep: 65,
    edgesep: 25,
    marginx: 50,
    marginy: 50,
    acyclicer: 'greedy',
  })

  nodes.forEach((node) => {
    layoutGraph.setNode(node.id, {
      width: NODE_WIDTH,
      height: NODE_HEIGHT,
    })
  })

  edges.forEach((edge) => {
    layoutGraph.setEdge(edge.source, edge.target)
  })

  dagre.layout(layoutGraph)

  return nodes.map((node) => {
    const position = layoutGraph.node(node.id)

    if (!position) return node

    return {
      ...node,
      position: {
        x: position.x - NODE_WIDTH / 2,
        y: position.y - NODE_HEIGHT / 2,
      },
      sourcePosition:
        direction === 'LR' ? Position.Right : Position.Bottom,
      targetPosition:
        direction === 'LR' ? Position.Left : Position.Top,
    }
  })
}

function DetailRow({ label, value, color }) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(120px, 190px) minmax(0, 1fr)',
        gap: 16,
        padding: '10px 0',
        borderBottom: '1px solid #1e293b',
      }}
    >
      <strong style={{ color: '#94a3b8' }}>
        {prettyLabel(label)}
      </strong>

      <span
        style={{
          color: color || '#e2e8f0',
          overflowWrap: 'anywhere',
          whiteSpace: 'pre-wrap',
        }}
      >
        {formatValue(value)}
      </span>
    </div>
  )
}

function KnowledgeGraph({ graph }) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [direction, setDirection] = useState('TB')
  const [selectedNodeId, setSelectedNodeId] = useState(null)
  const [selectedEdgeId, setSelectedEdgeId] = useState(null)
  const [showTechnical, setShowTechnical] = useState(false)
  const [focusConnections, setFocusConnections] = useState(true)

  const graphNodes = graph?.nodes ?? []
  const graphEdges = graph?.edges ?? []

  const categories = useMemo(() => {
    const available = [
      ...new Set(graphNodes.map((node) => node.label).filter(Boolean)),
    ]

    return available.sort(
      (a, b) => getCategoryIndex(a) - getCategoryIndex(b)
    )
  }, [graphNodes])

  const prepared = useMemo(() => {
    const sorted = [...graphNodes].sort(
      (a, b) =>
        getCategoryIndex(a.label) - getCategoryIndex(b.label)
    )

    const nodes = sorted
      .filter((node) => node.node_id != null)
      .map((node) => {
        const name = getEntityName(node)
        const categoryName = node.label || 'Unknown'
        const properties = node.properties || {}

        return {
          id: String(node.node_id),
          type: 'default',
          position: { x: 0, y: 0 },
          data: {
            label: name,
            category: categoryName,
            properties,
          },
          style: {
            width: NODE_WIDTH,
            minHeight: 55,
            background: COLORS[categoryName] || '#334155',
            color: '#ffffff',
            border: '1px solid #94a3b8',
            borderRadius: 12,
            padding: '14px 12px',
            fontSize: 13,
            fontWeight: 600,
            textAlign: 'center',
            overflowWrap: 'anywhere',
            boxShadow: '0 4px 12px rgba(0,0,0,0.18)',
          },
        }
      })

    const nodeIds = new Set(nodes.map((node) => node.id))

    const edges = graphEdges
      .filter(
        (edge) =>
          nodeIds.has(String(edge.source)) &&
          nodeIds.has(String(edge.target))
      )
      .map((edge, index) => ({
        id: `edge-${index}`,
        source: String(edge.source),
        target: String(edge.target),
        type: 'smoothstep',
        data: {
          relationship: String(
            edge.edge_type || edge.type || 'RELATED_TO'
          ).replaceAll('_', ' '),
          properties: edge.properties || {},
        },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: '#64748b',
        },
        style: {
          stroke: '#64748b',
          strokeWidth: 1.6,
        },
        interactionWidth: 24,
      }))

    return { nodes, edges }
  }, [graphNodes, graphEdges])

  const visible = useMemo(() => {
    const query = search.trim().toLowerCase()

    const filteredNodes = prepared.nodes.filter((node) => {
      const matchesCategory =
        category === 'All' || node.data.category === category

      const matchesSearch =
        !query ||
        node.data.label.toLowerCase().includes(query) ||
        node.data.category.toLowerCase().includes(query) ||
        node.id.toLowerCase().includes(query)

      return matchesCategory && matchesSearch
    })

    const visibleIds = new Set(
      filteredNodes.map((node) => node.id)
    )

    const filteredEdges = prepared.edges.filter(
      (edge) =>
        visibleIds.has(edge.source) &&
        visibleIds.has(edge.target)
    )

    return {
      nodes: createLayout(
        filteredNodes,
        filteredEdges,
        direction
      ),
      edges: filteredEdges,
    }
  }, [prepared, search, category, direction])

  const nodeLookup = useMemo(
    () =>
      new Map(
        prepared.nodes.map((node) => [node.id, node])
      ),
    [prepared.nodes]
  )

  const selectedNode = selectedNodeId
    ? nodeLookup.get(selectedNodeId)
    : null

  const selectedEdge = selectedEdgeId
    ? prepared.edges.find(
        (edge) => edge.id === selectedEdgeId
      )
    : null

  const connectedNodeIds = useMemo(() => {
    if (!selectedNodeId || !focusConnections) {
      return null
    }

    const connected = new Set([selectedNodeId])

    prepared.edges.forEach((edge) => {
      if (edge.source === selectedNodeId) {
        connected.add(edge.target)
      }

      if (edge.target === selectedNodeId) {
        connected.add(edge.source)
      }
    })

    return connected
  }, [selectedNodeId, focusConnections, prepared.edges])

  const displayNodes = useMemo(
    () =>
      visible.nodes.map((node) => ({
        ...node,
        style: {
          ...node.style,
          opacity:
            connectedNodeIds &&
            !connectedNodeIds.has(node.id)
              ? 0.25
              : 1,
          border:
            selectedNodeId === node.id
              ? '3px solid #f8fafc'
              : node.style.border,
        },
      })),
    [visible.nodes, connectedNodeIds, selectedNodeId]
  )

  const displayEdges = useMemo(
    () =>
      visible.edges.map((edge) => {
        const connected =
          selectedNodeId &&
          (edge.source === selectedNodeId ||
            edge.target === selectedNodeId)

        const highlighted =
          selectedEdgeId === edge.id || connected

        return {
            ...edge,
            animated: Boolean(highlighted),

            label: highlighted
                ? edge.data.relationship
                : undefined,

            labelStyle: {
                fill: '#e2e8f0',
                fontSize: 12,
                fontWeight: 600,
            },

            labelBgStyle: {
                fill: '#0f172a',
                fillOpacity: 0.95,
            },

            labelBgPadding: [6, 4],
            labelBgBorderRadius: 4,


          style: {
            stroke: highlighted ? '#38bdf8' : '#64748b',
            strokeWidth: highlighted ? 2.8 : 1.6,
            opacity:
              connectedNodeIds && !connected
                ? 0.15
                : 1,
          },
          markerEnd: {
            type: MarkerType.ArrowClosed,
            color: highlighted ? '#38bdf8' : '#64748b',
          },
        }
      }),
    [
      visible.edges,
      selectedNodeId,
      selectedEdgeId,
      connectedNodeIds,
    ]
  )

  const clearSelection = useCallback(() => {
    setSelectedNodeId(null)
    setSelectedEdgeId(null)
  }, [])

  const resetFilters = () => {
  setSearch('')
  setCategory('All')
  setDirection('TB')
  setFocusConnections(true)
  setShowTechnical(false)
  clearSelection()
}

  if (!prepared.nodes.length) {
    return (
      <div style={PANEL_STYLE}>
        No knowledge graph data available.
      </div>
    )
  }

  const properties = selectedNode?.data.properties || {}
  const connectedRelationships = selectedNode
    ? prepared.edges.filter(
        (edge) =>
            edge.source === selectedNode.id ||
            edge.target === selectedNode.id
        )
    : []
  const importantKeys = [
    'severity',
    'attack_label',
    'summary',
    'description',
    'confidence',
    'health',
    'coverage',
    'episode_role',
  ]

  const technicalKeys = new Set([
    'kg_node_id',
    'kg_node_label',
    'source_chunk_ids',
    'provenance',
    'temporal_transaction_time',
    'temporal_confidence',
    'temporal_source',
  ])

  const displayedProperties = Object.entries(properties).filter(
    ([key]) =>
      key !== 'name' &&
      (showTechnical || !technicalKeys.has(key))
  )

  displayedProperties.sort(([a], [b]) => {
    const aIndex = importantKeys.indexOf(a)
    const bIndex = importantKeys.indexOf(b)

    return (
      (aIndex === -1 ? 999 : aIndex) -
      (bIndex === -1 ? 999 : bIndex)
    )
  })

  return (
    <div style={{ color: '#e2e8f0' }}>
      {/* Graph statistics */}
      <div
        style={{
          display: 'flex',
          gap: 12,
          flexWrap: 'wrap',
          marginBottom: 16,
        }}
      >
        {[
          ['Entities', prepared.nodes.length],
          ['Relationships', prepared.edges.length],
          ['Categories', categories.length],
          ['Visible Nodes', visible.nodes.length],
        ].map(([label, value]) => (
          <div
            key={label}
            style={{
              ...PANEL_STYLE,
              padding: '12px 18px',
              minWidth: 130,
            }}
          >
            <div
              style={{
                color: '#94a3b8',
                fontSize: 12,
              }}
            >
              {label}
            </div>
            <div
              style={{
                fontSize: 24,
                fontWeight: 700,
                marginTop: 4,
              }}
            >
              {value}
            </div>
          </div>
        ))}
      </div>

      {/* Search and filtering */}
      <div
        style={{
          ...PANEL_STYLE,
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'end',
          gap: 14,
          marginBottom: 16,
        }}
      >
        <label
          style={{
            display: 'grid',
            gap: 6,
            flex: '1 1 220px',
          }}
        >
          <span style={{ color: '#94a3b8' }}>
            Search entities
          </span>

          <input
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
              clearSelection()
            }}
            placeholder="Search incident, IP, indicator..."
            style={{
              padding: '10px 12px',
              borderRadius: 8,
              background: '#0b1120',
              color: '#e2e8f0',
              border: '1px solid #475569',
              width: '100%',
              boxSizing: 'border-box',
            }}
          />
        </label>

        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ color: '#94a3b8' }}>
            Entity category
          </span>

          <select
            value={category}
            onChange={(event) => {
              setCategory(event.target.value)
              clearSelection()
            }}
            style={{
              ...BUTTON_STYLE,
              minWidth: 170,
            }}
          >
            <option value="All">All categories</option>

            {categories.map((item) => (
              <option key={item} value={item}>
                {prettyLabel(item)}
              </option>
            ))}
          </select>
        </label>

        <label style={{ display: 'grid', gap: 6 }}>
          <span style={{ color: '#94a3b8' }}>
            Layout
          </span>

          <select
            value={direction}
            onChange={(event) =>
              setDirection(event.target.value)
            }
            style={BUTTON_STYLE}
          >
            <option value="TB">Top to bottom</option>
            <option value="LR">Left to right</option>
          </select>
        </label>

        <button
          type="button"
          onClick={resetFilters}
          style={BUTTON_STYLE}
        >
          Reset Graph
        </button>
      </div>

      {/* Category legend */}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: '10px 18px',
          marginBottom: 14,
        }}
      >
        {categories.map((item) => (
          <div
            key={item}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 7,
              fontSize: 12,
              color: '#cbd5e1',
            }}
          >
            <span
              style={{
                width: 11,
                height: 11,
                borderRadius: 3,
                background: COLORS[item] || '#334155',
              }}
            />
            {prettyLabel(item)}
          </div>
        ))}
      </div>

      {/* Knowledge graph canvas */}
      <div
        style={{
          height: 680,
          width: '100%',
          background: '#0b1120',
          border: '1px solid #334155',
          borderRadius: 12,
          overflow: 'hidden',
        }}
      >
        <ReactFlow
          nodes={displayNodes}
          edges={displayEdges}
          fitView
          fitViewOptions={{
            padding: 0.15,
            minZoom: 0.5,
            maxZoom: 0.85,
            }}
          minZoom={0.1}
          maxZoom={2}
          nodesDraggable
          nodesConnectable={false}
          elementsSelectable
          onNodeClick={(_, node) => {
            setSelectedNodeId(node.id)
            setSelectedEdgeId(null)
          }}
          onEdgeClick={(_, edge) => {
            setSelectedEdgeId(edge.id)
            setSelectedNodeId(null)
          }}
          onPaneClick={clearSelection}
          colorMode="dark"
        >
          <Background
            color="#334155"
            gap={20}
            size={1}
          />

          <Controls />

          <MiniMap
            nodeColor={(node) =>
              COLORS[node.data.category] || '#334155'
            }
            style={{
              backgroundColor: '#111827',
              border: '1px solid #334155',
              borderRadius: 8,
            }}
            maskColor="rgba(15, 23, 42, 0.65)"
            pannable
            zoomable
          />

          <Panel position="top-right">
            <div
              style={{
                background: '#0f172a',
                border: '1px solid #334155',
                padding: '8px 12px',
                borderRadius: 8,
                fontSize: 12,
                color: '#94a3b8',
              }}
            >
              Click a node or relationship to inspect
            </div>
          </Panel>
        </ReactFlow>
      </div>

      {/* Investigation options */}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 18,
          marginTop: 14,
          fontSize: 13,
          color: '#94a3b8',
        }}
      >
        <label>
          <input
            type="checkbox"
            checked={focusConnections}
            onChange={(event) =>
              setFocusConnections(event.target.checked)
            }
            style={{ marginRight: 8 }}
          />
          Highlight connected entities
        </label>

        <span>
          Read-only investigation. No mitigation actions
          are executed.
        </span>
      </div>

      {/* Entity inspection panel */}
      {selectedNode && (
        <div
          style={{
            ...PANEL_STYLE,
            marginTop: 20,
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'start',
              gap: 12,
              flexWrap: 'wrap',
            }}
          >
            <div>
              <h3
                style={{
                  color: '#38bdf8',
                  margin: '0 0 8px',
                }}
              >
                Selected Entity
              </h3>
              <p style={{ color: '#94a3b8', margin: '8px 0' }}>
                🔗 {connectedRelationships.length} connected relationships
                </p>

              <div
                style={{
                  fontSize: 22,
                  fontWeight: 700,
                  overflowWrap: 'anywhere',
                }}
              >
                {selectedNode.data.label}
              </div>

              <p style={{ color: '#94a3b8' }}>
                {prettyLabel(selectedNode.data.category)}
              </p>
            </div>

            <button
              type="button"
              style={BUTTON_STYLE}
              onClick={clearSelection}
            >
              Close Details
            </button>
          </div>

          {/* Severity and confidence */}
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: 12,
              marginBottom: 16,
            }}
          >
            {properties.severity && (
              <div
                style={{
                  padding: '10px 14px',
                  background: '#111827',
                  border: '1px solid #334155',
                  borderRadius: 8,
                }}
              >
                <span style={{ color: '#94a3b8' }}>
                  Severity:{' '}
                </span>
                <strong
                  style={{
                    color: getSeverityColor(
                      properties.severity
                    ),
                    textTransform: 'uppercase',
                  }}
                >
                  {properties.severity}
                </strong>
              </div>
            )}

            {properties.confidence != null && (
              <div
                style={{
                  padding: '10px 14px',
                  background: '#111827',
                  border: '1px solid #334155',
                  borderRadius: 8,
                }}
              >
                <span style={{ color: '#94a3b8' }}>
                  Entity confidence:{' '}
                </span>
                <strong style={{ color: '#38bdf8' }}>
                  {formatConfidence(
                    properties.confidence
                  )}
                </strong>
              </div>
            )}
          </div>



            <h4 style={{ color: '#38bdf8' }}>
            Connected Entities ({connectedRelationships.length})
            </h4>

            <div style={{ display: 'grid', gap: 8, marginBottom: 20 }}>
            {connectedRelationships.length > 0 ? (
                connectedRelationships.map((edge) => {
                const outgoing = edge.source === selectedNode.id

                const otherId = outgoing
                    ? edge.target
                    : edge.source

                const otherNode = nodeLookup.get(otherId)

                return (
                    <button
                    key={edge.id}
                    type="button"
                    onClick={() => {
                        setSelectedNodeId(otherId)
                        setSelectedEdgeId(null)
                    }}
                    style={{
                        ...BUTTON_STYLE,
                        textAlign: 'left',
                        width: '100%',
                        overflowWrap: 'anywhere',
                    }}
                    >
                    <span style={{ color: '#38bdf8' }}>
                        {outgoing ? '→' : '←'}{' '}
                        {edge.data.relationship}
                    </span>

                    <span style={{ marginLeft: 12 }}>
                        {otherNode?.data.label || otherId}
                    </span>
                    </button>
                )
                })
            ) : (
                <p style={{ color: '#94a3b8' }}>
                No connected entities found.
                </p>
            )}
            </div>
            <h4 style={{ color: '#38bdf8' }}>
                Entity Properties
            </h4>


          <div
            style={{
              background: '#111827',
              border: '1px solid #334155',
              borderRadius: 10,
              padding: '8px 16px',
            }}
          >
            {displayedProperties.length ? (
              displayedProperties.map(([key, value]) => (
                <DetailRow
                  key={key}
                  label={key}
                  value={value}
                  color={
                    key === 'severity'
                      ? getSeverityColor(value)
                      : undefined
                  }
                />
              ))
            ) : (
              <p style={{ color: '#94a3b8' }}>
                No additional properties available.
              </p>
            )}
          </div>

          <button
            type="button"
            style={{
              ...BUTTON_STYLE,
              marginTop: 16,
            }}
            onClick={() =>
              setShowTechnical((previous) => !previous)
            }
          >
            {showTechnical
              ? 'Hide Technical Metadata'
              : 'Show Technical Metadata'}
          </button>

          <p
            style={{
              color: '#64748b',
              fontSize: 12,
              marginBottom: 0,
            }}
          >
            These properties come from the Synapt.AI
            knowledge graph. Entity confidence is not
            the same as overall incident-analysis confidence.
          </p>
        </div>
      )}

      {/* Relationship inspection panel */}
      {selectedEdge && (
        <div
          style={{
            ...PANEL_STYLE,
            marginTop: 20,
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              gap: 12,
            }}
          >
            <h3
              style={{
                color: '#38bdf8',
                marginTop: 0,
              }}
            >
              Selected Relationship
            </h3>

            <button
              type="button"
              onClick={clearSelection}
              style={BUTTON_STYLE}
            >
              Close Details
            </button>
          </div>

          <DetailRow
            label="Relationship"
            value={selectedEdge.data.relationship}
          />

          <DetailRow
            label="Source"
            value={
              nodeLookup.get(selectedEdge.source)?.data
                .label || selectedEdge.source
            }
          />

          <DetailRow
            label="Target"
            value={
              nodeLookup.get(selectedEdge.target)?.data
                .label || selectedEdge.target
            }
          />

          {Object.entries(
            selectedEdge.data.properties || {}
          ).map(([key, value]) => (
            <DetailRow
              key={key}
              label={key}
              value={value}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export default KnowledgeGraph
