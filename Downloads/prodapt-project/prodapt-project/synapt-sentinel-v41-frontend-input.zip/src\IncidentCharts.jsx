
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts'

const chartColors = {
  blue: '#60a5fa',
  green: '#34d399',
  orange: '#fbbf24',
  grid: '#334155',
  text: '#cbd5e1',
}

// Shared dark tooltip styling for all three charts.
const tooltipStyle = {
  backgroundColor: '#1e293b',
  border: '1px solid #475569',
  borderRadius: '8px',
  color: '#f8fafc',
}

const tooltipLabelStyle = {
  color: '#f8fafc',
}

const tooltipItemStyle = {
  color: '#f8fafc',
}

const tooltipCursor = {
  fill: 'rgba(148, 163, 184, 0.12)',
}

const chartBox = {
  padding: '20px',
  border: '1px solid #334155',
  borderRadius: '12px',
  background: '#111827',
}

function ChartPanel({ title, description, children }) {
  return (
    <div style={chartBox}>
      <h3 style={{ marginTop: 0 }}>{title}</h3>

      <p style={{ color: '#94a3b8', fontSize: '14px' }}>
        {description}
      </p>

      <div style={{ width: '100%', height: 280 }}>
        {children}
      </div>
    </div>
  )
}

export default function IncidentCharts({ incident }) {
  const flows = Array.isArray(incident?.flows)
    ? incident.flows
    : []

  if (flows.length === 0) {
    return null
  }

  // Destination port counts from sampled flows.
  const portCounts = {}

  flows.forEach((flow) => {
    const port = String(
      flow.destination_port ?? 'Unknown'
    )

    portCounts[port] = (portCounts[port] || 0) + 1
  })

  const portData = Object.entries(portCounts).map(
    ([port, count]) => ({
      port,
      count,
    })
  )

  // Packet totals from sampled flows.
  const totalForward = flows.reduce(
    (sum, flow) =>
      sum + (Number(flow.total_forward_packets) || 0),
    0
  )

  const totalBackward = flows.reduce(
    (sum, flow) =>
      sum + (Number(flow.total_backward_packets) || 0),
    0
  )

  const packetData = [
    {
      direction: 'Forward',
      packets: totalForward,
    },
    {
      direction: 'Backward',
      packets: totalBackward,
    },
  ]

  // CIC-IDS2017 flow durations are in microseconds.
  const durationData = flows.map((flow, index) => ({
    flow: flow.flow_id || `Flow ${index + 1}`,
    seconds:
      (Number(flow.flow_duration) || 0) / 1_000_000,
  }))

  return (
    <section
      style={{
        marginTop: '24px',
        padding: '24px',
        border: '1px solid #334155',
        borderRadius: '12px',
        background: '#0f172a',
        color: '#f8fafc',
      }}
    >
      <h2 style={{ marginTop: 0 }}>
        Incident Visual Analytics
      </h2>

      <p style={{ color: '#94a3b8' }}>
        Visualizations based on {flows.length} sampled
        CIC-IDS2017 network-flow records.
        These charts describe the sample, not the
        entire dataset or a confirmed compromise.
      </p>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns:
            'repeat(auto-fit, minmax(min(100%, 320px), 1fr))',
          gap: '20px',
          marginTop: '20px',
        }}
      >
        {/* CHART 1: Destination Port Distribution */}
        <ChartPanel
          title="Destination Port Distribution"
          description="Number of sampled flows per destination port."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={portData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke={chartColors.grid}
              />

              <XAxis
                dataKey="port"
                stroke={chartColors.text}
              />

              <YAxis
                allowDecimals={false}
                stroke={chartColors.text}
              />

              <Tooltip
                contentStyle={tooltipStyle}
                labelStyle={tooltipLabelStyle}
                itemStyle={tooltipItemStyle}
                cursor={tooltipCursor}
              />

              <Bar
                dataKey="count"
                name="Flows"
                fill={chartColors.blue}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartPanel>

        {/* CHART 2: Packet Direction Comparison */}
        <ChartPanel
          title="Packet Direction Comparison"
          description="Total forward and backward packets across sampled flows."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={packetData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke={chartColors.grid}
              />

              <XAxis
                dataKey="direction"
                stroke={chartColors.text}
              />

              <YAxis
                allowDecimals={false}
                stroke={chartColors.text}
              />

              <Tooltip
                contentStyle={tooltipStyle}
                labelStyle={tooltipLabelStyle}
                itemStyle={tooltipItemStyle}
                cursor={tooltipCursor}
              />

              <Bar
                dataKey="packets"
                name="Packets"
                fill={chartColors.green}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartPanel>

        {/* CHART 3: Flow Duration */}
        <ChartPanel
          title="Flow Duration"
          description="Duration of each sampled flow, converted from microseconds to seconds."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={durationData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke={chartColors.grid}
              />

              <XAxis
                dataKey="flow"
                stroke={chartColors.text}
                tick={{ fontSize: 10 }}
                angle={-35}
                textAnchor="end"
                height={65}
              />

              <YAxis stroke={chartColors.text} />

              <Tooltip
                contentStyle={tooltipStyle}
                labelStyle={tooltipLabelStyle}
                itemStyle={tooltipItemStyle}
                cursor={tooltipCursor}
                formatter={(value) => [
                  `${Number(value).toFixed(6)} seconds`,
                  'Duration',
                ]}
              />

              <Bar
                dataKey="seconds"
                name="Duration (seconds)"
                fill={chartColors.orange}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartPanel>
      </div>
    </section>
  )
}
