# Deferred Synapt.AI ingestion — integration gate

The external Synapt.AI ingestion pipeline previously reported **0 chunks/entities**. This package does NOT pretend to fix or validate the external provider. Local analysis is independent; the external `/api/incidents/analyze` route is gated by `SENTINEL_ENABLE_SYNAPT=1`, and is disabled by default.

After the provider actually ingests data, verify the provider reports >0 indexed chunks and >0 entities, retrieve exact known source text using a unique document identifier, compare cited source IDs to the stored reference, and test negative cases and outages. Only then enable the external route. Keep local retrieval citations and Synapt-origin citations distinguished in UI/results; do not merge ground truth and provider narrative.

Never copy real API keys into the Git repository, screenshots, or this package. The project cannot complete this step until the external service is operational and credentials/network access are available.
