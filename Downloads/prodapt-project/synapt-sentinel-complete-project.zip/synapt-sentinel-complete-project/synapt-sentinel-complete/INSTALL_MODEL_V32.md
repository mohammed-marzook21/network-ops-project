# Synapt Sentinel V3.2 selective review experiment

This package was prepared against the three Python files you supplied. It **adds** `backend/model_v32_escalation.py` and a test; it does not replace V2/V3/V3.1 files or production artifacts.

## 1. Install from the repository root in PowerShell

```powershell
cd C:\Users\mohammed.marzook\Downloads\synapt-sentinel
Expand-Archive -LiteralPath .\synapt-sentinel-model-v32-escalation.zip -DestinationPath . -Force
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests\test_model_v32_escalation.py -q
```

## 2. Run eight held-out capture experiments

```powershell
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\model_v32_escalation.py --csv $csvs --per-class 3000 --benign-cap 5000 --trees 60 --fpr-budget 0.05 --review-budgets 0.01 0.03 0.05
```

## 3. Print the 5% review-budget results

```powershell
$r = Get-Content .\backend\artifacts\model_v32_escalation\evaluation.json -Raw | ConvertFrom-Json
$r.captures | Where-Object { $_.status -eq 'evaluated' } | ForEach-Object {
    $q = $_.review_by_budget.'0.0500'
    [PSCustomObject]@{
        Capture = $_.held_out_capture
        AutomatedRecall = $_.supervised.recall
        AutomatedFPR = $_.supervised.fpr
        AnomalyRescued = $q.anomaly.rescued_attacks
        AnomalyBenignReviews = $q.anomaly.benign_reviews
        SupervisedRescued = $q.supervised.rescued_attacks
        HybridRescued = $q.hybrid.rescued_attacks
    }
} | Format-List
```

## Interpretation

The three review-ranking methods have **the same maximum queue size** and operate only on flows below the supervised alert threshold. `rescued_attacks` counts missed attacks included in a *hypothetical* analyst-review queue, **not** attacks automatically detected or actually confirmed. The simulation assumes perfect retrospective identification of reviewed attacks and uses test labels **only to measure results**, not to choose review ranks or thresholds. Automated FPR is unchanged because review candidates are not automatically labeled malicious. All sampled-flow review yields are prevalence-dependent; this is not a live SOC throughput estimate.

The review capacity is calculated separately for each held-out capture. A live system would need online queue management, streaming score distributions, and analyst outcome feedback. This experiment does **not** implement per-flow explanations or production deployment.
