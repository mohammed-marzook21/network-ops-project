# Synapt Sentinel — Requirements evidence, test plan and limitations

## Status legend

- **Implemented + locally tested**: exercised by automated tests in the supplied build.
- **Implemented, requires local confirmation**: integration exists but depends on model artifacts, CSVs, frontend runtime or credentials not included here.
- **Not independently validated**: functionality exists but external/research validity remains unverified.
- **Deferred**: not implemented or dependent on broken external ingestion.

## Traceability matrix

| Requirement | Implementation / evidence | State | Acceptance check |
|---|---|---|---|
| Dataset audit, 15 labels, CIC-IDS2017 | `model_pipeline.py`, prior V2 audit | Implemented, local dataset excluded | Run `model_pipeline.py` against eight originals |
| Binary intrusion prediction | `model_pipeline.py`, `model_api.py` | Implemented, artifact required | Authenticated POST `/api/models/predict`; untrained = 503 |
| Attack type prediction | Trained ExtraTrees multiclass | Implemented, artifact required | Predictions sourced from model, not incident label |
| Anomaly detector | IsolationForest in model pipeline | Implemented | Return independent anomaly scores, not probabilities |
| Within-corpus report | `artifacts/models/evaluation.json` if supplied | Not portable in ZIP | Confirm artifact JSON and test model identity |
| Unseen attack evaluation | `cross_capture_eval.py`, V3–V3.3, `validation_external.py` | Tested within CIC capture exclusions; independent test pending | Frozen model, unseen independent labeled capture |
| RAG hybrid retrieval | `intelligence.py`, `intelligence_api.py` | Implemented + locally tested | BM25 + TF-IDF/SVD + reciprocal rank fusion search |
| Grounded citations | Retrieval evidence incident IDs in `intelligence.py`, `investigation_api.py` | Implemented | Inspect source incident IDs, no fabricated network metadata |
| Metadata filters | `Filters`, `passes`, `metadata` | Implemented | Nonexistent timestamp/IP filters return no bogus matches |
| Recommendations | `response_engine.py` | Implemented, advisory | Investigation workflow response stage, no containment |
| Multi-agent workflow | `investigation_api.py` wrapping `investigate()` | Implemented + locally tested as **deterministic stages** | Four traceable detection, analysis, risk, response outputs |
| Risk prioritization | `indicators()` local feature heuristics + V2 binary score | Implemented, uncalibrated | Clearly identify heuristic scores vs model scores |
| Per-flow explainability | `explain_api.py` | Implemented + tested with synthetic fixture | Median feature replacement deltas, not SHAP or causal |
| Persistent triage queue | `review_queue.py`, SQLite | Implemented + locally tested | 100 genuine flows → pending items → review |
| Authentication & RBAC | `security_api.py` | Implemented + locally tested for local prototype | 401 anonymous, 403 viewer decision/intake |
| Server-side reviewer identity | `review_queue.py` | Implemented + locally tested | Decision actor drawn from bearer session |
| Rate limiting | In-process sliding window in `security_api.py` | Implemented, single-process only | Excess login/intake requests → 429; use shared proxy limits in production |
| Audit integrity | HMAC chain on new `review_events` | Implemented + locally tested | Alter event details → `audit_integrity: invalid` |
| Prior review history migration | Additive `review_events` columns | Implemented | Previous events remain visible as `legacy_unverified` |
| Feedback loop | `quality_api.py`, `feedback_export.py` | Review feedback persisted/exported; **no auto learning** | Export after analyst decisions; human vet first |
| Real DeepEval | `evaluate_quality.py --deepeval` | **Not run in package** | Configure evaluator + network, retain genuine result logs |
| Real LLM-as-Judge | `POST /api/quality/judge` | **Not run in package** | Configure provider key, authenticate, inspect actual JSON judge scores |
| Frontend five pages | React/Vite `frontend/src/App.jsx` | Existing pages preserved, syntax parsed | `npm ci` then `npm run build`; manually inspect all five |
| Local four-stage AI UI | `LocalInvestigation.jsx` | Implemented, frontend build still to verify | Select dataset case; click Run local investigation |
| Final report | Existing `.md` + PDF endpoints | Implemented in baseline | Download from Reports page |
| End-to-end tests | `tests/test_end_to_end_secure.py` | Implemented + locally tested with mocked model predictions | 43 backend tests passing; real artifact smoke on user's PC |
| Synapt.AI ingestion | Existing client, external gated by env | **Deferred; ingestion broken/unverified** | Nonzero chunks/entities and exact retrieved citations |
| Production SOC deployment | No centralized identity/TLS proxy/secret vault/load-test | **Not done** | External penetration testing and independent calibration |

## Known quantitative findings from prior local experiments

These numbers come from earlier development runs, **not rerun from the source ZIP**, and must not be presented as external deployment estimates:

- V2 within-corpus multiclass macro F1 ≈ 0.8803 and binary ROC-AUC ≈ 0.99946, on sampled duplicate-disjoint rows.
- V2 cross-capture sampled pooled attack recall ≈ **25.3%** across attack-containing excluded captures; Bot recall 0%, PortScan ≈ 0.54%, WebAttacks ≈ 4.22%. Significant capture shift.
- V3 anomaly fusion often selected zero anomaly weight and did **not** improve the supervised detector broadly.
- V3.1 OR anomaly detector recovered some missed attacks but increased false alarms sharply.
- V3.3 supervised 5%-budget review ranking surfaced 1,752 missed attack **samples** with 1,456 benign sample reviews; the 54.6% internal precision is subject to sampled prevalence and leakage through repeated model selection across the same capture family.
- CIC-IDS2017 original CSVs do **not** provide ground-truth IP addresses, event timestamps, or flow IDs. Avoid making up those fields.

## Operationally important limitations

1. **Model accuracy across unseen environments is weak:** the app is an **assisted academic research prototype**, not an autonomous intrusion prevention system.
2. **Calibration:** `intrusion_score` is uncalibrated, not a posterior incident probability or proven risk level. The 5% validation FPR budget has not reliably transferred to held-out captures.
3. **No independent newly collected test:** users need to supply one. `validation_external.py` refuses to silently fit/tune models on evaluation traffic, but cannot verify origin independence.
4. **Deterministic four-stage workflow:** calling stages "agents" is an implementation label, not proof of independently reasoning LLM agents.
5. **Optional real LLM evaluations:** cost, access, network and configured credentials are prerequisites. Not passing or skipping them must be reported plainly.
6. **Security is local-prototype security:** opaque tokens are in sessionStorage (XSS exposure), rate limiting uses process memory (not cluster-wide), no MFA, OS-protected secret vault, TLS termination, centralized authentication or professionally audited access controls.
7. **Audit HMAC chain:** protects against database-only tampering if signing key is protected; admin with access to key and DB can re-sign events. Legacy pre-V4.2 events are unverified.
8. **Feedback is not autonomous retraining:** reviewed exports require explicit data vetting and separate validation.
9. **Review budget is batch-relative:** 100 flows at 5% yields up to 5 entries; small batches can yield none. Do not call these classifications.
10. **Synapt.AI ingestion remains broken:** no backend claim of nonzero ingested chunks/entities. It is disabled by default, and subsequent integration requires external verification.

## What an acceptable final academic demonstration proves

A user can run the application, view authentic local CIC-IDS2017 sample evidence, search historical cases, execute four traceable advisory investigation stages, view the trained model's prediction and sensitivity explanations on actual compatible feature inputs, create a bounded review queue, authenticate, record an inconclusive review decision, verify the event log, export Markdown/PDF reports, and show honest retrieval/model evaluation caveats. If external evaluator credentials or independent captures are absent, those items remain **pending evidence**, not secretly marked complete.

## Suggested test evidence folder (created locally, not bundled)

`backend/artifacts/final_audit.json`, `backend/artifacts/models/evaluation.json`, `backend/artifacts/cross_capture/evaluation.json`, V3–V3.3 JSON results, `deepeval_run.log` after a **real** run, one properly labeled judge response, an external captured holdout provenance note, screenshots of five pages, and output of `python -m pytest backend/tests -q` and `npm run build`.
