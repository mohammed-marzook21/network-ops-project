# Synapt Sentinel V4.1 — Analyst Review frontend

## Scope
Adds an analyst review panel to Incident Explorer (read-only) and Response Center (decision form). Keeps the five existing pages, the V2 model, and all backend endpoints unchanged. Uses GET /api/review/items, GET /api/review/items/{id}, and POST /api/review/items/{id}/decision.

## Installation (PowerShell)
From the Synapt Sentinel project root on the `experiment/model-v3` branch:

```powershell
Copy-Item .\frontend\src\App.jsx .\frontend\src\App.jsx.v40-backup -Force
Expand-Archive -LiteralPath .\synapt-sentinel-v41-frontend.zip -DestinationPath . -Force
cd .\frontend
npm install
npm run build
npm run dev
```

Visit the local Vite URL shown by npm, then open Incident Explorer and Response Center. Pending items are shown only if they have already been created through the V4 `/api/review/intake` endpoint. The Incident Explorer panel is read-only; Response Center allows decisions and displays audit history. Click Refresh after external updates.

## Validation
- Verify the backend is running on http://127.0.0.1:8000 and the V4 endpoints appear at /docs.
- Ensure `VITE_API_BASE_URL` points to the backend if not using the default URL.
- Run `npm run build` and check for errors.
- Create review items via Swagger POST `/api/review/intake` with 100 model-compatible flow records and `review_budget: 0.01`, then inspect the queue. Fewer than 100 flows with a 1% budget creates zero items.
- Submit an analyst decision in Response Center; it should move from Pending to Reviewed and appear in the audit history.

## Security and data integrity
The backend has **no authentication**. Reviewer names are user-entered and not verified. Run locally only; do not expose the API or trust the audit trail as proof of identity. This UI does not invent IP addresses, timestamps, or flow IDs and does not automatically treat the prepared incident catalog as valid model input. Model scores are not calibrated probabilities. No automatic response or containment occurs.

## Rollback
```powershell
Copy-Item .\frontend\src\App.jsx.v40-backup .\frontend\src\App.jsx -Force
Remove-Item .\frontend\src\AnalystReview.jsx, .\frontend\src\AnalystReview.css
```
