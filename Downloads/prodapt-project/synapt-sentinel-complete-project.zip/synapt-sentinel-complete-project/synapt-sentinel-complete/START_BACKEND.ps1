$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$env:PYTHONPATH=(Resolve-Path '.\backend').Path
& '.\backend\.venv\Scripts\python.exe' -m uvicorn main:app --app-dir '.\backend' --host '127.0.0.1' --port 8000 --reload
