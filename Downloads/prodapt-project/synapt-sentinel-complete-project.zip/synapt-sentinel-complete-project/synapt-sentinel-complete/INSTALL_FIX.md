# Synapt Sentinel cross-capture calibration compatibility fix

Extract into the Synapt Sentinel project root, preserving the backend/ directory structure. This replaces only backend/cross_capture_eval.py and adds backend/tests/test_cross_capture_calibration_compat.py. The trained model artifacts and model API are untouched.

From PowerShell at the project root:

```powershell
python -c "import sklearn; print(sklearn.__version__)"
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests -q
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\cross_capture_eval.py --csv $csvs --per-class 3000 --benign-cap 5000 --trees 60
```

Requires scikit-learn >=1.6 with sklearn.frozen.FrozenEstimator. Validation Brier score is calculated on the same data used to fit sigmoid calibration and is NOT an independent calibration assessment. No production model artifacts are replaced.
