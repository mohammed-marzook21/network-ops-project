import { useState } from 'react'
const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000'
export default function LocalInvestigation({ incidentId }) {
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  async function run() {
    if (!incidentId) return
    setError('');setLoading(true);setResult(null)
    try {
      const response = await fetch(`${API_BASE}/api/workflow/incident/${encodeURIComponent(incidentId)}`)
      const body = await response.json()
      if (!response.ok) throw new Error(body.detail || `HTTP ${response.status}`)
      setResult(body)
    } catch (e) { setError(e.message) }
    finally { setLoading(false) }
  }
  return <section className="panel" style={{padding:24, marginBottom:24}} aria-label="Local evidence-grounded investigation">
    <div className="section-heading"><div><span className="eyebrow">OFFLINE / INDEPENDENT OF SYNAPT INGESTION</span><h2>Local four-stage investigation</h2><p>Detection → analysis → risk → response. Deterministic, source-traceable stages; not independently prompted LLM agents.</p></div></div>
    <button className="primary-button" disabled={!incidentId || loading} onClick={run}>{loading ? 'Investigating…' : 'Run local investigation'}</button>
    {error && <p role="alert">{error}</p>}
    {result && <div style={{marginTop:18}}>
      <p><strong>Case:</strong> {result.incident_id} · <strong>Dataset label:</strong> {result.dataset_attack_label}</p>
      <p><strong>Response:</strong> advisory only — no actions executed.</p>
      {(result.workflow?.steps || []).map((step, idx) => <details key={idx} style={{margin:'12px 0'}}><summary>{step.agent?.replaceAll('_',' ')} — {step.status}</summary><pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{JSON.stringify(step.output, null, 2)}</pre></details>)}
      <h3>Supporting historical cases</h3>
      {result.evidence.length ? <ul>{result.evidence.map(source => <li key={source.incident_id}><strong>{source.incident_id}</strong> — {source.attack_type}: {source.summary || 'No summary available'}</li>)}</ul> : <p>No evidence sources matched.</p>}
      <p>Dataset labels are annotations, not proof of compromise. These results do not depend on Synapt.AI ingestion.</p>
    </div>}
  </section>
}
