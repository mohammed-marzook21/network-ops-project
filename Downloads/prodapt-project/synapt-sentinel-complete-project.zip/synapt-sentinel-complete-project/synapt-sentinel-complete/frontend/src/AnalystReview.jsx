import { useCallback, useEffect, useState } from 'react'
import './AnalystReview.css'

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000'
const TOKEN_KEY = 'sentinel.review.session'
const AUTH_EVENT = 'sentinel-auth-change'
const readToken = () => sessionStorage.getItem(TOKEN_KEY) || ''

async function request(path, options = {}, authenticated = true) {
  const token = readToken()
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(authenticated && token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) {
    const err = new Error(typeof body.detail === 'string' ? body.detail : `HTTP ${response.status}`)
    err.status = response.status
    throw err
  }
  return body
}

export default function AnalystReview({ allowDecision = false }) {
  const [token, setToken] = useState(readToken)
  const [user, setUser] = useState(null)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [status, setStatus] = useState('pending')
  const [items, setItems] = useState([])
  const [selected, setSelected] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [decision, setDecision] = useState('inconclusive')
  const [note, setNote] = useState('')

  useEffect(() => {
    const sync = () => { setToken(readToken()); setSelected(null) }
    window.addEventListener(AUTH_EVENT, sync)
    return () => window.removeEventListener(AUTH_EVENT, sync)
  }, [])

  const clearAuth = useCallback(() => {
    sessionStorage.removeItem(TOKEN_KEY)
    setUser(null); setItems([]); setSelected(null); setToken('')
    window.dispatchEvent(new Event(AUTH_EVENT))
  }, [])

  useEffect(() => {
    if (!token) { setUser(null); return }
    let alive = true
    request('/api/auth/me').then(data => { if (alive) setUser(data) })
      .catch(() => { if (alive) clearAuth() })
    return () => { alive = false }
  }, [token, clearAuth])

  const refresh = useCallback(async () => {
    if (!token) return
    setLoading(true); setError('')
    try {
      const data = await request(`/api/review/items?status=${status}&limit=200`)
      setItems(Array.isArray(data.items) ? data.items : [])
    } catch (err) {
      if (err.status === 401) clearAuth()
      setError(err.message)
    } finally { setLoading(false) }
  }, [status, token, clearAuth])

  useEffect(() => { if (token) refresh() }, [token, refresh])

  async function signIn(event) {
    event.preventDefault(); setError('')
    try {
      const data = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }, false)
      sessionStorage.setItem(TOKEN_KEY, data.access_token)
      setPassword(''); setUser(data.user); setToken(data.access_token)
      window.dispatchEvent(new Event(AUTH_EVENT))
    } catch (err) { setError(err.message) }
  }

  async function signOut() {
    try { await request('/api/auth/logout', { method: 'POST' }) } catch { /* local session discarded */ }
    clearAuth()
  }

  async function openItem(id) {
    setError(''); setNotice('')
    try { setSelected(await request(`/api/review/items/${encodeURIComponent(id)}`)) }
    catch (err) { setError(err.message) }
  }

  async function submit(event) {
    event.preventDefault()
    if (!selected || !user || user.role === 'viewer') return
    setSaving(true); setError(''); setNotice('')
    try {
      await request(`/api/review/items/${encodeURIComponent(selected.item.id)}/decision`, {
        method: 'POST', body: JSON.stringify({ decision, note }),
      })
      setNotice(`Decision recorded as ${user.username}.`)
      setSelected(null); setNote(''); await refresh()
    } catch (err) { setError(err.message) }
    finally { setSaving(false) }
  }

  return <section className="review-panel" aria-label="Analyst review queue">
    <div className="review-heading"><div><span className="review-kicker">HUMAN-IN-THE-LOOP TRIAGE</span><h2>Needs Review</h2><p>Unflagged flows ranked by supervised risk score. Review entries are not confirmed attacks.</p></div>
      {token ? <button className="outline-button" type="button" onClick={refresh} disabled={loading}>{loading ? 'Loading…' : 'Refresh queue'}</button> : null}
    </div>
    {!token && <form className="review-form review-login" onSubmit={signIn}>
      <h3>Analyst sign in</h3><p>Only authenticated users may inspect review evidence or record decisions.</p>
      <label>Username <input autoComplete="username" required minLength={3} value={username} onChange={e => setUsername(e.target.value)} /></label>
      <label>Password <input autoComplete="current-password" required type="password" value={password} onChange={e => setPassword(e.target.value)} /></label>
      <button className="primary-button" type="submit">Sign in</button>
    </form>}
    {error && <p role="alert" className="review-error">{error}</p>}{notice && <p role="status" className="review-notice">{notice}</p>}
    {token && <>
      <div className="review-toolbar"><label htmlFor={`review-filter-${allowDecision}`}>Show</label>
        <select id={`review-filter-${allowDecision}`} value={status} onChange={e => { setStatus(e.target.value); setSelected(null) }}>
          <option value="pending">Pending</option><option value="reviewed">Reviewed</option><option value="all">All</option>
        </select><span>{items.length} items (up to 200)</span><span className="review-identity">{user ? `${user.username} · ${user.role}` : 'Checking session…'}</span>
        <button className="outline-button" type="button" onClick={signOut}>Sign out</button>
      </div>
      {!loading && items.length === 0 && <p className="review-empty">No review items found. Use POST /api/review/intake with real model-compatible flow features. Incident catalog rows are not automatically imported.</p>}
      {items.length > 0 && <div className="review-table-wrap"><table className="review-table"><thead><tr><th>Item</th><th>Score</th><th>Predicted type</th><th>Status</th><th>Action</th></tr></thead><tbody>
        {items.map(item => <tr key={item.id}><td title={item.id}>{item.id.slice(0, 8)}…</td><td>{Number.isFinite(Number(item.score)) ? Number(item.score).toFixed(3) : '—'}</td><td>{item.attack_type || '—'}</td><td>{item.status}</td><td><button type="button" className="outline-button" onClick={() => openItem(item.id)}>Inspect</button></td></tr>)}
      </tbody></table></div>}
      {selected && <div className="review-detail"><h3>Review evidence</h3><p><strong>Review ID:</strong> <code>{selected.item.id}</code></p><p><strong>Model score:</strong> {Number(selected.item.score).toFixed(4)} — not a calibrated probability</p><p><strong>Model attack type:</strong> {selected.item.attack_type}</p><p><strong>Status:</strong> {selected.item.status}</p>
        <p><strong>Audit integrity:</strong> {selected.audit_integrity === 'verified' ? 'Signed event chain verified' : selected.audit_integrity === 'legacy_unverified' ? 'Legacy events — integrity not established' : selected.audit_integrity}</p>
        <details><summary>Submitted flow features</summary><pre>{JSON.stringify(selected.item.features, null, 2)}</pre></details><h4>Audit history</h4><ol>{(selected.events || []).map((entry, index) => <li key={index}>{entry.created_at} — {entry.event} ({entry.actor}){entry.details?.decision ? `: ${entry.details.decision}` : ''}</li>)}</ol>
        {allowDecision && selected.item.status === 'pending' && user?.role !== 'viewer' && <form onSubmit={submit} className="review-form"><p>Authenticated reviewer: <strong>{user?.username}</strong></p>
          <label>Decision <select value={decision} onChange={e => setDecision(e.target.value)}><option value="inconclusive">Inconclusive</option><option value="confirmed_attack">Confirmed attack</option><option value="benign">Benign</option></select></label>
          <label>Evidence / notes <textarea value={note} maxLength={2000} onChange={e => setNote(e.target.value)} rows={3}/></label>
          <button className="primary-button" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Record decision'}</button></form>}
        {!allowDecision && <p>Open Response Center to record an analyst decision.</p>}
        {user?.role === 'viewer' && <p>Viewer role: read-only access.</p>}
      </div>}
    </>}
    <p className="review-warning">Local evaluation prototype. Use TLS and an external identity provider before a public or multi-user deployment. No automatic containment.</p>
  </section>
}
