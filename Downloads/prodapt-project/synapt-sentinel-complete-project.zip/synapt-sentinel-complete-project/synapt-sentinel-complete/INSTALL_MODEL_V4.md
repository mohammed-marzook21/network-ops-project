# Synapt Sentinel V4 — Review queue installation (Windows PowerShell)

Run from your Synapt Sentinel repository root, on `experiment/model-v3`, with your existing Python 3.11 virtual environment active.

## Install

Extract the package at the project root (not inside `backend`):

```powershell
Expand-Archive -LiteralPath .\synapt-sentinel-v4-review-queue.zip -DestinationPath . -Force
```

Add these two lines to `backend/main.py` **once** (do not replace the existing file):

```python
from review_queue import router as review_router
app.include_router(review_router)
```

Place the `app.include_router(review_router)` line **after** `app = FastAPI(...)` has been created. The import may go with other imports near the top.

## Test

```powershell
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests\test_review_queue.py -q
```

## Start

Restart the FastAPI backend. The new endpoints appear at `http://127.0.0.1:8000/docs` if your backend runs on port 8000.

* `POST /api/review/intake`: score 1–100 supplied feature dictionaries using the existing V2 model and queue a fraction of **unflagged** flows.
* `GET /api/review/items?status=pending`: list queue.
* `GET /api/review/items/{id}`: details and audit events.
* `POST /api/review/items/{id}/decision`: analyst decision.

Sample `POST /api/review/items/{id}/decision` body:

```json
{"reviewer":"analyst-1","decision":"inconclusive","note":"Needs investigation"}
```

The review budget uses `floor(batch_size * review_budget)`. At 1% and fewer than 100 flows per request, zero items are queued. This avoids silently exceeding the budget. For small live batches, a **future** queue scheduler should accumulate flows across batches; do not raise the quota ad hoc.

Database location: `backend/artifacts/review_queue.sqlite3` (or `SENTINEL_REVIEW_DB`). Keep the DB out of Git and back it up if decisions matter.

**Security limitations:** This is a local development prototype, not a production deployment. There is no authentication or authorization, the `reviewer` field is user-supplied, and feature dictionaries are stored in SQLite. Restrict API access to trusted local users. Add authentication, role-based access, retention controls, and authenticated audit identity before deployment. No network IPs or timestamps are synthesized. The model artifact must exist; no fallback to ground-truth labels. No external Synapt.AI ingestion is involved. No frontend files are modified.
