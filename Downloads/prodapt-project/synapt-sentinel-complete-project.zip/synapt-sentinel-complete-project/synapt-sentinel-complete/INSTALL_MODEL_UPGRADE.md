# Synapt Sentinel — model-training upgrade

## Scope
This replaces only `backend/model_pipeline.py` and adds `backend/tests/test_model_pipeline_v2.py`. It does **not** replace the existing API, frontend, ingestion pipeline, or trained models. No model has been trained on your local CIC-IDS2017 files by this package.

## Installation (PowerShell, from project root)

1. Stop backend and create a Git checkpoint: `git status --short`; `git branch backup/before-model-v2`.
2. Extract this ZIP into the **project root** with `Expand-Archive -LiteralPath .\synapt-sentinel-model-upgrade.zip -DestinationPath . -Force`.
3. Activate your existing virtual environment and run:

```powershell
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest backend/tests -q
```

The package includes the updated existing `test_intelligence.py` because the previous test assumed a four-capture minimum. The new pipeline permits a single CSV for **within-corpus** evaluation; this does not provide independent-capture validation.

## Training — conservative first run

Run from project root; this finds only the eight main capture CSVs (not Python package test CSVs):

```powershell
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\model_pipeline.py --csv $csvs --per-class 5000 --benign-cap 15000 --trees 60
```

The script reads CSVs in chunks, samples per label, removes identical feature vectors across partitions, trains multiclass and binary ExtraTrees models plus benign-only Isolation Forest, and writes:

- `backend/artifacts/models/models.joblib` (local model; never deserialize untrusted artifacts)
- `backend/artifacts/models/evaluation.json` (metrics, split audit, and limitations)

Check `evaluation.json` before trusting any prediction. For a larger second run, use `--per-class 20000 --benign-cap 50000 --trees 120`. Expect substantial runtime and memory use; stop if the machine is swapping.

## API integration

Existing `/api/models/predict` loads `backend/artifacts/models/models.joblib` on first use. Restart FastAPI after training. Predictions now include `intrusion_score`, which is **not calibrated**, and `predicted_intrusion` at a validation-selected threshold. Anomaly scores are also not probabilities. Never automatically block traffic based on these predictions.

## Scientific limitations

- The 70/15/15 partition is **within-corpus**; it does not establish generalization to independent captures or unseen campaigns.
- Exact duplicate feature vectors are kept in one partition and collapsed, but near-duplicate and temporal correlations remain possible.
- Rare labels (e.g. 11 Heartbleed flows) cannot support strong per-class performance claims.
- No IPs, timestamps, or flow IDs are available in these CSVs. Do not invent them.
- Synapt ingestion remains untouched.
- Model evaluation and retraining feedback loops require further independent validation.
