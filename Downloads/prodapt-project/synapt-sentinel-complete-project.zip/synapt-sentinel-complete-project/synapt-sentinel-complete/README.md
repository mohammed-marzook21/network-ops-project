# Synapt Sentinel — Integrated End-to-End Research Prototype

This source package assembles the working React/Vite five-page frontend, FastAPI backend, CIC-IDS2017 local incident samples, V2 supervised/anomaly model integration, hybrid BM25+LSA retrieval, four deterministic investigation stages, authenticated analyst review, sensitivity explanations, feedback export, optional real DeepEval/LLM-as-Judge entry points, and repeatable validation/tests.

**Status:** Backend test suite passed locally (43 tests). Frontend JSX parsed without syntax errors, but a full Vite build was **not verified in the packaging environment** because npm dependency installation could not complete. Re-run `npm ci; npm run build` on Windows. This is a research/academic prototype, not a production SOC service.

**Not included:** original eight CIC-IDS2017 CSVs (~2.8 million rows), the evaluated production `models.joblib` artifact, locally stored analyst decisions, `.env`, passwords, OpenAI/DeepEval credentials, or verified Synapt.AI ingestion. Transfer your own original local artifacts separately; do not run untrusted joblib files.

## Start here

For the fastest setup, open PowerShell in the extracted folder and run `powershell -ExecutionPolicy Bypass -File .\SETUP_AND_VERIFY.ps1` after reviewing the script. Then start `START_BACKEND.ps1` and `START_FRONTEND.ps1` in separate terminals. For full control, read [INSTALL_WINDOWS_END_TO_END.md](INSTALL_WINDOWS_END_TO_END.md) and [PROJECT_REQUIREMENTS_AND_LIMITATIONS.md](PROJECT_REQUIREMENTS_AND_LIMITATIONS.md). The cleanest approach is extracting this archive into a **new directory** and copying your existing trusted trained model and CSV data into it, rather than overwriting your working Git branch.

## Core endpoints

| Endpoint | Function |
|---|---|
| `GET /api/incidents/dataset` | Local incident catalog |
| `POST /api/intelligence/search` | BM25 + LSA retrieval with incident evidence IDs |
| `GET /api/workflow/incident/{id}` | Detection → analysis → risk → response; no Synapt dependency |
| `POST /api/auth/login` | Local user authentication, bearer session |
| `GET /api/auth/me` | Identify server-authenticated analyst |
| `POST /api/review/intake` | Model-based review ranking (analyst/admin) |
| `GET /api/review/items` | Review queue (authenticated) |
| `POST /api/review/items/{id}/decision` | Server-attributed analyst decision |
| `POST /api/models/predict` | Evaluated V2 artifact prediction (analyst/admin) |
| `POST /api/models/explain` | Local feature sensitivity (analyst/admin) |
| `POST /api/quality/feedback` | Persistent, authenticated feedback, no auto retraining |
| `POST /api/quality/judge` | Real opt-in LLM-as-Judge with a configured key (analyst/admin) |
| `GET /api/incidents/dataset/{id}/report/pdf` | Offline local incident report |

## Architecture

```mermaid
flowchart LR
    React[React + Vite: five pages] --> FastAPI[FastAPI backend]
    FastAPI --> CIC[Local CIC-IDS2017 incident summaries]
    FastAPI --> RAG[BM25 + LSA historical retrieval]
    RAG --> Stages[Deterministic detection → analysis → risk → response]
    FastAPI --> Model[Trusted V2 joblib model]
    Model --> Queue[Authenticated SQLite review queue]
    Queue --> Audit[HMAC-chain audit events]
    Queue --> Feedback[Offline analyst feedback export]
    Synapt[Synapt.AI: unverified ingestion] -. opt-in, future .-> FastAPI
```

**Important:** CIC-IDS2017 CSVs have traffic features and labels, not verified flow IDs, source/destination IPs, or timestamps. Sample incident IDs in local JSON are internal dataset sample identifiers, not original network flow IDs. Dataset labels are not independent predictions.

## Evaluation rule

No deployment-level model recall or precision claims should be inferred from within-corpus evaluation. Cross-capture results previously showed major misses on PortScan and Bot. External, *genuinely independent* capture validation is still necessary before any deployment claim. Optional paid LLM tests do not return fabricated pass results when keys or network access are missing.
