# Synapt Sentinel V4.1 UI polish (Windows PowerShell)

## Scope
Moves the Needs Review panel directly below the Incident Explorer and Response Center page headings; applies dark, high-contrast native select options and visible keyboard focus. Does not modify the backend, prediction model, or analyst decisions.

## Install
From the project root, back up your current App.jsx and AnalystReview.css:

```powershell
Copy-Item .\frontend\src\App.jsx .\frontend\src\App.jsx.before-v41-polish -Force
Copy-Item .\frontend\src\AnalystReview.css .\frontend\src\AnalystReview.css.before-v41-polish -Force
Expand-Archive -LiteralPath .\synapt-sentinel-v41-ui-polish.zip -DestinationPath . -Force
cd .\frontend
npm run build
npm run dev
```

## Verify
On both pages the page heading appears first, then Needs Review. Open Pending / Reviewed / All, the case selector, and attack-type filter. Verify readable dark options and keyboard focus (Tab). Native dropdown popup appearance can still vary by browser/OS. Confirm review actions and audit history continue working.

## Rollback
```powershell
Copy-Item .\src\App.jsx.before-v41-polish .\src\App.jsx -Force
Copy-Item .\src\AnalystReview.css.before-v41-polish .\src\AnalystReview.css -Force
Remove-Item .\src\SelectTheme.css
```
