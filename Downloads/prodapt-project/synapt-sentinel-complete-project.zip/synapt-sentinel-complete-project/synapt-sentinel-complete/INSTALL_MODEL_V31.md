# Synapt Sentinel — Model V3.1 diagnostics

Run from your existing PowerShell virtual environment at the project root on branch `experiment/model-v3`.

## Install

Place the ZIP in the project root, then:

```powershell
Expand-Archive -LiteralPath .\synapt-sentinel-model-v31-diagnostics.zip -DestinationPath . -Force
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests\test_model_v31_diagnostics.py -q
```

## Evaluate all eight captures

```powershell
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\model_v31_diagnostics.py --csv $csvs --per-class 3000 --benign-cap 5000 --trees 60 --fpr-budget 0.05
```

## Inspect attack-family failures

```powershell
$r = Get-Content .\backend\artifacts\model_v31_diagnostics\evaluation.json -Raw | ConvertFrom-Json
foreach ($c in $r.captures) {
  if ($c.status -ne 'evaluated') { continue }
  Write-Host "`n$($c.held_out_capture) | OR FPR: $($c.or_rule.fpr) | Rescued: $($c.rescued_missed_attacks_by_anomaly)"
  $c.supervised_by_label.PSObject.Properties | Where-Object Name -ne 'BENIGN' | ForEach-Object {
    $label = $_.Name
    [PSCustomObject]@{Label=$label; Rows=$_.Value.rows; SupervisedRecall=$_.Value.flag_rate; AnomalyRecall=$c.anomaly_by_label.$label.flag_rate; ORRecall=$c.or_by_label.$label.flag_rate; Unseen=$_.Value.unseen_in_training}
  } | Format-Table -AutoSize
}
```

The OR rule flags a flow if **either** supervised or anomaly detection flags it. This is an intentionally aggressive *diagnostic*; its held-out FPR can exceed 5%. It must not be deployed without independent validation. `evaluation.json` contains the exact counts, per-label score distributions, and thresholds.

This experiment never modifies `backend/model_api.py`, the production model artifact, or V3's results. Do not claim that results are improved until comparing held-out attack recall **and** held-out FPR.
