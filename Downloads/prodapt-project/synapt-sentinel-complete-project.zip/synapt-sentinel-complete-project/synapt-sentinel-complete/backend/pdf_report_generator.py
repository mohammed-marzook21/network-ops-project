
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    HRFlowable,
)

from report_generator import generate_incident_report


def generate_pdf_report(
    incident,
    local_analysis,
    response_recommendations,
):
    """
    Generate a PDF from the existing Markdown incident report.

    Returns PDF bytes without saving a file to disk.
    No Synapt.AI calls or containment actions occur.
    """

    markdown_report = generate_incident_report(
        incident,
        local_analysis,
        response_recommendations,
    )

    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=45,
        leftMargin=45,
        topMargin=50,
        bottomMargin=50,
        title="Synapt Sentinel Incident Investigation Report",
        author="Synapt Sentinel",
    )

    styles = getSampleStyleSheet()

    styles.add(
        ParagraphStyle(
            name="SentinelTitle",
            parent=styles["Title"],
            fontSize=18,
            leading=24,
            textColor=colors.HexColor("#17365D"),
            alignment=TA_CENTER,
            spaceAfter=18,
        )
    )

    styles.add(
        ParagraphStyle(
            name="SentinelHeading",
            parent=styles["Heading2"],
            fontSize=12,
            leading=16,
            textColor=colors.HexColor("#1D4ED8"),
            spaceBefore=15,
            spaceAfter=8,
        )
    )

    styles.add(
        ParagraphStyle(
            name="SentinelBody",
            parent=styles["BodyText"],
            fontSize=9,
            leading=14,
            spaceAfter=6,
        )
    )

    styles.add(
        ParagraphStyle(
            name="SentinelBullet",
            parent=styles["BodyText"],
            fontSize=9,
            leading=14,
            leftIndent=15,
            firstLineIndent=-10,
            spaceAfter=5,
        )
    )

    story = []

    for raw_line in markdown_report.splitlines():
        line = raw_line.strip()

        if not line:
            story.append(Spacer(1, 6))
            continue

        if line.startswith("# "):
            story.append(
                Paragraph(
                    escape(line[2:]),
                    styles["SentinelTitle"],
                )
            )
            story.append(
                HRFlowable(
                    width="100%",
                    thickness=1,
                    color=colors.HexColor("#CBD5E1"),
                )
            )

        elif line.startswith("## "):
            story.append(
                Paragraph(
                    escape(line[3:]),
                    styles["SentinelHeading"],
                )
            )

        elif line.startswith("### "):
            story.append(
                Paragraph(
                    escape(line[4:]),
                    styles["Heading3"],
                )
            )

        elif line.startswith("- "):
            story.append(
                Paragraph(
                    "&#8226; " + escape(line[2:]),
                    styles["SentinelBullet"],
                )
            )

        elif (
            len(line) > 2
            and line[0].isdigit()
            and ". " in line[:5]
        ):
            story.append(
                Paragraph(
                    escape(line),
                    styles["SentinelBullet"],
                )
            )

        else:
            safe_text = escape(line)

            # Render Markdown bold labels.
            parts = safe_text.split("**")

            if len(parts) > 1:
                safe_text = "".join(
                    f"<b>{part}</b>" if index % 2 else part
                    for index, part in enumerate(parts)
                )

            story.append(
                Paragraph(
                    safe_text,
                    styles["SentinelBody"],
                )
            )

    def add_page_number(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.grey)

        canvas.drawRightString(
            A4[0] - 45,
            28,
            f"Page {doc.page}",
        )

        canvas.drawString(
            45,
            28,
            "Synapt Sentinel | Local Investigation Report",
        )

        canvas.restoreState()

    document.build(
        story,
        onFirstPage=add_page_number,
        onLaterPages=add_page_number,
    )

    pdf_bytes = buffer.getvalue()
    buffer.close()

    return pdf_bytes
