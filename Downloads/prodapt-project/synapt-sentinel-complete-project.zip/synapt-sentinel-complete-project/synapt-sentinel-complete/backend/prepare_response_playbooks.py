
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"
OUTPUT = DATA_DIR / "incident_response_playbooks.md"

PLAYBOOKS = [
    {
        "name": "Credential Brute Force",
        "labels": [
            "SSH-Patator",
            "FTP-Patator",
            "Web Attack - Brute Force",
        ],
        "investigate": [
            "Identify affected authentication services.",
            "Review login success and failure logs.",
            "Correlate timestamps and account activity.",
            "Check whether any authentication succeeded.",
        ],
        "contain": [
            "Consider rate limiting or temporary access restrictions.",
            "Review account lockout and MFA controls.",
            "Require analyst approval before blocking IP addresses.",
        ],
        "recover": [
            "Reset affected credentials if compromise is confirmed.",
            "Review exposed services and authentication policies.",
            "Monitor for recurring authentication attempts.",
        ],
    },
    {
        "name": "Denial of Service",
        "labels": [
            "DDoS",
            "DoS GoldenEye",
            "DoS Hulk",
            "DoS Slowhttptest",
            "DoS slowloris",
        ],
        "investigate": [
            "Review traffic rates and connection patterns.",
            "Check service health and resource utilization.",
            "Determine whether service availability was affected.",
        ],
        "contain": [
            "Consider rate limiting and traffic filtering.",
            "Review CDN, WAF, and upstream protection options.",
            "Require approval before disruptive network changes.",
        ],
        "recover": [
            "Verify service availability and performance.",
            "Review capacity and protection configurations.",
            "Continue monitoring for renewed traffic spikes.",
        ],
    },
    {
        "name": "Network Reconnaissance",
        "labels": ["PortScan"],
        "investigate": [
            "Review destination port patterns.",
            "Correlate network flows with firewall logs.",
            "Identify exposed services where evidence permits.",
        ],
        "contain": [
            "Review unnecessary exposed ports.",
            "Consider access-control adjustments after validation.",
        ],
        "recover": [
            "Confirm required services remain accessible.",
            "Monitor for subsequent exploitation attempts.",
        ],
    },
    {
        "name": "Web Application Attack",
        "labels": [
            "Web Attack - Sql Injection",
            "Web Attack - XSS",
        ],
        "investigate": [
            "Review application, web server, and WAF logs.",
            "Identify suspicious requests and application errors.",
            "Check for evidence of successful exploitation.",
        ],
        "contain": [
            "Consider validated WAF rules.",
            "Review vulnerable application endpoints.",
            "Require approval before production configuration changes.",
        ],
        "recover": [
            "Patch confirmed vulnerabilities.",
            "Validate fixes through authorized security testing.",
            "Monitor for repeated exploitation attempts.",
        ],
    },
    {
        "name": "Potential Compromise or Exploitation",
        "labels": [
            "Bot",
            "Heartbleed",
            "Infiltration",
        ],
        "investigate": [
            "Review relevant host, application, and network logs.",
            "Determine whether compromise or exploitation occurred.",
            "Identify affected assets using corroborating evidence.",
        ],
        "contain": [
            "Consider host isolation only after analyst review.",
            "Preserve relevant forensic evidence.",
            "Avoid destructive or automated containment.",
        ],
        "recover": [
            "Remediate confirmed vulnerabilities or persistence.",
            "Restore affected systems using approved procedures.",
            "Validate system integrity and continue monitoring.",
        ],
    },
]

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    lines = [
        "# Synapt Sentinel - Incident Response Playbooks",
        "",
        "These playbooks provide general defensive guidance.",
        "CIC-IDS2017 labels alone do not prove compromise,",
        "successful exploitation, or service disruption.",
        "No containment action is automatically authorized.",
        "",
    ]

    for playbook in PLAYBOOKS:
        lines.extend([
            f"## {playbook['name']}",
            "",
            "### Related Dataset Labels",
            "",
        ])

        for label in playbook["labels"]:
            lines.append(f"- {label}")

        for heading, key in [
            ("Investigation", "investigate"),
            ("Containment Recommendations", "contain"),
            ("Recovery and Validation", "recover"),
        ]:
            lines.extend(["", f"### {heading}", ""])

            for step in playbook[key]:
                lines.append(f"- {step}")

        lines.extend(["", "---", ""])

    OUTPUT.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    print("Incident response playbooks generated.")
    print(f"Playbooks included: {len(PLAYBOOKS)}")
    print(f"Output: {OUTPUT}")
    print(f"Size: {OUTPUT.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
