"""Run once locally: python bootstrap_admin.py --username admin"""
import argparse
from getpass import getpass
from security_api import create_user

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--username', default='admin')
    args = parser.parse_args()
    password = getpass('New admin password (12+ characters): ')
    confirm = getpass('Confirm password: ')
    if password != confirm:
        raise SystemExit('Passwords did not match')
    create_user(args.username, password, 'admin')
    print('Admin account created. Credentials are not stored in the source code.')
