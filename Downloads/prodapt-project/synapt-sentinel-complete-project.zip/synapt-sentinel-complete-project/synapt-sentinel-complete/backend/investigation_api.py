"""End-to-end evidence-grounded local investigation, independent of Synapt.AI.

These are separate deterministic agents/stages; they are not independent LLM
personas. A dataset label is never promoted to a trained prediction.
"""
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from intelligence import investigate, indicators, document
from intelligence_api import index

router = APIRouter(prefix='/api/workflow', tags=['Investigation workflow'])


@router.get('/incident/{incident_id}')
def incident_workflow(incident_id: str):
    catalog = index()
    item = next((x for x in catalog.incidents if x['incident_id'] == incident_id), None)
    if item is None:
        raise HTTPException(404, 'Incident not found')
    evaluation = investigate(item, catalog)
    retrieval = catalog.search(document(item), top_k=5, exclude_id=incident_id)
    # Only claim evidence that corresponds to a real, retrievable local record.
    ids = {x['incident_id'] for x in catalog.incidents}
    sources = [{'incident_id': r['incident_id'], 'attack_type': r['attack_type'],
                'summary': r['evidence']['summary'], 'score': r['score'],
                'origin':'local_incident'} for r in retrieval if r['incident_id'] in ids]
    return {'success':True, 'provider':'local', 'incident_id':incident_id,
            'dataset_attack_label':item.get('attack_type'),
            'dataset_label_is_prediction':False,
            'workflow':evaluation, 'evidence':sources,
            'retrieval':'bm25_lsa_reciprocal_rank_fusion',
            'execution_status':'not_executed', 'synapt_ingestion_required':False,
            'limitations':['Deterministic stage orchestration, not four independently prompted LLM agents',
                           'Historical matches support investigation; they do not establish intrusion',
                           'Samples omit actual source/destination IPs and timestamps']}


@router.get('/readiness')
def readiness():
    catalog = index()
    return {'local_investigation':'available' if catalog.incidents else 'no_local_incidents',
            'indexed_incidents':len(catalog.incidents),
            'synapt_ingestion':'not_verified_external_dependency',
            'automatic_containment':False,
            'multi_agent_implementation':'deterministic_detection_analysis_risk_response_stages'}
