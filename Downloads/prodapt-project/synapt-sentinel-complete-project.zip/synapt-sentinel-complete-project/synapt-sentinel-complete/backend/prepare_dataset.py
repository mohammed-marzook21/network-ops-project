
import csv
import json
import re
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"
SAMPLE_SIZE = 10

# Exclude previously generated sample CSVs.
DATASET_FILES = [
    path for path in DATA_DIR.glob("*.csv")
    if not path.name.endswith("_sample.csv")
]


def safe_name(label):
    return re.sub(
        r"[^a-z0-9]+", "_", label.lower()
    ).strip("_")


def get_value(row, column):
    return (row.get(column) or "").strip()
def normalize_label(label):
    label = label.replace("\uFFFD", "-")
    label = label.replace("\u00ef\u00bf\u00bd", "-")
    return " ".join(label.split())


def main():
    samples = {}

    for csv_file in sorted(DATASET_FILES):
        print(f"Reading: {csv_file.name}")

        with csv_file.open(
            "r", encoding="utf-8-sig", errors="replace", newline=""
        ) as file:
            reader = csv.DictReader(file)

            for row in reader:
                row = {
                    key.strip(): value
                    for key, value in row.items()
                    if key is not None
                }

                label = normalize_label(get_value(row, "Label"))

                if not label or label.upper() == "BENIGN":
                    continue

                if label not in samples:
                    samples[label] = {
                        "source_file": csv_file.name,
                        "flows": []
                    }

                if len(samples[label]["flows"]) >= SAMPLE_SIZE:
                    continue

                index = len(samples[label]["flows"]) + 1

                samples[label]["flows"].append({
                    "flow_id": f"FLOW-{index:03d}",
                    "destination_port": get_value(
                        row, "Destination Port"
                    ),
                    "flow_duration": get_value(
                        row, "Flow Duration"
                    ),
                    "total_forward_packets": get_value(
                        row, "Total Fwd Packets"
                    ),
                    "total_backward_packets": get_value(
                        row, "Total Backward Packets"
                    ),
                    "label": label
                })



    if not samples:
        print("No attack records found.")
        return

    output_dir = DATA_DIR / "generated_incidents"
    output_dir.mkdir(exist_ok=True)

    for number, (label, sample) in enumerate(
        sorted(samples.items()), start=1
    ):
        incident_id = f"CIC-AUTO-{number:03d}"

        incident = {
            "incident_id": incident_id,
            "source": "CIC-IDS2017",
            "source_file": sample["source_file"],
            "attack_type": label,
            "record_count": len(sample["flows"]),
            "dataset_labels": [label],
            "severity": "unassessed",
            "analysis_status": "pending",
            "summary": (
                f"A sample of network-flow records "
                f"labeled {label} in the CIC-IDS2017 dataset."
            ),
            "flows": sample["flows"]
        }

        filename = (
            f"{safe_name(label)}_incident.json"
        )

        output_file = output_dir / filename

        with output_file.open(
            "w", encoding="utf-8"
        ) as file:
            json.dump(incident, file, indent=2)

        print(
            f"{incident_id}: {label} "
            f"({len(sample['flows'])} flows)"
        )

    print(
        f"\nGenerated {len(samples)} incident files in:"
    )
    print(output_dir)


if __name__ == "__main__":
    main()
