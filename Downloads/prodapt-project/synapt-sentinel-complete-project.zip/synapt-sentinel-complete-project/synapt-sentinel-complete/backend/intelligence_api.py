"""Versioned local-intelligence API, independent of Synapt health."""
from __future__ import annotations
from functools import lru_cache
from ipaddress import ip_address
from pathlib import Path
import re
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field, field_validator

from intelligence import HybridIndex, load_incidents, passes, indicators, investigate, classify

router = APIRouter(prefix='/api/intelligence',tags=['Local intelligence'])
DATA = Path(__file__).resolve().parent / 'data'


def incident_paths() -> dict[str,Path]:
    paths = {'CIC-SSH-001':DATA/'cic_ssh_incident.json', 'CIC-FTP-001':DATA/'cic_ftp_incident.json'}
    for file in sorted((DATA/'generated_incidents').glob('*_incident.json')):
        try:
            import json
            d = json.loads(file.read_text(encoding='utf-8'))
            if re.fullmatch(r'CIC-AUTO-\d+',str(d.get('incident_id',''))): paths[d['incident_id']]=file
        except (OSError,ValueError): continue
    return paths


def index() -> HybridIndex:
    return HybridIndex(load_incidents(incident_paths()))


def get_item(incident_id: str) -> dict:
    for item in index().incidents:
        if item['incident_id'] == incident_id: return item
    raise HTTPException(404,'Dataset incident not found')


class Filters(BaseModel):
    attack_type: str | None = Field(default=None,max_length=100)
    protocol: str | None = Field(default=None,max_length=20)
    source_ip: str | None = None
    destination_ip: str | None = None
    destination_port: int | None = Field(default=None,ge=0,le=65535)
    start_time: str | None = Field(default=None,max_length=40)
    end_time: str | None = Field(default=None,max_length=40)

    @field_validator('source_ip','destination_ip')
    @classmethod
    def validate_ips(cls,v):
        if v is not None: ip_address(v)
        return v


class SearchRequest(Filters):
    query: str = Field(min_length=2,max_length=600)
    top_k: int = Field(default=5,ge=1,le=25)
    exclude_id: str | None = Field(default=None,max_length=80)

    @field_validator('query')
    @classmethod
    def meaningful(cls,v):
        if not v.strip(): raise ValueError('Query cannot be blank')
        return v.strip()


@router.post('/search')
def search(req:SearchRequest):
    results=index().search(req.query,req.model_dump(exclude={'query','top_k','exclude_id'},exclude_none=True),req.top_k,req.exclude_id)
    return {'success':True,'method':'bm25_plus_lsa_rrf','retrieval_backend':'local',
            'count':len(results),'results':results,
            'note':'LSA vectors are corpus-trained latent semantic representations, not pretrained sentence embeddings.'}


@router.get('/metadata')
def list_metadata(attack_type:str|None=None, protocol:str|None=None,
                  source_ip:str|None=None,destination_ip:str|None=None,
                  destination_port:Annotated[int|None,Query(ge=0,le=65535)]=None,
                  start_time:str|None=None,end_time:str|None=None):
    try: filters=Filters(attack_type=attack_type,protocol=protocol,source_ip=source_ip,
                        destination_ip=destination_ip,destination_port=destination_port,
                        start_time=start_time,end_time=end_time)
    except ValueError as e: raise HTTPException(422,str(e))
    from intelligence import metadata
    matches=[metadata(x) for x in index().incidents if passes(x,filters.model_dump(exclude_none=True))]
    return {'success':True,'count':len(matches),'incidents':matches}


@router.get('/incident/{incident_id}/classification')
def classification(incident_id:str):
    idx=index()
    item=next((x for x in idx.incidents if x['incident_id']==incident_id),None)
    if item is None: raise HTTPException(404,'Dataset incident not found')
    return {'success':True, 'classification':classify(item,idx)}


@router.get('/incident/{incident_id}/priority')
def priority(incident_id:str):
    return {'success':True,'priority':indicators(get_item(incident_id))}


@router.get('/incident/{incident_id}/investigation')
def investigation(incident_id:str):
    idx=index()
    item=next((x for x in idx.incidents if x['incident_id']==incident_id),None)
    if item is None: raise HTTPException(404,'Dataset incident not found')
    return {'success':True,'investigation':investigate(item,idx)}


@router.get('/status')
def status():
    idx=index()
    return {'success':True,'indexed_incidents':len(idx.incidents),
            'retrieval':'local_bm25_lsa','ingestion_pipeline':'independent',
            'trained_attack_model':'not_available_until_trained_and_evaluated',
            'llm_judge':'not_configured'}
