
from collections import Counter
from statistics import mean


def parse_number(value):
    """
    Safely convert a CSV-derived numeric value.
    """
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def analyze_local_incident(incident):
    """
    Produce descriptive statistics from sampled
    CIC-IDS2017 network-flow records.

    This is deterministic local analysis, not
    Synapt.AI inference or threat confirmation.
    """

    flows = incident.get("flows", [])

    ports = []
    durations = []
    forward_packets = []
    backward_packets = []

    for flow in flows:
        port = parse_number(
            flow.get("destination_port")
        )
        duration = parse_number(
            flow.get("flow_duration")
        )
        forward = parse_number(
            flow.get("total_forward_packets")
        )
        backward = parse_number(
            flow.get("total_backward_packets")
        )

        if port is not None:
            ports.append(int(port))

        if duration is not None:
            durations.append(duration)

        if forward is not None:
            forward_packets.append(forward)

        if backward is not None:
            backward_packets.append(backward)

    common_ports = [
        {
            "port": port,
            "count": count,
        }
        for port, count in Counter(
            ports
        ).most_common(5)
    ]

    return {
        "incident_id": incident.get("incident_id"),
        "attack_type": incident.get("attack_type"),
        "analysis_type": "local_descriptive",
        "severity": "unassessed",
        "ai_confidence": None,
        "sample_size": len(flows),
        "statistics": {
            "common_destination_ports": common_ports,
            "average_flow_duration_microseconds": (
                round(mean(durations), 2)
                if durations else None
            ),
            "total_forward_packets": (
                sum(forward_packets)
                if forward_packets else None
            ),
            "total_backward_packets": (
                sum(backward_packets)
                if backward_packets else None
            ),
        },
        "observations": [
            (
                f"The selected sample contains "
                f"{len(flows)} network-flow records."
            ),
            (
                "Attack category comes from the "
                "CIC-IDS2017 dataset label."
            ),
            (
                "These statistics describe sampled "
                "flows, not the full attack."
            ),
        ],
        "limitations": [
            "No source or destination IP addresses are available.",
            "Authentication outcomes are not established.",
            "Service impact is not established.",
            "Severity has not been independently assessed.",
            "No automated containment has been performed.",
        ],
    }
