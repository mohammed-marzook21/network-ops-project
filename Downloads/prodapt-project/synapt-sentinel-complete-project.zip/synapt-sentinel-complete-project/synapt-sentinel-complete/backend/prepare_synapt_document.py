import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"

input_file = DATA_DIR / "cic_ssh_incident.json"
output_file = DATA_DIR / "cic_ssh_incident.md"

with input_file.open("r", encoding="utf-8") as file:
    incident = json.load(file)

lines = [
    "# CIC-IDS2017 SSH-Patator Incident",
    "",
    f"Incident ID: {incident['incident_id']}",
    f"Dataset: {incident['source']}",
    f"Attack Type: {incident['attack_type']}",
    f"Number of Flows: {incident['record_count']}",
    f"Severity: {incident['severity']}",
    "",
    "## Incident Summary",
    incident["summary"],
    "",
    "## Network Flow Evidence",
    "",
]

for flow in incident["flows"]:
    lines.extend([
        f"### {flow['flow_id']}",
        f"- Destination Port: {flow['destination_port']}",
        f"- Flow Duration: {flow['flow_duration']} microseconds",
        f"- Forward Packets: {flow['total_forward_packets']}",
        f"- Backward Packets: {flow['total_backward_packets']}",
        f"- Dataset Label: {flow['label']}",
        "",
    ])

lines.extend([
    "## Evidence Interpretation",
    "",
    "The CIC-IDS2017 dataset labels these sampled flows as SSH-Patator.",
    "All sampled flows target destination port 22.",
    "These records are dataset observations, not live security alerts.",
    "Source and destination IP addresses are not available in this CSV.",
    "Incident severity has not yet been independently assessed.",
    "",
    "## Analyst Review",
    "",
    "Further investigation is required before recommending or executing",
    "any network blocking or other mitigation action.",
])

output_file.write_text("\n".join(lines), encoding="utf-8")

print("Synapt ingestion document created successfully!")
print(f"Saved to: {output_file}")