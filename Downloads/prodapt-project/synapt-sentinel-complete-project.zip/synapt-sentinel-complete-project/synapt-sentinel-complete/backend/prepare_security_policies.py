
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"
OUTPUT_FILE = DATA_DIR / "security_policy_knowledge_pack.md"

POLICIES = [
    {
        "id": "POL-001",
        "title": "Evidence Integrity",
        "rules": [
            "Use original CIC-IDS2017 measurements when describing dataset flows.",
            "Distinguish dataset labels from independently confirmed detections.",
            "Never invent source IPs, destination IPs, accounts, timestamps, or hostnames.",
            "Identify the incident ID and source file when presenting evidence.",
            "Do not use evidence from another incident as proof for the selected incident.",
        ],
    },
    {
        "id": "POL-002",
        "title": "Severity and Confidence",
        "rules": [
            "Keep incident severity unassessed until sufficient evidence is available.",
            "Do not calculate AI confidence from a dataset label alone.",
            "Separate measured observations from hypotheses.",
            "State when additional logs are required to confirm a conclusion.",
        ],
    },
    {
        "id": "POL-003",
        "title": "Human Approval",
        "rules": [
            "All disruptive containment actions require explicit analyst approval.",
            "Never automatically block IP addresses.",
            "Never automatically isolate hosts.",
            "Never disable accounts or terminate processes without approval.",
            "Never modify firewall rules without approval.",
            "Approval must be recorded before any supported response action.",
        ],
    },
    {
        "id": "POL-004",
        "title": "Safe Incident Response",
        "rules": [
            "Prioritize read-only investigation and evidence preservation.",
            "Recommend actions without executing them automatically.",
            "Consider operational impact before containment.",
            "Validate recovery using appropriate service and security checks.",
            "Escalate uncertain or potentially high-impact decisions to an analyst.",
        ],
    },
    {
        "id": "POL-005",
        "title": "Synapt Knowledge Retrieval",
        "rules": [
            "Verify that retrieved evidence corresponds to the selected incident.",
            "Do not treat an incident ID appearing in a response as sufficient proof.",
            "Distinguish general playbook guidance from incident-specific evidence.",
            "Do not present synthetic incident evidence as real CIC-IDS2017 evidence.",
            "Mark analysis as unavailable or unverified when supporting evidence is missing.",
        ],
    },
    {
        "id": "POL-006",
        "title": "Auditability",
        "rules": [
            "Preserve the selected incident ID in analysis records.",
            "Record the origin of evidence and recommendations.",
            "Record analyst approval decisions when implemented.",
            "Do not claim that an action was executed unless execution is confirmed.",
            "Keep generated reports clear about evidence limitations.",
        ],
    },
]


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    lines = [
        "# Synapt Sentinel - Security Policy Knowledge Pack",
        "",
        "Purpose: Define evidence-handling and incident-response",
        "safeguards for the Synapt Sentinel application.",
        "",
        "These are proposed project policies, not proof that",
        "the application currently enforces every rule.",
        "Backend enforcement must be implemented and tested.",
        "",
    ]

    for policy in POLICIES:
        lines.extend([
            f"## {policy['id']} - {policy['title']}",
            "",
        ])

        for rule in policy["rules"]:
            lines.append(f"- {rule}")

        lines.extend(["", "---", ""])

    OUTPUT_FILE.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    print("Security policy knowledge pack generated.")
    print(f"Policies included: {len(POLICIES)}")
    print(f"Output: {OUTPUT_FILE}")
    print(f"Size: {OUTPUT_FILE.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
