"""Local verification manifest for final project demonstration. No invented metrics."""
from __future__ import annotations
import argparse
import json
import os
from datetime import datetime,timezone
from pathlib import Path
from intelligence_api import index
from evaluate_quality import retrieval_evaluation
from review_queue import connect, verify_events

BASE=Path(__file__).resolve().parent

def audit():
    catalog=index().incidents
    issues=[]
    ids={rec['incident_id'] for rec in catalog}
    for item in catalog:
        if item.get('source_ip') or item.get('destination_ip') or item.get('timestamp'):
            issues.append(f"{item['incident_id']}: source supplied IP/time metadata; verify provenance")
    with connect() as db:
        reviews=db.execute('SELECT id FROM review_items').fetchall()
        audit_states={}
        for row in reviews:
            events=db.execute('SELECT * FROM review_events WHERE item_id=? ORDER BY rowid',(row['id'],)).fetchall()
            status=verify_events(row['id'],events)
            audit_states[status]=audit_states.get(status,0)+1
    artifact=BASE/'artifacts'/'models'/'models.joblib'
    evaluation=BASE/'artifacts'/'models'/'evaluation.json'
    cross=BASE/'artifacts'/'cross_capture'/'evaluation.json'
    v3=BASE/'artifacts'/'model_v3_experiment'/'evaluation.json'
    return {'generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'local_incidents_indexed':len(catalog),
            'retrieval':retrieval_evaluation(),
            'review_items':len(reviews),'review_audit_states':audit_states,
            'trained_model_artifact_present':artifact.is_file(),
            'model_evaluation_present':evaluation.is_file(),
            'cross_capture_evaluation_present':cross.is_file(),
            'v3_experiment_evaluation_present':v3.is_file(),
            'synapt_ingestion_verified':False,
            'synapt_external_calls_enabled':os.environ.get('SENTINEL_ENABLE_SYNAPT')=='1',
            'deepeval_run_status':'not_executed_by_this_audit',
            'llm_judge_run_status':'not_executed_by_this_audit',
            'data_quality_warnings':issues,
            'limitations':['Existing retrieval benchmark uses same corpus and attack labels',
                           'Capture reuse means prior experiments do not provide independent validation',
                           'Attack labels from dataset are not predicted risk',
                           'Project does not automatically execute response actions']}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(BASE/'artifacts'/'final_audit.json'))
    args=parser.parse_args();report=audit();p=Path(args.output);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
