"""Submit actual flow features from a CIC-IDS2017 CSV with authenticated analyst session.

Usage: python demo_review_intake.py --csv "path/to/capture.pcap_ISCX.csv" --username admin
Never invent flow IDs, IP addresses, timestamps or ground truth.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from getpass import getpass
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from model_pipeline import FEATURE_COLUMNS


def call(url, data, token=None):
    header={'Content-Type':'application/json'}
    if token: header['Authorization']='Bearer '+token
    request=Request(url, data=json.dumps(data).encode('utf-8'),headers=header,method='POST')
    try:
        with urlopen(request, timeout=120) as r:return json.load(r)
    except HTTPError as err:
        raise RuntimeError(f'API returned HTTP {err.code}: {err.read().decode()[:1200]}') from err


def flows_from_csv(path, count=100):
    records=[]
    with open(path,encoding='utf-8-sig',errors='replace',newline='') as f:
        reader=csv.DictReader(f)
        for raw in reader:
            row={str(k).strip():v for k,v in raw.items() if k}
            if any(field not in row for field in FEATURE_COLUMNS):
                raise ValueError('CSV lacks required model feature columns')
            try:
                numeric={key:float(row[key]) for key in FEATURE_COLUMNS}
            except (ValueError,TypeError):continue
            if all(math.isfinite(v) for v in numeric.values()):records.append(numeric)
            if len(records)>=count:break
    if len(records)<count:raise ValueError(f'Only {len(records)} complete finite feature rows found; need {count}')
    return records

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--csv',required=True);p.add_argument('--username',required=True)
    p.add_argument('--api',default='http://127.0.0.1:8000');p.add_argument('--budget',type=float,default=.05)
    args=p.parse_args()
    session=call(args.api+'/api/auth/login',{'username':args.username,'password':getpass('Password: ')})
    results=call(args.api+'/api/review/intake',{'flows':flows_from_csv(args.csv),
                  'review_budget':args.budget},session['access_token'])
    print(json.dumps(results,indent=2))
    print('Open Incident Explorer and Response Center to inspect pending review items.')
