"""Local hybrid retrieval and traceable incident investigation. No external ingestion.

Lexical BM25 + latent-semantic TF-IDF/SVD retrieval. A transformer encoder can
be integrated later without changing API contracts. No generated evidence.
"""
from __future__ import annotations

from collections import Counter
from functools import lru_cache
import ipaddress
import json
import math
from pathlib import Path
import re
from typing import Any

import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer

from local_analyzer import analyze_local_incident
from response_engine import generate_recommendations

BASE = Path(__file__).resolve().parent
TOKEN = re.compile(r"[a-z0-9][a-z0-9_.:-]*", re.I)
FEATURES = ('destination_port','flow_duration','total_forward_packets','total_backward_packets')


def tokenize(s: str) -> list[str]:
    return TOKEN.findall(s.lower())


def load_incidents(paths: dict[str, Path]) -> list[dict]:
    records = []
    for incident_id, path in sorted(paths.items()):
        try:
            with path.open(encoding='utf-8') as f:
                item = json.load(f)
            if item.get('incident_id') == incident_id and isinstance(item.get('flows'), list):
                records.append(item)
        except (ValueError, OSError):
            continue
    return records


def numeric(v: Any) -> float | None:
    try:
        n = float(v)
        return n if math.isfinite(n) else None
    except (ValueError, TypeError):
        return None


def metadata(item: dict) -> dict:
    flows = item.get('flows', [])
    ports = sorted({int(x) for f in flows if (x := numeric(f.get('destination_port'))) is not None and 0 <= x <= 65535})
    protocols = sorted({str(f['protocol']).upper() for f in flows if f.get('protocol') not in (None, '')})
    return {'incident_id': item['incident_id'], 'attack_type': item.get('attack_type'),
            'ports': ports, 'protocols': protocols, 'timestamp': item.get('timestamp'),
            'source_ip': item.get('source_ip'), 'destination_ip': item.get('destination_ip'),
            'source': item.get('source')}


def document(item: dict) -> str:
    md = metadata(item)
    desc = ' '.join(f"port {p}" for p in md['ports'])
    return ' '.join(str(x or '') for x in (item.get('attack_type'), item.get('summary'),
                 item.get('source'), ' '.join(item.get('dataset_labels') or []), desc,
                 ' '.join(md['protocols'])))


def passes(item: dict, filters: dict) -> bool:
    md = metadata(item)
    for field in ('attack_type', 'protocol', 'source_ip', 'destination_ip'):
        value = filters.get(field)
        if value is None:
            continue
        if field == 'protocol':
            if str(value).upper() not in md['protocols']: return False
        elif str(md.get(field) or '').lower() != str(value).lower():
            return False
    if filters.get('destination_port') is not None and filters['destination_port'] not in md['ports']:
        return False
    stamp = md.get('timestamp')
    if filters.get('start_time') or filters.get('end_time'):
        if not stamp: return False  # never claim unknown timestamp matches
        if filters.get('start_time') and stamp < filters['start_time']: return False
        if filters.get('end_time') and stamp > filters['end_time']: return False
    return True


class HybridIndex:
    """Index of trusted local documents; lexical BM25 + LSA semantic similarity."""
    def __init__(self, incidents: list[dict]):
        self.incidents = incidents
        self.texts = [document(x) for x in incidents]
        self.tokens = [tokenize(x) for x in self.texts]
        self.freqs = [Counter(t) for t in self.tokens]
        self.lengths = [len(t) for t in self.tokens]
        self.avgdl = sum(self.lengths) / max(1,len(self.lengths))
        self.df = Counter(t for words in self.tokens for t in set(words))
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = None
        self.svd = None
        self.semantic = None
        if self.texts:
            self.matrix = self.vectorizer.fit_transform(self.texts)
            # SVD extracts latent lexical concepts; it is not a pretrained encoder.
            rank = min(32, self.matrix.shape[0] - 1, self.matrix.shape[1] - 1)
            if rank >= 2:
                self.svd = TruncatedSVD(n_components=rank, random_state=42)
                self.semantic = self.svd.fit_transform(self.matrix)
            else:
                self.semantic = self.matrix.toarray()

    def search(self, query: str, filters: dict | None = None, top_k: int = 5,
               exclude_id: str | None = None) -> list[dict]:
        if not self.incidents: return []
        words = tokenize(query)
        n = len(self.incidents)
        bm = np.zeros(n)
        for i, counts in enumerate(self.freqs):
            for term in set(words):
                df = self.df.get(term, 0)
                if not df or not counts[term]: continue
                idf = math.log(1 + (n - df + 0.5)/(df+0.5))
                tf = counts[term]
                bm[i] += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * self.lengths[i]/max(self.avgdl,1)))
        q = self.vectorizer.transform([query])
        sem_q = self.svd.transform(q)[0] if self.svd else q.toarray()[0]
        denom = (np.linalg.norm(self.semantic, axis=1) * np.linalg.norm(sem_q))
        semantic_scores = np.divide(self.semantic @ sem_q, denom, out=np.zeros(n), where=denom>0)
        # Separate rankings avoid letting one scale dominate another.
        lex_rank = sorted(range(n), key=lambda i: (-bm[i], i))
        sem_rank = sorted(range(n), key=lambda i: (-semantic_scores[i], i))
        lex_pos = {i:p for p,i in enumerate(lex_rank)}
        sem_pos = {i:p for p,i in enumerate(sem_rank)}
        combined = {i: 1/(60+lex_pos[i]+1)+1/(60+sem_pos[i]+1) for i in range(n)}
        eligible = [i for i,doc in enumerate(self.incidents)
                    if doc['incident_id'] != exclude_id and passes(doc, filters or {})]
        eligible.sort(key=lambda i: (-combined[i], self.incidents[i]['incident_id']))
        return [{'incident_id': self.incidents[i]['incident_id'],
                 'attack_type': self.incidents[i].get('attack_type'),
                 'score': round(combined[i], 6),
                 'lexical_score': round(float(bm[i]), 5),
                 'semantic_score': round(float(semantic_scores[i]), 5),
                 'metadata': metadata(self.incidents[i]),
                 'evidence': {'source':'local_incident','incident_id':self.incidents[i]['incident_id'],
                              'summary':self.incidents[i].get('summary')}} for i in eligible[:top_k]]


def indicators(item: dict) -> dict:
    flows = item.get('flows', [])
    feature_summary = {}
    for key in FEATURES:
        values = [num for f in flows if (num := numeric(f.get(key))) is not None]
        feature_summary[key] = {'mean':round(float(np.mean(values)),3),'max':round(max(values),3),
                                'n':len(values)} if values else None
    f = feature_summary
    port = (f['destination_port'] or {}).get('mean')
    fwd = (f['total_forward_packets'] or {}).get('mean', 0)
    bwd = (f['total_backward_packets'] or {}).get('mean', 0)
    signals = []
    if port is not None and port in (21,22,23,3389):
        signals.append({'signal':'administrative_or_authentication_port','value':port,'weight':15})
    if bwd == 0 and fwd > 0: signals.append({'signal':'no_backward_packets_in_sample','value':fwd,'weight':10})
    if fwd > 100 or bwd > 100: signals.append({'signal':'elevated_packet_count_in_sample','value':max(fwd,bwd),'weight':15})
    # Explicitly heuristic: not a probability, trained risk model, or confirmed severity.
    score = min(100, 20 + sum(x['weight'] for x in signals))
    return {'feature_summary':feature_summary, 'signals':signals,
            'heuristic_priority_score':score,
            'priority_band':'high' if score >= 60 else 'medium' if score >= 35 else 'low',
            'priority_method':'transparent_heuristic_unvalidated',
            'limitations':['Sample-only measurements','No observed infrastructure impact',
                           'Not a model confidence or probability']}


def classify(item: dict, index: HybridIndex) -> dict:
    query = document(item)
    neighbors = index.search(query, top_k=5, exclude_id=item['incident_id'])
    labels = Counter(x['attack_type'] for x in neighbors if x.get('attack_type'))
    return {'predicted_attack_type': labels.most_common(1)[0][0] if labels else None,
            'method':'retrieval_nearest_neighbor_baseline', 'is_trained_classifier':False,
            'reference_dataset_label':item.get('attack_type'), 'supporting_incidents':neighbors[:3],
            'confidence':None, 'warning':'Historical similarity is not supervised predictive validation.'}


def investigate(item: dict, index: HybridIndex) -> dict:
    steps = []
    local = analyze_local_incident(item)
    steps.append({'agent':'detection','status':'complete', 'output':{'sample_size':len(item.get('flows',[])),
                  'observations':local['observations']}})
    classification = classify(item,index)
    similar = index.search(document(item), top_k=5, exclude_id=item['incident_id'])
    steps.append({'agent':'analysis','status':'complete','output':{'classification':classification,
                  'similar_incidents':similar}})
    priority = indicators(item)
    steps.append({'agent':'risk_assessment','status':'complete','output':priority})
    response = generate_recommendations(item)
    steps.append({'agent':'response_recommendation','status':'complete','output':response})
    return {'incident_id':item['incident_id'], 'workflow':'deterministic_multi_agent_orchestration_v1',
            'steps':steps, 'evidence_ids':[x['incident_id'] for x in similar],
            'execution_status':'not_executed','requires_analyst_approval':True,
            'disclaimer':'Dataset labels are annotations, not independent proof of an intrusion.'}
