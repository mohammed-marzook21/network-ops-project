"""Export reviewed examples for offline human-reviewed learning; never retrains production models."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from review_queue import connect, verify_events


def export(path):
    records=[]
    with connect() as db:
        reviewed=db.execute("SELECT * FROM review_items WHERE status='reviewed' ORDER BY updated_at,id").fetchall()
        for item in reviewed:
            events=db.execute('SELECT * FROM review_events WHERE item_id=? ORDER BY rowid',(item['id'],)).fetchall()
            records.append({'review_id':item['id'],'analyst_decision':item['decision'],
                            'reviewer':item['reviewer'],'updated_at':item['updated_at'],
                            'model_attack_type':item['attack_type'],'intrusion_score':item['score'],
                            'features':json.loads(item['features_json']),
                            'audit_integrity':verify_events(item['id'],events),
                            'training_eligibility':'human_vetting_required'})
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({'count':len(records),'items':records,
          'notes':['Review decisions are not automatically ground-truth flow labels',
                   'Do not retrain on this export without verification, deduplication and separate validation']},indent=2),encoding='utf-8')
    return len(records)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default=str(Path(__file__).resolve().parent/'artifacts'/'review_feedback_export.json'))
    args=p.parse_args();print(f'Exported {export(args.output)} reviewed items')
