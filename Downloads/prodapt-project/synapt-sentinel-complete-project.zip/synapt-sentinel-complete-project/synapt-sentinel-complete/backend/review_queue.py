"""Authenticated, persistent analyst-review queue with tamper-evident event chain.

No automatic response actions. Attack labels are predictions, not ground truth.
HMAC chain protects against casual DB-only alteration; does not defend against an
attacker who can access the signing key or execute arbitrary server code.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import math
import os
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator

from model_api import load_model
from model_pipeline import predict, FEATURE_COLUMNS
from security_api import current_user, enforce_limit, permit

router = APIRouter(prefix='/api/review', tags=['Analyst review'])
DB_PATH = Path(os.environ.get('SENTINEL_REVIEW_DB', str(Path(__file__).resolve().parent / 'artifacts' / 'review_queue.sqlite3')))
KEY_PATH = DB_PATH.with_suffix('.audit.key')


def now():
    return datetime.now(timezone.utc).isoformat()


def audit_key():
    configured = os.environ.get('SENTINEL_AUDIT_KEY')
    if configured:
        if len(configured) < 32:
            raise RuntimeError('SENTINEL_AUDIT_KEY must have >=32 characters')
        return configured.encode('utf-8')
    # Single local instance only. Keep this file across restarts.
    KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        with KEY_PATH.open('xb') as out:
            os.chmod(KEY_PATH, 0o600)
            out.write(secrets.token_bytes(32))
    except FileExistsError:
        pass
    return KEY_PATH.read_bytes()


def signature(item_id, previous_hash, event, actor, detail_json, created):
    payload = json.dumps([item_id, previous_hash, event, actor, detail_json, created], separators=(',',':'))
    return hmac.new(audit_key(), payload.encode('utf-8'), hashlib.sha256).hexdigest()


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(DB_PATH), timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=15000')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('''CREATE TABLE IF NOT EXISTS review_items (
        id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, batch_index INTEGER NOT NULL,
        status TEXT NOT NULL, priority REAL NOT NULL, score REAL NOT NULL,
        attack_type TEXT NOT NULL, anomaly_score REAL NOT NULL,
        features_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        reviewer TEXT, decision TEXT, note TEXT)''')
    db.execute('''CREATE TABLE IF NOT EXISTS review_events (
        id TEXT PRIMARY KEY, item_id TEXT NOT NULL, event TEXT NOT NULL,
        actor TEXT NOT NULL, details_json TEXT NOT NULL, created_at TEXT NOT NULL,
        previous_hash TEXT, event_hash TEXT,
        FOREIGN KEY(item_id) REFERENCES review_items(id))''')
    # Explicit additive migration for existing V4 data.
    columns = {r['name'] for r in db.execute('PRAGMA table_info(review_events)')}
    for name in ('previous_hash', 'event_hash'):
        if name not in columns:
            db.execute(f'ALTER TABLE review_events ADD COLUMN {name} TEXT')
    db.commit()
    return db


def write_event(db, item_id, event, actor, details, created):
    previous = db.execute('SELECT event_hash FROM review_events WHERE item_id=? ORDER BY rowid DESC LIMIT 1',
                          (item_id,)).fetchone()
    prev = previous['event_hash'] if previous and previous['event_hash'] else 'GENESIS'
    details_json = json.dumps(details, sort_keys=True, separators=(',',':'), allow_nan=False)
    digest = signature(item_id, prev, event, actor, details_json, created)
    db.execute('''INSERT INTO review_events (id,item_id,event,actor,details_json,created_at,previous_hash,event_hash)
                  VALUES (?,?,?,?,?,?,?,?)''',
               (str(uuid.uuid4()), item_id, event, actor, details_json, created, prev, digest))


def verify_events(item_id, events):
    prev = 'GENESIS'
    for row in events:
        # Existing events predate chain support; report unknown rather than claiming integrity.
        if row['previous_hash'] is None or row['event_hash'] is None:
            return 'legacy_unverified'
        if row['previous_hash'] != prev or not hmac.compare_digest(
                row['event_hash'], signature(item_id, prev, row['event'], row['actor'],
                                             row['details_json'], row['created_at'])):
            return 'invalid'
        prev = row['event_hash']
    return 'verified' if events else 'no_events'


class Intake(BaseModel):
    flows: list[dict] = Field(min_length=1, max_length=100)
    review_budget: float = Field(default=0.01, gt=0, le=0.05)

    @field_validator('flows')
    @classmethod
    def check_flows(cls, flows):
        for row in flows:
            if len(row) > 120:
                raise ValueError('Too many submitted feature fields')
            if any(k not in row for k in FEATURE_COLUMNS):
                raise ValueError('Each flow needs all twelve model feature names')
            if len(json.dumps(row, allow_nan=False)) > 15000:
                raise ValueError('Flow payload too large')
            for feature in FEATURE_COLUMNS:
                value = row[feature]
                if isinstance(value, bool) or not isinstance(value, (float, int, str)):
                    raise ValueError(f'Feature {feature} must be numeric')
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    raise ValueError(f'Feature {feature} must be numeric')
                if not math.isfinite(number):
                    raise ValueError(f'Feature {feature} is not finite')
        return flows


class Decision(BaseModel):
    # Reviewer identity comes from authenticated server-side session, never request body.
    decision: Literal['confirmed_attack', 'benign', 'inconclusive']
    note: str = Field(default='', max_length=2000)


def rank_candidates(predictions, budget):
    if not 0 < budget <= 0.05:
        raise ValueError('review_budget must be in (0, 0.05]')
    count = int(len(predictions) * budget)
    candidates = [(i, float(p['intrusion_score'])) for i,p in enumerate(predictions)
                  if p.get('predicted_intrusion') is False and p.get('intrusion_score') is not None]
    return sorted(candidates, key=lambda pair: (-pair[1], pair[0]))[:count]


def serialize(row):
    result = dict(row)
    result['features'] = json.loads(result.pop('features_json'))
    return result


@router.post('/intake')
def intake(req: Intake, request: Request, user=Depends(permit('analyst', 'admin'))):
    enforce_limit('intake:'+user['username'], 30, 60)
    try:
        predictions = predict(load_model(), req.flows)
        if any(p.get('intrusion_score') is None for p in predictions):
            raise HTTPException(503, 'Binary intrusion model required')
        selected = rank_candidates(predictions, req.review_budget)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    batch_id, created, items = str(uuid.uuid4()), now(), []
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        for index, score in selected:
            p = predictions[index]
            item_id = str(uuid.uuid4())
            db.execute('''INSERT INTO review_items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                       (item_id,batch_id,index,'pending',score,score,str(p['attack_type']),
                        float(p['anomaly_score']),json.dumps(req.flows[index],allow_nan=False),created,created,
                        None,None,None))
            write_event(db,item_id,'queued',user['username'],
                        {'review_budget':req.review_budget,'source':'trained_local_model'},created)
            items.append({'id':item_id,'batch_index':index,'intrusion_score':score,
                          'status':'pending','attack_type':p['attack_type']})
    return {'batch_id':batch_id,'total_flows':len(req.flows),
            'automated_flagged':sum(p.get('predicted_intrusion') is True for p in predictions),
            'review_budget':req.review_budget,'review_count':len(items), 'items':items,
            'source':'trained_local_model',
            'warning':'Review selection is not an attack classification; model scores are uncalibrated.'}


@router.get('/items')
def list_items(status: Literal['pending','reviewed','all']='pending',
               limit: int=Query(50,ge=1,le=200), user=Depends(current_user)):
    with connect() as db:
        if status == 'all':
            rows = db.execute('SELECT * FROM review_items ORDER BY created_at DESC, priority DESC LIMIT ?',
                              (limit,)).fetchall()
        else:
            rows = db.execute('SELECT * FROM review_items WHERE status=? ORDER BY priority DESC, created_at ASC LIMIT ?',
                              (status,limit)).fetchall()
    return {'items':[serialize(row) for row in rows]}


@router.get('/items/{item_id}')
def get_item(item_id: str, user=Depends(current_user)):
    with connect() as db:
        row = db.execute('SELECT * FROM review_items WHERE id=?',(item_id,)).fetchone()
        if not row: raise HTTPException(404, 'Review item not found')
        events = db.execute('SELECT * FROM review_events WHERE item_id=? ORDER BY rowid', (item_id,)).fetchall()
    return {'item': serialize(row), 'events': [
                {'event':e['event'],'actor':e['actor'],'created_at':e['created_at'],
                 'details':json.loads(e['details_json'])} for e in events],
            'audit_integrity': verify_events(item_id, events)}


@router.post('/items/{item_id}/decision')
def decide(item_id: str, req: Decision, user=Depends(permit('analyst','admin'))):
    stamp = now()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        updated = db.execute('''UPDATE review_items SET status='reviewed', reviewer=?, decision=?,note=?,updated_at=?
                                WHERE id=? AND status='pending' ''',
                             (user['username'],req.decision,req.note,stamp,item_id))
        if updated.rowcount != 1:
            exists = db.execute('SELECT 1 FROM review_items WHERE id=?',(item_id,)).fetchone()
            raise HTTPException(409 if exists else 404, 'Already reviewed' if exists else 'Review item not found')
        write_event(db,item_id,'decision',user['username'],
                    {'decision':req.decision,'note':req.note},stamp)
    return {'id':item_id,'status':'reviewed','decision':req.decision,'reviewer':user['username']}
