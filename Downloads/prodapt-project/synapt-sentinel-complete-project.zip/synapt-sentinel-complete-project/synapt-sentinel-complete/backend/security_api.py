"""Local-user authentication for analyst review. No external identity provider required.

Tokens are opaque, generated with secrets and stored ONLY as hashes in SQLite.
For public deployments use TLS, centralized identity, key management and a shared
rate limiter; the built-in limiter is a single-process safety control.
"""
from __future__ import annotations
import hashlib
import hmac
import os
import secrets
import sqlite3
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

DB_PATH = Path(os.environ.get('SENTINEL_AUTH_DB', str(Path(__file__).resolve().parent / 'artifacts' / 'auth.sqlite3')))
ROLES = frozenset(('viewer', 'analyst', 'admin'))
SESSION_SECONDS = 8 * 3600
_lock = threading.Lock()
_attempts = defaultdict(deque)
_bearer = HTTPBearer(auto_error=False)
router = APIRouter(prefix='/api/auth', tags=['Local authentication'])


def db_connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(DB_PATH), timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=15000')
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY,
               salt TEXT NOT NULL, password_hash TEXT NOT NULL,
               role TEXT NOT NULL CHECK(role IN ('viewer','analyst','admin')),
               active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''')
    db.execute('''CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY,
               username TEXT NOT NULL, expires INTEGER NOT NULL,
               created_at TEXT NOT NULL, FOREIGN KEY(username) REFERENCES users(username))''')
    db.commit()
    return db


def utc():
    return datetime.now(timezone.utc).isoformat()


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 390_000).hex()


def create_user(username: str, password: str, role: str = 'analyst'):
    if not (3 <= len(username) <= 64 and username.replace('_', '').replace('-', '').isalnum()):
        raise ValueError('Username must be 3-64 alphanumeric characters, hyphens or underscores')
    if len(password) < 12 or len(password) > 256:
        raise ValueError('Password must be 12-256 characters')
    if role not in ROLES:
        raise ValueError('Unknown role')
    salt = secrets.token_hex(16)
    with db_connect() as db:
        db.execute('INSERT INTO users (username,salt,password_hash,role,active,created_at) VALUES (?,?,?,?,1,?)',
                   (username, salt, hash_password(password, salt), role, utc()))


def enforce_limit(key: str, max_requests: int, window_seconds: int):
    current = time.monotonic()
    with _lock:
        entries = _attempts[key]
        while entries and current - entries[0] >= window_seconds:
            entries.popleft()
        if len(entries) >= max_requests:
            raise HTTPException(429, 'Rate limit exceeded; retry later')
        entries.append(current)


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=1, max_length=256)


@router.post('/login')
def login(credentials: Credentials, request: Request):
    host = request.client.host if request.client else 'unknown'
    enforce_limit('login-ip:'+host, 20, 300)
    enforce_limit('login-user:'+credentials.username.lower(), 12, 300)
    with db_connect() as db:
        user = db.execute('SELECT * FROM users WHERE username=?', (credentials.username,)).fetchone()
        # Comparable cost even for unknown user.
        salt = user['salt'] if user else '00'*16
        expected = user['password_hash'] if user else '00'*32
        supplied = hash_password(credentials.password, salt)
        if not hmac.compare_digest(expected, supplied) or not user or not user['active']:
            raise HTTPException(401, 'Invalid credentials')
        token = secrets.token_urlsafe(40)
        expiry = int(time.time()) + SESSION_SECONDS
        db.execute('DELETE FROM sessions WHERE expires <= ?', (int(time.time()),))
        db.execute('INSERT INTO sessions VALUES (?,?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(), user['username'], expiry, utc()))
    return {'access_token': token, 'token_type': 'bearer', 'expires_in': SESSION_SECONDS,
            'user': {'username': user['username'], 'role': user['role']}}


def current_user(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)]):
    if credentials is None or credentials.scheme.lower() != 'bearer':
        raise HTTPException(401, 'Authentication required', headers={'WWW-Authenticate':'Bearer'})
    digest = hashlib.sha256(credentials.credentials.encode()).hexdigest()
    with db_connect() as db:
        row = db.execute('''SELECT u.username, u.role, u.active, s.expires FROM sessions s
                            JOIN users u ON u.username=s.username WHERE s.token_hash=?''', (digest,)).fetchone()
    if row is None or not row['active'] or row['expires'] <= int(time.time()):
        raise HTTPException(401, 'Invalid or expired session')
    return {'username': row['username'], 'role': row['role']}


def permit(*allowed_roles):
    def dependency(user=Depends(current_user)):
        if user['role'] not in allowed_roles:
            raise HTTPException(403, 'Insufficient permissions')
        return user
    return dependency


@router.get('/me')
def me(user=Depends(current_user)):
    return user


@router.post('/logout')
def logout(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)], user=Depends(current_user)):
    with db_connect() as db:
        db.execute('DELETE FROM sessions WHERE token_hash=?', (hashlib.sha256(credentials.credentials.encode()).hexdigest(),))
    return {'success': True}


class NewUser(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=12, max_length=256)
    role: str = 'analyst'


@router.post('/users', status_code=201)
def add_user(req: NewUser, admin=Depends(permit('admin'))):
    try:
        create_user(req.username, req.password, req.role)
    except sqlite3.IntegrityError:
        raise HTTPException(409, 'Username already exists')
    except ValueError as e:
        raise HTTPException(422, str(e))
    return {'username': req.username, 'role': req.role, 'created': True}
