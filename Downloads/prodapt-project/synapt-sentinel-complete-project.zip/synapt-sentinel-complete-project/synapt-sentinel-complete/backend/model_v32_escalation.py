"""V3.2: held-out-capture selective analyst-review experiment. No production writes.

Review candidates are supervised-negative flows; ranks are selected without test labels.
Budgets are per held-out capture, simulating a fixed-capacity review queue.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from model_pipeline import FEATURE_COLUMNS, load_sample
from model_v3_experiment import threshold_at_fpr, anomaly_percentile, metrics


def select_review_indices(supervised_scores, anomaly_scores, cutoff, budget, method):
    """Select at most floor(budget * total rows) supervised-negative flows.

    Rank by anomaly, supervised score, or normalized combination. Stable tie-breaking.
    """
    s = np.asarray(supervised_scores, dtype=float)
    a = np.asarray(anomaly_scores, dtype=float)
    if s.shape != a.shape or s.ndim != 1 or not np.isfinite(s).all() or not np.isfinite(a).all():
        raise ValueError('Scores must be matching finite one-dimensional arrays')
    if not 0 <= budget <= 1:
        raise ValueError('Review budget must be in [0, 1]')
    if method not in ('anomaly', 'supervised', 'hybrid'):
        raise ValueError('Unknown review method')
    candidates = np.flatnonzero(s < cutoff)
    capacity = min(len(candidates), int(np.floor(budget * len(s))))
    if capacity == 0:
        return np.empty(0, dtype=int)
    if method == 'anomaly':
        rank = a[candidates]
    elif method == 'supervised':
        rank = s[candidates]
    else:
        # Rank-percentiles make score scales comparable without labels.
        def pct(v):
            order = np.argsort(v, kind='stable')
            ranks = np.empty(len(v), dtype=float)
            ranks[order] = np.arange(len(v))
            return ranks / max(1, len(v) - 1)
        rank = .5 * pct(a[candidates]) + .5 * pct(s[candidates])
    ordering = np.lexsort((candidates, -rank))
    return candidates[ordering[:capacity]]


def review_metrics(y, supervised_scores, cutoff, indices):
    y = np.asarray(y, dtype=int)
    s = np.asarray(supervised_scores, dtype=float)
    idx = np.asarray(indices, dtype=int)
    if y.shape != s.shape or y.ndim != 1:
        raise ValueError('Mismatched labels and scores')
    baseline = s >= cutoff
    if np.any(baseline[idx]):
        raise ValueError('Review queue must not include supervised-positive flows')
    rescued = int(y[idx].sum())
    benign = int(len(idx) - rescued)
    missed = int(np.count_nonzero((y == 1) & ~baseline))
    return {'reviewed': int(len(idx)), 'review_fraction': len(idx) / len(y) if len(y) else 0.,
            'rescued_attacks': rescued, 'benign_reviews': benign,
            'review_precision_or_yield': rescued / len(idx) if len(idx) else None,
            'rescued_per_100_benign_reviews': 100 * rescued / benign if benign else None,
            'missed_attacks_before_review': missed,
            'fraction_of_missed_attacks_recovered': rescued / missed if missed else None,
            'automated_attack_predictions_unchanged': True}


def run(paths, output, per_class=3000, benign_cap=5000, trees=60, seed=42,
        fpr_budget=.05, review_budgets=(.01, .03, .05)):
    paths = [Path(p) for p in paths]
    if len(paths) < 3 or len({p.name for p in paths}) != len(paths):
        raise ValueError('Provide at least three uniquely named captures')
    if min(per_class, benign_cap, trees) < 1 or not 0 < fpr_budget < 1:
        raise ValueError('Invalid training settings')
    budgets = sorted(set(float(b) for b in review_budgets))
    if not budgets or any(not 0 < b <= 1 for b in budgets):
        raise ValueError('Review budgets must be in (0, 1]')
    captures = []
    for held in paths:
        train, _ = load_sample([p for p in paths if p != held], per_class, benign_cap, seed=seed)
        test, _ = load_sample([held], per_class, benign_cap, seed=seed + 1)
        conflicts = train.groupby('__key__')['__label__'].nunique()
        train = train.loc[~train['__key__'].isin(conflicts[conflicts > 1].index)].drop_duplicates('__key__').copy()
        seen = set(train['__key__'])
        overlap = int(test['__key__'].isin(seen).sum())
        test = test.loc[~test['__key__'].isin(seen)].drop_duplicates('__key__').copy()
        y = (train['__label__'] != 'BENIGN').astype(int)
        yt = (test['__label__'] != 'BENIGN').astype(int).to_numpy()
        entry = {'held_out_capture': held.name, 'train_rows': len(train), 'test_rows': len(test),
                 'removed_overlap': overlap,
                 'unseen_attack_labels': sorted(set(test.loc[yt == 1, '__label__']) - set(train.loc[y == 1, '__label__']))}
        if not len(test) or y.nunique() != 2 or y.value_counts().min() < 8:
            entry['status'] = 'insufficient_data'
            captures.append(entry)
            continue
        fit, val = train_test_split(np.arange(len(train)), test_size=.25, stratify=y, random_state=seed)
        x, xt = train[FEATURE_COLUMNS], test[FEATURE_COLUMNS]
        clf = Pipeline([('imputer', SimpleImputer(strategy='median')),
                        ('model', ExtraTreesClassifier(n_estimators=trees, min_samples_leaf=2,
                                                       class_weight='balanced', random_state=seed, n_jobs=-1))])
        clf.fit(x.iloc[fit], y.iloc[fit])
        vy = y.iloc[val].to_numpy()
        sv = clf.predict_proba(x.iloc[val])[:, 1]
        st = clf.predict_proba(xt)[:, 1]
        cut = threshold_at_fpr(sv[vy == 0], fpr_budget)
        benign_fit = x.iloc[fit][y.iloc[fit] == 0]
        imp = SimpleImputer(strategy='median')
        iso = IsolationForest(n_estimators=100, contamination='auto', random_state=seed, n_jobs=-1)
        iso.fit(imp.fit_transform(benign_fit))
        raw_val = -iso.decision_function(imp.transform(x.iloc[val]))
        raw_test = -iso.decision_function(imp.transform(xt))
        at = anomaly_percentile(raw_test, raw_val[vy == 0])
        by_budget = {}
        for b in budgets:
            methods = {}
            for method in ('anomaly', 'supervised', 'hybrid'):
                indices = select_review_indices(st, at, cut, b, method)
                summary = review_metrics(yt, st, cut, indices)
                # Only aggregate feature contributions; not a per-flow causal explanation.
                methods[method] = summary
            by_budget[f'{b:.4f}'] = methods
        entry.update(status='evaluated', supervised=metrics(yt, st, cut),
                     supervised_threshold=float(cut), review_by_budget=by_budget,
                     attack_labels={str(label): int(count) for label, count in
                                    test.loc[yt == 1, '__label__'].value_counts().items()})
        captures.append(entry)
        print(f'{held.name}: recall={entry["supervised"]["recall"]}, FPR={entry["supervised"]["fpr"]}, '
              f'5% anomaly rescue={by_budget.get("0.0500", {}).get("anomaly", {}).get("rescued_attacks", "n/a")}', flush=True)
    report = {'methodology': 'Sampled leave-one-capture-out, exact-feature duplicate exclusion; test labels only for retrospective evaluation',
              'settings': {'per_class': per_class, 'benign_cap': benign_cap, 'trees': trees,
                           'seed': seed, 'fpr_budget': fpr_budget, 'review_budgets': budgets},
              'limitations': [
                  'Review queue is simulated by ranking all flows in each held-out capture, not online streaming',
                  'Review budget is a fraction of all sampled flows, not a deployment-wide workload estimate',
                  'Anomaly review is not automated detection: all rescued attacks require hypothetical perfect analyst review',
                  'Actual FPR on held-out capture may exceed validation-side target',
                  'Sampling distorts attack prevalence and review precision; do not extrapolate to deployment',
                  'Feature-vector duplicates removed but near duplicates/capture artifacts remain',
                  'Supervised scores are not calibrated probabilities; uncertainty ranking is heuristic',
                  'No per-flow explainability claims; report is aggregate only'],
              'captures': captures}
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', nargs='+', required=True, type=Path)
    p.add_argument('--output', default=str(Path(__file__).resolve().parent / 'artifacts' / 'model_v32_escalation' / 'evaluation.json'))
    p.add_argument('--per-class', type=int, default=3000)
    p.add_argument('--benign-cap', type=int, default=5000)
    p.add_argument('--trees', type=int, default=60)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--fpr-budget', type=float, default=.05)
    p.add_argument('--review-budgets', nargs='+', type=float, default=[.01, .03, .05])
    args = p.parse_args()
    run(args.csv, args.output, args.per_class, args.benign_cap, args.trees,
        args.seed, args.fpr_budget, args.review_budgets)
    print('Saved:', args.output)
