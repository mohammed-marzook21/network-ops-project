# Synapt Sentinel - Incident Response Playbooks

These playbooks provide general defensive guidance.
CIC-IDS2017 labels alone do not prove compromise,
successful exploitation, or service disruption.
No containment action is automatically authorized.

## Credential Brute Force

### Related Dataset Labels

- SSH-Patator
- FTP-Patator
- Web Attack - Brute Force

### Investigation

- Identify affected authentication services.
- Review login success and failure logs.
- Correlate timestamps and account activity.
- Check whether any authentication succeeded.

### Containment Recommendations

- Consider rate limiting or temporary access restrictions.
- Review account lockout and MFA controls.
- Require analyst approval before blocking IP addresses.

### Recovery and Validation

- Reset affected credentials if compromise is confirmed.
- Review exposed services and authentication policies.
- Monitor for recurring authentication attempts.

---

## Denial of Service

### Related Dataset Labels

- DDoS
- DoS GoldenEye
- DoS Hulk
- DoS Slowhttptest
- DoS slowloris

### Investigation

- Review traffic rates and connection patterns.
- Check service health and resource utilization.
- Determine whether service availability was affected.

### Containment Recommendations

- Consider rate limiting and traffic filtering.
- Review CDN, WAF, and upstream protection options.
- Require approval before disruptive network changes.

### Recovery and Validation

- Verify service availability and performance.
- Review capacity and protection configurations.
- Continue monitoring for renewed traffic spikes.

---

## Network Reconnaissance

### Related Dataset Labels

- PortScan

### Investigation

- Review destination port patterns.
- Correlate network flows with firewall logs.
- Identify exposed services where evidence permits.

### Containment Recommendations

- Review unnecessary exposed ports.
- Consider access-control adjustments after validation.

### Recovery and Validation

- Confirm required services remain accessible.
- Monitor for subsequent exploitation attempts.

---

## Web Application Attack

### Related Dataset Labels

- Web Attack - Sql Injection
- Web Attack - XSS

### Investigation

- Review application, web server, and WAF logs.
- Identify suspicious requests and application errors.
- Check for evidence of successful exploitation.

### Containment Recommendations

- Consider validated WAF rules.
- Review vulnerable application endpoints.
- Require approval before production configuration changes.

### Recovery and Validation

- Patch confirmed vulnerabilities.
- Validate fixes through authorized security testing.
- Monitor for repeated exploitation attempts.

---

## Potential Compromise or Exploitation

### Related Dataset Labels

- Bot
- Heartbleed
- Infiltration

### Investigation

- Review relevant host, application, and network logs.
- Determine whether compromise or exploitation occurred.
- Identify affected assets using corroborating evidence.

### Containment Recommendations

- Consider host isolation only after analyst review.
- Preserve relevant forensic evidence.
- Avoid destructive or automated containment.

### Recovery and Validation

- Remediate confirmed vulnerabilities or persistence.
- Restore affected systems using approved procedures.
- Validate system integrity and continue monitoring.

---
