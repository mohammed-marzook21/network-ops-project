# Synapt Sentinel - MITRE ATT&CK Knowledge Pack

Purpose: Provide investigation context for CIC-IDS2017 incidents.

Important interpretation rules:
- MITRE mappings are contextual hypotheses, not confirmed detections.
- Dataset labels are not proof that a technique succeeded.
- Do not infer source IPs, destination IPs, compromised accounts,
  attacker identities, or service impact from missing evidence.
- Do not assign numerical confidence or incident severity solely
  from a dataset label.
- Recommendations require analyst review before disruptive action.


Generated: 2026-10-10

## T1110 - Brute Force

ATT&CK Tactic: Credential Access
Official Reference: https://attack.mitre.org/techniques/T1110/
Mapping Status: Contextual mapping

### Related CIC-IDS2017 Labels

- SSH-Patator
- FTP-Patator
- Web Attack - Brute Force

### Mapping Rationale

These dataset categories describe brute-force activity. The sampled flow records alone do not prove individual authentication attempts.

### Recommended Investigation

- Review authentication success and failure logs.
- Identify affected accounts and services.
- Check timestamps, rate patterns, and source addresses using additional logs where available.

---

## T1498 - Network Denial of Service

ATT&CK Tactic: Impact
Official Reference: https://attack.mitre.org/techniques/T1498/
Mapping Status: Contextual mapping

### Related CIC-IDS2017 Labels

- DDoS

### Mapping Rationale

The DDoS dataset category is relevant to network availability attacks. Ten sampled flows cannot establish network saturation or actual service impact.

### Recommended Investigation

- Review traffic volume and bandwidth utilization.
- Check network device counters and service availability.
- Correlate flows with firewall and load-balancer logs.

---

## T1190 - Exploit Public-Facing Application

ATT&CK Tactic: Initial Access
Official Reference: https://attack.mitre.org/techniques/T1190/
Mapping Status: Conditional mapping

### Related CIC-IDS2017 Labels

- Web Attack - Sql Injection
- Web Attack - XSS

### Mapping Rationale

These categories may be relevant to exploitation of a public-facing application. The mapping requires confirmation that a public-facing application was targeted and exploitation occurred.

### Recommended Investigation

- Review web server, application, and WAF logs.
- Check for suspicious requests and application errors.
- Look for evidence of successful exploitation.

---
