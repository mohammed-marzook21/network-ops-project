# CIC-IDS2017 SSH-Patator Incident

Incident ID: CIC-SSH-001
Dataset: CIC-IDS2017
Attack Type: SSH-Patator
Number of Flows: 10
Severity: unassessed

## Incident Summary
A sample of network-flow records labeled SSH-Patator in the CIC-IDS2017 dataset.

## Network Flow Evidence

### FLOW-001
- Destination Port: 22
- Flow Duration: 404 microseconds
- Forward Packets: 2
- Backward Packets: 0
- Dataset Label: SSH-Patator

### FLOW-002
- Destination Port: 22
- Flow Duration: 5808851 microseconds
- Forward Packets: 15
- Backward Packets: 18
- Dataset Label: SSH-Patator

### FLOW-003
- Destination Port: 22
- Flow Duration: 5840763 microseconds
- Forward Packets: 18
- Backward Packets: 19
- Dataset Label: SSH-Patator

### FLOW-004
- Destination Port: 22
- Flow Duration: 5797001 microseconds
- Forward Packets: 17
- Backward Packets: 19
- Dataset Label: SSH-Patator

### FLOW-005
- Destination Port: 22
- Flow Duration: 5776990 microseconds
- Forward Packets: 15
- Backward Packets: 19
- Dataset Label: SSH-Patator

### FLOW-006
- Destination Port: 22
- Flow Duration: 20 microseconds
- Forward Packets: 1
- Backward Packets: 1
- Dataset Label: SSH-Patator

### FLOW-007
- Destination Port: 22
- Flow Duration: 69 microseconds
- Forward Packets: 1
- Backward Packets: 1
- Dataset Label: SSH-Patator

### FLOW-008
- Destination Port: 22
- Flow Duration: 6114814 microseconds
- Forward Packets: 17
- Backward Packets: 19
- Dataset Label: SSH-Patator

### FLOW-009
- Destination Port: 22
- Flow Duration: 84 microseconds
- Forward Packets: 1
- Backward Packets: 1
- Dataset Label: SSH-Patator

### FLOW-010
- Destination Port: 22
- Flow Duration: 58 microseconds
- Forward Packets: 1
- Backward Packets: 1
- Dataset Label: SSH-Patator

## Evidence Interpretation

The CIC-IDS2017 dataset labels these sampled flows as SSH-Patator.
All sampled flows target destination port 22.
These records are dataset observations, not live security alerts.
Source and destination IP addresses are not available in this CSV.
Incident severity has not yet been independently assessed.

## Analyst Review

Further investigation is required before recommending or executing
any network blocking or other mitigation action.