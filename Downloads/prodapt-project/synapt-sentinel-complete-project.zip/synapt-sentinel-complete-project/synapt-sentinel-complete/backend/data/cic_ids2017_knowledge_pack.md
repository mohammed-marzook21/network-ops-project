# Synapt Sentinel — CIC-IDS2017 Incident Knowledge Pack

Source: CIC-IDS2017 MachineLearningCSV dataset.

This document contains sampled network-flow records.
Attack types are dataset labels, not independent AI detections.
Severity is unassessed unless explicitly established.
No source or destination IP addresses are inferred.
No remediation actions have been executed.

## Incident CIC-SSH-001

Incident ID: CIC-SSH-001
Attack Type: SSH-Patator
Dataset Source: CIC-IDS2017
Original CSV: ssh_patator_sample.csv
Dataset Labels: ['SSH-Patator']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 22
Flow Duration (microseconds): 404
Forward Packets: 2
Backward Packets: 0
Dataset Label: SSH-Patator

Flow ID: FLOW-002
Destination Port: 22
Flow Duration (microseconds): 5808851
Forward Packets: 15
Backward Packets: 18
Dataset Label: SSH-Patator

Flow ID: FLOW-003
Destination Port: 22
Flow Duration (microseconds): 5840763
Forward Packets: 18
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-004
Destination Port: 22
Flow Duration (microseconds): 5797001
Forward Packets: 17
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-005
Destination Port: 22
Flow Duration (microseconds): 5776990
Forward Packets: 15
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-006
Destination Port: 22
Flow Duration (microseconds): 20
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-007
Destination Port: 22
Flow Duration (microseconds): 69
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-008
Destination Port: 22
Flow Duration (microseconds): 6114814
Forward Packets: 17
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-009
Destination Port: 22
Flow Duration (microseconds): 84
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-010
Destination Port: 22
Flow Duration (microseconds): 58
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-FTP-001

Incident ID: CIC-FTP-001
Attack Type: FTP-Patator
Dataset Source: CIC-IDS2017
Original CSV: ftp_patator_sample.csv
Dataset Labels: ['FTP-Patator']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5216127
Forward Packets: 3
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-002
Destination Port: 21
Flow Duration (microseconds): 20
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-003
Destination Port: 21
Flow Duration (microseconds): 38
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-004
Destination Port: 21
Flow Duration (microseconds): 80
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-005
Destination Port: 21
Flow Duration (microseconds): 68
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-006
Destination Port: 21
Flow Duration (microseconds): 47
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-007
Destination Port: 21
Flow Duration (microseconds): 83
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-008
Destination Port: 21
Flow Duration (microseconds): 265
Forward Packets: 2
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-009
Destination Port: 21
Flow Duration (microseconds): 3302859
Forward Packets: 6
Backward Packets: 6
Dataset Label: FTP-Patator

Flow ID: FLOW-010
Destination Port: 21
Flow Duration (microseconds): 3
Forward Packets: 2
Backward Packets: 0
Dataset Label: FTP-Patator

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-001

Incident ID: CIC-AUTO-001
Attack Type: Bot
Dataset Source: CIC-IDS2017
Original CSV: Friday-WorkingHours-Morning.pcap_ISCX.csv
Dataset Labels: ['Bot']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 8080
Flow Duration (microseconds): 60202640
Forward Packets: 9
Backward Packets: 9
Dataset Label: Bot

Flow ID: FLOW-002
Destination Port: 8080
Flow Duration (microseconds): 57891
Forward Packets: 1
Backward Packets: 1
Dataset Label: Bot

Flow ID: FLOW-003
Destination Port: 8080
Flow Duration (microseconds): 134812
Forward Packets: 4
Backward Packets: 3
Dataset Label: Bot

Flow ID: FLOW-004
Destination Port: 1841
Flow Duration (microseconds): 84
Forward Packets: 1
Backward Packets: 1
Dataset Label: Bot

Flow ID: FLOW-005
Destination Port: 8080
Flow Duration (microseconds): 127781
Forward Packets: 4
Backward Packets: 3
Dataset Label: Bot

Flow ID: FLOW-006
Destination Port: 1845
Flow Duration (microseconds): 33
Forward Packets: 1
Backward Packets: 1
Dataset Label: Bot

Flow ID: FLOW-007
Destination Port: 8080
Flow Duration (microseconds): 165810
Forward Packets: 5
Backward Packets: 4
Dataset Label: Bot

Flow ID: FLOW-008
Destination Port: 8080
Flow Duration (microseconds): 65033
Forward Packets: 4
Backward Packets: 3
Dataset Label: Bot

Flow ID: FLOW-009
Destination Port: 1846
Flow Duration (microseconds): 42
Forward Packets: 1
Backward Packets: 1
Dataset Label: Bot

Flow ID: FLOW-010
Destination Port: 1847
Flow Duration (microseconds): 29
Forward Packets: 1
Backward Packets: 1
Dataset Label: Bot

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-002

Incident ID: CIC-AUTO-002
Attack Type: DDoS
Dataset Source: CIC-IDS2017
Original CSV: Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv
Dataset Labels: ['DDoS']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 1293792
Forward Packets: 3
Backward Packets: 7
Dataset Label: DDoS

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 4421382
Forward Packets: 4
Backward Packets: 0
Dataset Label: DDoS

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 1083538
Forward Packets: 3
Backward Packets: 6
Dataset Label: DDoS

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 80034360
Forward Packets: 8
Backward Packets: 4
Dataset Label: DDoS

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 642654
Forward Packets: 3
Backward Packets: 6
Dataset Label: DDoS

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 79731718
Forward Packets: 8
Backward Packets: 5
Dataset Label: DDoS

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 306157
Forward Packets: 3
Backward Packets: 6
Dataset Label: DDoS

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 79780371
Forward Packets: 8
Backward Packets: 4
Dataset Label: DDoS

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 682575
Forward Packets: 3
Backward Packets: 5
Dataset Label: DDoS

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 79098660
Forward Packets: 8
Backward Packets: 6
Dataset Label: DDoS

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-003

Incident ID: CIC-AUTO-003
Attack Type: DoS GoldenEye
Dataset Source: CIC-IDS2017
Original CSV: Wednesday-workingHours.pcap_ISCX.csv
Dataset Labels: ['DoS GoldenEye']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5008837
Forward Packets: 4
Backward Packets: 5
Dataset Label: DoS GoldenEye

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 5008159
Forward Packets: 7
Backward Packets: 5
Dataset Label: DoS GoldenEye

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 5004971
Forward Packets: 7
Backward Packets: 6
Dataset Label: DoS GoldenEye

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 5004703
Forward Packets: 7
Backward Packets: 5
Dataset Label: DoS GoldenEye

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 5005677
Forward Packets: 8
Backward Packets: 6
Dataset Label: DoS GoldenEye

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 5005163
Forward Packets: 8
Backward Packets: 5
Dataset Label: DoS GoldenEye

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 5006562
Forward Packets: 8
Backward Packets: 6
Dataset Label: DoS GoldenEye

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 5007321
Forward Packets: 8
Backward Packets: 6
Dataset Label: DoS GoldenEye

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 5020607
Forward Packets: 8
Backward Packets: 6
Dataset Label: DoS GoldenEye

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 5020047
Forward Packets: 5
Backward Packets: 4
Dataset Label: DoS GoldenEye

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-004

Incident ID: CIC-AUTO-004
Attack Type: DoS Hulk
Dataset Source: CIC-IDS2017
Original CSV: Wednesday-workingHours.pcap_ISCX.csv
Dataset Labels: ['DoS Hulk']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 1878
Forward Packets: 3
Backward Packets: 6
Dataset Label: DoS Hulk

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 1550
Forward Packets: 3
Backward Packets: 6
Dataset Label: DoS Hulk

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 497
Forward Packets: 4
Backward Packets: 0
Dataset Label: DoS Hulk

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 1893
Forward Packets: 3
Backward Packets: 7
Dataset Label: DoS Hulk

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 1942
Forward Packets: 3
Backward Packets: 6
Dataset Label: DoS Hulk

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 3720
Forward Packets: 3
Backward Packets: 6
Dataset Label: DoS Hulk

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 1381
Forward Packets: 3
Backward Packets: 4
Dataset Label: DoS Hulk

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 4357
Forward Packets: 3
Backward Packets: 6
Dataset Label: DoS Hulk

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 684
Forward Packets: 2
Backward Packets: 0
Dataset Label: DoS Hulk

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 2791
Forward Packets: 3
Backward Packets: 5
Dataset Label: DoS Hulk

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-005

Incident ID: CIC-AUTO-005
Attack Type: DoS Slowhttptest
Dataset Source: CIC-IDS2017
Original CSV: Wednesday-workingHours.pcap_ISCX.csv
Dataset Labels: ['DoS Slowhttptest']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 16045
Forward Packets: 5
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 109998919
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 109993343
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 109988359
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 109982960
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 109977744
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 109967320
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 109962098
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 109972494
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 109956889
Forward Packets: 4
Backward Packets: 3
Dataset Label: DoS Slowhttptest

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-006

Incident ID: CIC-AUTO-006
Attack Type: DoS slowloris
Dataset Source: CIC-IDS2017
Original CSV: Wednesday-workingHours.pcap_ISCX.csv
Dataset Labels: ['DoS slowloris']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5169956
Forward Packets: 8
Backward Packets: 6
Dataset Label: DoS slowloris

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 229
Forward Packets: 2
Backward Packets: 0
Dataset Label: DoS slowloris

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 5001928
Forward Packets: 3
Backward Packets: 1
Dataset Label: DoS slowloris

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 5125872
Forward Packets: 8
Backward Packets: 7
Dataset Label: DoS slowloris

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 214
Forward Packets: 2
Backward Packets: 0
Dataset Label: DoS slowloris

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 5001683
Forward Packets: 3
Backward Packets: 1
Dataset Label: DoS slowloris

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 507096
Forward Packets: 6
Backward Packets: 1
Dataset Label: DoS slowloris

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 507376
Forward Packets: 6
Backward Packets: 1
Dataset Label: DoS slowloris

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 507477
Forward Packets: 6
Backward Packets: 1
Dataset Label: DoS slowloris

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 507581
Forward Packets: 6
Backward Packets: 1
Dataset Label: DoS slowloris

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-007

Incident ID: CIC-AUTO-007
Attack Type: FTP-Patator
Dataset Source: CIC-IDS2017
Original CSV: Tuesday-WorkingHours.pcap_ISCX.csv
Dataset Labels: ['FTP-Patator']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5216127
Forward Packets: 3
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-002
Destination Port: 21
Flow Duration (microseconds): 20
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-003
Destination Port: 21
Flow Duration (microseconds): 38
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-004
Destination Port: 21
Flow Duration (microseconds): 80
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-005
Destination Port: 21
Flow Duration (microseconds): 68
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-006
Destination Port: 21
Flow Duration (microseconds): 47
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-007
Destination Port: 21
Flow Duration (microseconds): 83
Forward Packets: 1
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-008
Destination Port: 21
Flow Duration (microseconds): 265
Forward Packets: 2
Backward Packets: 1
Dataset Label: FTP-Patator

Flow ID: FLOW-009
Destination Port: 21
Flow Duration (microseconds): 3302859
Forward Packets: 6
Backward Packets: 6
Dataset Label: FTP-Patator

Flow ID: FLOW-010
Destination Port: 21
Flow Duration (microseconds): 3
Forward Packets: 2
Backward Packets: 0
Dataset Label: FTP-Patator

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-008

Incident ID: CIC-AUTO-008
Attack Type: Heartbleed
Dataset Source: CIC-IDS2017
Original CSV: Wednesday-workingHours.pcap_ISCX.csv
Dataset Labels: ['Heartbleed']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 444
Flow Duration (microseconds): 119302728
Forward Packets: 2685
Backward Packets: 1729
Dataset Label: Heartbleed

Flow ID: FLOW-002
Destination Port: 444
Flow Duration (microseconds): 119262215
Forward Packets: 2792
Backward Packets: 2110
Dataset Label: Heartbleed

Flow ID: FLOW-003
Destination Port: 444
Flow Duration (microseconds): 119261118
Forward Packets: 2794
Backward Packets: 2130
Dataset Label: Heartbleed

Flow ID: FLOW-004
Destination Port: 444
Flow Duration (microseconds): 119260295
Forward Packets: 2791
Backward Packets: 2114
Dataset Label: Heartbleed

Flow ID: FLOW-005
Destination Port: 444
Flow Duration (microseconds): 119297996
Forward Packets: 2782
Backward Packets: 2089
Dataset Label: Heartbleed

Flow ID: FLOW-006
Destination Port: 444
Flow Duration (microseconds): 119259886
Forward Packets: 2782
Backward Packets: 2091
Dataset Label: Heartbleed

Flow ID: FLOW-007
Destination Port: 444
Flow Duration (microseconds): 119259012
Forward Packets: 2801
Backward Packets: 2069
Dataset Label: Heartbleed

Flow ID: FLOW-008
Destination Port: 444
Flow Duration (microseconds): 119257653
Forward Packets: 2802
Backward Packets: 2067
Dataset Label: Heartbleed

Flow ID: FLOW-009
Destination Port: 444
Flow Duration (microseconds): 119299621
Forward Packets: 2805
Backward Packets: 2028
Dataset Label: Heartbleed

Flow ID: FLOW-010
Destination Port: 444
Flow Duration (microseconds): 119296592
Forward Packets: 2797
Backward Packets: 2006
Dataset Label: Heartbleed

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-009

Incident ID: CIC-AUTO-009
Attack Type: Infiltration
Dataset Source: CIC-IDS2017
Original CSV: Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv
Dataset Labels: ['Infiltration']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 444
Flow Duration (microseconds): 42664070
Forward Packets: 5
Backward Packets: 6
Dataset Label: Infiltration

Flow ID: FLOW-002
Destination Port: 444
Flow Duration (microseconds): 2030
Forward Packets: 2
Backward Packets: 0
Dataset Label: Infiltration

Flow ID: FLOW-003
Destination Port: 444
Flow Duration (microseconds): 119991834
Forward Packets: 5523
Backward Packets: 5525
Dataset Label: Infiltration

Flow ID: FLOW-004
Destination Port: 444
Flow Duration (microseconds): 5005212
Forward Packets: 15
Backward Packets: 15
Dataset Label: Infiltration

Flow ID: FLOW-005
Destination Port: 444
Flow Duration (microseconds): 119973135
Forward Packets: 4376
Backward Packets: 4374
Dataset Label: Infiltration

Flow ID: FLOW-006
Destination Port: 444
Flow Duration (microseconds): 119974830
Forward Packets: 3398
Backward Packets: 3398
Dataset Label: Infiltration

Flow ID: FLOW-007
Destination Port: 444
Flow Duration (microseconds): 119993844
Forward Packets: 3813
Backward Packets: 3811
Dataset Label: Infiltration

Flow ID: FLOW-008
Destination Port: 444
Flow Duration (microseconds): 78233714
Forward Packets: 48
Backward Packets: 52
Dataset Label: Infiltration

Flow ID: FLOW-009
Destination Port: 444
Flow Duration (microseconds): 118573317
Forward Packets: 3733
Backward Packets: 3732
Dataset Label: Infiltration

Flow ID: FLOW-010
Destination Port: 444
Flow Duration (microseconds): 119992821
Forward Packets: 2252
Backward Packets: 2250
Dataset Label: Infiltration

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-010

Incident ID: CIC-AUTO-010
Attack Type: PortScan
Dataset Source: CIC-IDS2017
Original CSV: Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv
Dataset Labels: ['PortScan']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5021059
Forward Packets: 6
Backward Packets: 5
Dataset Label: PortScan

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 70
Forward Packets: 1
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 5024211
Forward Packets: 6
Backward Packets: 5
Dataset Label: PortScan

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 52
Forward Packets: 1
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 5386396
Forward Packets: 3
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 5018079
Forward Packets: 6
Backward Packets: 5
Dataset Label: PortScan

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 101
Forward Packets: 1
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 5001169
Forward Packets: 3
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 671
Forward Packets: 2
Backward Packets: 1
Dataset Label: PortScan

Flow ID: FLOW-010
Destination Port: 443
Flow Duration (microseconds): 102
Forward Packets: 1
Backward Packets: 1
Dataset Label: PortScan

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-011

Incident ID: CIC-AUTO-011
Attack Type: SSH-Patator
Dataset Source: CIC-IDS2017
Original CSV: Tuesday-WorkingHours.pcap_ISCX.csv
Dataset Labels: ['SSH-Patator']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 22
Flow Duration (microseconds): 404
Forward Packets: 2
Backward Packets: 0
Dataset Label: SSH-Patator

Flow ID: FLOW-002
Destination Port: 22
Flow Duration (microseconds): 5808851
Forward Packets: 15
Backward Packets: 18
Dataset Label: SSH-Patator

Flow ID: FLOW-003
Destination Port: 22
Flow Duration (microseconds): 5840763
Forward Packets: 18
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-004
Destination Port: 22
Flow Duration (microseconds): 5797001
Forward Packets: 17
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-005
Destination Port: 22
Flow Duration (microseconds): 5776990
Forward Packets: 15
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-006
Destination Port: 22
Flow Duration (microseconds): 20
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-007
Destination Port: 22
Flow Duration (microseconds): 69
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-008
Destination Port: 22
Flow Duration (microseconds): 6114814
Forward Packets: 17
Backward Packets: 19
Dataset Label: SSH-Patator

Flow ID: FLOW-009
Destination Port: 22
Flow Duration (microseconds): 84
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

Flow ID: FLOW-010
Destination Port: 22
Flow Duration (microseconds): 58
Forward Packets: 1
Backward Packets: 1
Dataset Label: SSH-Patator

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-012

Incident ID: CIC-AUTO-012
Attack Type: Web Attack - Brute Force
Dataset Source: CIC-IDS2017
Original CSV: Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
Dataset Labels: ['Web Attack - Brute Force']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5185118
Forward Packets: 7
Backward Packets: 7
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 5057374
Forward Packets: 10
Backward Packets: 7
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 81
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 5271123
Forward Packets: 7
Backward Packets: 5
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 5020638
Forward Packets: 7
Backward Packets: 4
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 1629049
Forward Packets: 12
Backward Packets: 8
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 5088371
Forward Packets: 4
Backward Packets: 4
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 21405204
Forward Packets: 28
Backward Packets: 19
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 66
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Brute Force

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 4050296
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - Brute Force

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-013

Incident ID: CIC-AUTO-013
Attack Type: Web Attack - Sql Injection
Dataset Source: CIC-IDS2017
Original CSV: Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
Dataset Labels: ['Web Attack - Sql Injection']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5006127
Forward Packets: 4
Backward Packets: 4
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 508
Forward Packets: 2
Backward Packets: 1
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 5069927
Forward Packets: 4
Backward Packets: 4
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 42
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 5038618
Forward Packets: 4
Backward Packets: 4
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 43
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 5086516
Forward Packets: 5
Backward Packets: 4
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 48
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 5006168
Forward Packets: 4
Backward Packets: 4
Dataset Label: Web Attack - Sql Injection

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 78
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - Sql Injection

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---

## Incident CIC-AUTO-014

Incident ID: CIC-AUTO-014
Attack Type: Web Attack - XSS
Dataset Source: CIC-IDS2017
Original CSV: Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
Dataset Labels: ['Web Attack - XSS']
Severity: unassessed
Analysis Status: pending
Sampled Record Count: 10

### Network Flow Evidence

Flow ID: FLOW-001
Destination Port: 80
Flow Duration (microseconds): 5638432
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-002
Destination Port: 80
Flow Duration (microseconds): 5638527
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-003
Destination Port: 80
Flow Duration (microseconds): 5945704
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-004
Destination Port: 80
Flow Duration (microseconds): 6075117
Forward Packets: 16
Backward Packets: 12
Dataset Label: Web Attack - XSS

Flow ID: FLOW-005
Destination Port: 80
Flow Duration (microseconds): 34
Forward Packets: 1
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-006
Destination Port: 80
Flow Duration (microseconds): 3958444
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-007
Destination Port: 80
Flow Duration (microseconds): 4020679
Forward Packets: 20
Backward Packets: 11
Dataset Label: Web Attack - XSS

Flow ID: FLOW-008
Destination Port: 80
Flow Duration (microseconds): 3607565
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-009
Destination Port: 80
Flow Duration (microseconds): 3607613
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

Flow ID: FLOW-010
Destination Port: 80
Flow Duration (microseconds): 5607142
Forward Packets: 3
Backward Packets: 1
Dataset Label: Web Attack - XSS

### Evidence Limitations

These records are samples, not the full incident.
The CSV records used here do not include source or destination IP addresses.
The dataset label does not establish incident severity.
Any defensive recommendation requires contextual review.

---
