
from datetime import datetime, timezone


def generate_incident_report(
    incident,
    local_analysis,
    response_recommendations,
):
    incident_id = incident.get("incident_id", "Unknown")
    attack_type = incident.get("attack_type", "Unknown")

    statistics = local_analysis.get("statistics", {})

    investigation_steps = response_recommendations.get(
        "investigation_steps", []
    )

    recommendations = response_recommendations.get(
        "recommendations", []
    )

    ports = statistics.get("common_destination_ports", [])

    generated_at = datetime.now(timezone.utc).strftime(
        "%Y-%m-%d %H:%M:%S UTC"
    )

    lines = [
        "# Synapt Sentinel - Incident Investigation Report",
        "",
        f"**Incident ID:** {incident_id}",
        f"**Dataset Attack Label:** {attack_type}",
        f"**Dataset Source:** {incident.get('source', 'Unknown')}",
        f"**Source File:** {incident.get('source_file', 'Unknown')}",
        f"**Generated:** {generated_at}",
        "",
        "## Assessment Status",
        "",
        "- Severity: Unassessed",
        "- AI confidence: Not assigned",
        "- Evidence status: Dataset-label-based",
        "- Containment execution: None",
        "",
        "## Sampled Network Flow Statistics",
        "",
        f"- Sample size: {local_analysis.get('sample_size', 0)} flows",
        (
            "- Average flow duration (microseconds): "
            f"{statistics.get('average_flow_duration_microseconds')}"
        ),
        (
            "- Total forward packets: "
            f"{statistics.get('total_forward_packets')}"
        ),
        (
            "- Total backward packets: "
            f"{statistics.get('total_backward_packets')}"
        ),
        "",
        "### Common Destination Ports",
        "",
    ]

    if ports:
        for entry in ports:
            lines.append(
                f"- Port {entry['port']}: "
                f"{entry['count']} sampled flows"
            )
    else:
        lines.append("- No destination-port data available")

    lines.extend([
        "",
        "## Investigation Steps",
        "",
    ])

    for index, step in enumerate(investigation_steps, 1):
        lines.append(f"{index}. {step}")

    lines.extend([
        "",
        "## Recommended Response Actions",
        "",
    ])

    for recommendation in recommendations:
        lines.append(f"- {recommendation}")

    lines.extend([
        "",
        "## Evidence Limitations",
        "",
    ])

    for limitation in local_analysis.get("limitations", []):
        lines.append(f"- {limitation}")

    lines.extend([
        "",
        "## Safety and Approval",
        "",
        (
            "All disruptive actions require explicit analyst "
            "approval. This report contains recommendations only."
        ),
        "",
        (
            "No blocking, host isolation, credential reset, "
            "or firewall changes were executed."
        ),
        "",
        "## Evidence Provenance",
        "",
        (
            "This report is generated from locally stored "
            "CIC-IDS2017 incident samples and deterministic "
            "analysis. It is not a verified Synapt.AI finding."
        ),
        "",
        (
            "Dataset labels do not independently prove "
            "successful exploitation or service disruption."
        ),
        "",
    ])

    return "\n".join(lines)
