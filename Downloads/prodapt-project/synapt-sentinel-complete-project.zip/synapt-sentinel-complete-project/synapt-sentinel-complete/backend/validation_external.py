"""Evaluate a FROZEN trained model on user-supplied independent labeled CSV.

Do not use CIC-IDS2017 captures reused in V2/V3 experiments as 'independent'.
Rows are processed in bounded chunks, no model fitting or threshold tuning.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from model_pipeline import FEATURE_COLUMNS, clean_label, canonical_columns


def evaluate(model_path, csv_path, output, chunksize=10000):
    artifact=joblib.load(model_path)  # Load ONLY locally trusted artifacts. joblib is executable pickle.
    model=artifact.get('binary_classifier')
    if model is None:raise ValueError('Artifact has no trained binary model')
    threshold=float(artifact.get('binary_threshold',.5))
    labels=[]; scores=[]; counts={}; rows=0; absent=set()
    for chunk in pd.read_csv(csv_path,chunksize=chunksize,low_memory=False,encoding_errors='replace'):
        chunk=canonical_columns(chunk)
        missing=[column for column in FEATURE_COLUMNS+['Label'] if column not in chunk.columns]
        if missing:raise ValueError(f'Missing columns: {missing}')
        frame=chunk[FEATURE_COLUMNS].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
        valid=~frame.isna().all(axis=1)
        truth=chunk['Label'].map(clean_label)
        valid &= truth.notna() & (truth.astype(str).str.strip()!='')
        if not valid.any():continue
        frame=frame[valid]; truth=truth[valid]
        prob=model.predict_proba(frame)[:,list(model.classes_).index(1)]
        labels.extend((truth != 'BENIGN').astype('int8').tolist())
        scores.extend(prob.tolist())
        absent.update(set(truth)-set(artifact.get('classes',[])))
        for label,count in truth.value_counts().items():counts[label]=counts.get(label,0)+int(count)
        rows+=len(truth)
    if rows==0:raise ValueError('No valid labeled samples')
    y=np.asarray(labels,dtype=int);p=np.asarray(scores)
    predicted=p>=threshold
    tp=int(((y==1)&predicted).sum());tn=int(((y==0)&~predicted).sum())
    fp=int(((y==0)&predicted).sum());fn=int(((y==1)&~predicted).sum())
    out={'source_csv':str(Path(csv_path).name), 'evaluation':'frozen_model_external_capture',
         'rows':rows, 'labels':counts, 'unknown_training_labels':sorted(absent),
         'threshold_frozen':threshold,
         'confusion':{'tp':tp,'tn':tn,'fp':fp,'fn':fn},
         'attack_recall':tp/(tp+fn) if tp+fn else None,
         'false_positive_rate':fp/(fp+tn) if fp+tn else None,
         'precision':tp/(tp+fp) if tp+fp else None,
         'roc_auc':float(roc_auc_score(y,p)) if len(set(y))==2 else None,
         'average_precision':float(average_precision_score(y,p)) if y.sum() else None,
         'brier_score':float(brier_score_loss(y,p)),
         'score_is_calibrated':False,
         'interpretation':['Do not select thresholds on this test CSV',
                           'Independence must be documented by investigator; this code cannot verify provenance',
                           'Probability calibration does not transfer automatically between captures']}
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--csv',required=True)
    parser.add_argument('--model',default=str(Path(__file__).resolve().parent/'artifacts'/'models'/'models.joblib'))
    parser.add_argument('--output',default=str(Path(__file__).resolve().parent/'artifacts'/'validation_external.json'))
    parser.add_argument('--chunksize',type=int,default=10000)
    args=parser.parse_args()
    print(json.dumps(evaluate(args.model,args.csv,args.output,args.chunksize),indent=2))
