from model_v33_review_effectiveness import compare
import pytest


def sample():
    methods = {}
    for method in ('anomaly', 'supervised', 'hybrid'):
        methods[method] = {'reviewed': 4, 'rescued_attacks': 2, 'benign_reviews': 2,
                           'missed_attacks_before_review': 3}
    return {'settings': {'review_budgets': [.05]}, 'captures': [
        {'held_out_capture': 'a.csv', 'status': 'evaluated',
         'supervised': {'recall': .5, 'fpr': .02},
         'review_by_budget': {'0.0500': methods}},
        {'held_out_capture': 'skipped.csv', 'status': 'insufficient_data'},
    ]}


def test_aggregate_and_precision():
    result = compare(sample())
    assert len(result['by_capture']) == 3
    assert result['aggregate'][0]['review_precision'] == .5
    assert result['aggregate'][0]['attacks_per_100_benign_reviews'] == 100
    assert result['aggregate'][0]['fraction_of_missed_attacks_surfaced'] == pytest.approx(2/3)


def test_reject_inconsistent_counts():
    report = sample()
    report['captures'][0]['review_by_budget']['0.0500']['anomaly']['benign_reviews'] = 1
    with pytest.raises(ValueError, match='Inconsistent'):
        compare(report)


def test_zero_reviews():
    report = sample()
    for method in ('anomaly', 'supervised', 'hybrid'):
        report['captures'][0]['review_by_budget']['0.0500'][method].update(
            reviewed=0, rescued_attacks=0, benign_reviews=0)
    assert compare(report)['aggregate'][0]['review_precision'] is None
