import numpy as np
import pytest
from model_v32_escalation import select_review_indices, review_metrics


def test_review_budget_and_negative_only():
    s = np.array([.9, .1, .2, .3, .4, .5, .6, .7, .8, .05])
    a = np.arange(10) / 10
    for method in ('anomaly', 'supervised', 'hybrid'):
        indices = select_review_indices(s, a, .65, .3, method)
        assert len(indices) == 3
        assert np.all(s[indices] < .65)
        assert len(set(indices)) == 3


def test_anomaly_ranking_and_rescue():
    s = np.array([.8, .1, .2, .3, .4])
    a = np.array([0., .9, .8, .1, .2])
    y = np.array([1, 1, 0, 0, 0])
    idx = select_review_indices(s, a, .5, .4, 'anomaly')
    assert list(idx) == [1, 2]
    result = review_metrics(y, s, .5, idx)
    assert result['rescued_attacks'] == 1
    assert result['benign_reviews'] == 1
    assert result['fraction_of_missed_attacks_recovered'] == 1


def test_zero_budget_and_all_benign():
    s = np.array([.1, .2])
    a = np.array([.5, .6])
    assert len(select_review_indices(s, a, .9, 0, 'anomaly')) == 0
    result = review_metrics(np.zeros(2, dtype=int), s, .9, np.array([1]))
    assert result['rescued_attacks'] == 0
    assert result['fraction_of_missed_attacks_recovered'] is None


def test_invalid_inputs():
    with pytest.raises(ValueError):
        select_review_indices([.1], [.2, .3], .5, .1, 'anomaly')
    with pytest.raises(ValueError):
        select_review_indices([.1], [.2], .5, 1.1, 'anomaly')
    with pytest.raises(ValueError):
        review_metrics([0], [.9], .5, [0])
