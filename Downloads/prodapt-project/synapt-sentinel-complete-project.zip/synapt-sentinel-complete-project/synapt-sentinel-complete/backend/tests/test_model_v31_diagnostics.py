import numpy as np
import pytest
from model_v31_diagnostics import label_breakdown, run


def test_label_breakdown_unseen_and_scores():
    result = label_breakdown(['BENIGN', 'Bot', 'Bot'], [0.1, 0.2, 0.9], 0.5, {'DDoS'})
    assert result['Bot']['unseen_in_training'] is True
    assert result['Bot']['flagged'] == 1
    assert result['Bot']['flag_rate'] == .5
    assert result['BENIGN']['unseen_in_training'] is False


def test_invalid_inputs(tmp_path):
    with pytest.raises(ValueError):
        run([tmp_path / 'one.csv'], tmp_path / 'report.json')
    with pytest.raises(ValueError):
        run([tmp_path / f'{i}.csv' for i in range(3)], tmp_path / 'report.json', fpr_budget=1.0)
