"""Tiny synthetic smoke checks; synthetic performance is NEVER reported as model quality."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from model_pipeline import FEATURE_COLUMNS, train
from explain_api import explain
from validation_external import evaluate


def test_explain_and_frozen_validation(tmp_path):
    rows=[]
    for i in range(240):
        sample={field:float(i*3+(i%7)*j) for j,field in enumerate(FEATURE_COLUMNS)}
        sample['Label']='BENIGN' if i<120 else 'DDoS'
        rows.append(sample)
    csv=tmp_path/'train.csv'; pd.DataFrame(rows).to_csv(csv,index=False)
    output=tmp_path/'trained'
    train([csv],output,per_class=120,benign_cap=120,trees=8,importance_rows=12)
    import joblib
    artifact=joblib.load(output/'models.joblib')
    results=explain(artifact,[{f:float(i) for i,f in enumerate(FEATURE_COLUMNS)}])
    assert len(results[0]['feature_sensitivities'])==len(FEATURE_COLUMNS)
    assert results[0]['method']=='one_feature_at_a_time_replacement_with_training_median'
    # This uses the SAME synthetic file as training only to smoke-test the evaluator's mechanics.
    # It is explicitly NOT an independent holdout performance validation.
    report=evaluate(output/'models.joblib',csv,tmp_path/'eval.json',chunksize=50)
    assert report['rows']==240
    assert report['confusion']['tp']+report['confusion']['tn']+report['confusion']['fp']+report['confusion']['fn']==240
    assert (tmp_path/'eval.json').exists()
