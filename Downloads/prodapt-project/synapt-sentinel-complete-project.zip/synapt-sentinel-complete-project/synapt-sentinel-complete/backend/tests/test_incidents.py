
import json
import re
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    # Import here so test collection does not immediately
    # initialize the application.
    from main import app

    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture(scope="module")
def incidents(client):
    response = client.get("/api/incidents/dataset")

    assert response.status_code == 200

    payload = response.json()

    assert payload["success"] is True
    assert isinstance(payload["incidents"], list)
    assert payload["count"] == len(payload["incidents"])

    return payload["incidents"]


def test_incident_listing(incidents):
    assert len(incidents) >= 16

    incident_ids = [
        incident["incident_id"]
        for incident in incidents
    ]

    assert len(incident_ids) == len(set(incident_ids))

    assert "CIC-AUTO-011" in incident_ids
    assert "CIC-AUTO-002" in incident_ids


def test_incident_detail(client):
    response = client.get(
        "/api/incidents/dataset/CIC-AUTO-011"
    )

    assert response.status_code == 200

    payload = response.json()

    assert payload["success"] is True

    incident = payload["incident"]

    assert incident["incident_id"] == "CIC-AUTO-011"
    assert incident["attack_type"] == "SSH-Patator"
    assert incident["source"] == "CIC-IDS2017"

    assert incident["severity"] == "unassessed"

    assert isinstance(incident["flows"], list)
    assert len(incident["flows"]) == 10


def test_flow_measurements_are_numeric(client):
    response = client.get(
        "/api/incidents/dataset/CIC-AUTO-011"
    )

    assert response.status_code == 200

    flows = response.json()["incident"]["flows"]

    for flow in flows:
        assert int(flow["destination_port"]) >= 0
        assert int(flow["flow_duration"]) >= 0
        assert int(flow["total_forward_packets"]) >= 0
        assert int(flow["total_backward_packets"]) >= 0


def test_ssh_packet_totals(client):
    response = client.get(
        "/api/incidents/dataset/CIC-AUTO-011"
    )

    flows = response.json()["incident"]["flows"]

    forward = sum(
        int(flow["total_forward_packets"])
        for flow in flows
    )

    backward = sum(
        int(flow["total_backward_packets"])
        for flow in flows
    )

    assert forward == 88
    assert backward == 98

    assert {
        flow["destination_port"]
        for flow in flows
    } == {"22"}


def test_ddos_packet_totals(client):
    response = client.get(
        "/api/incidents/dataset/CIC-AUTO-002"
    )

    assert response.status_code == 200

    incident = response.json()["incident"]

    assert incident["attack_type"] == "DDoS"

    flows = incident["flows"]

    assert len(flows) == 10

    assert sum(
        int(flow["total_forward_packets"])
        for flow in flows
    ) == 51

    assert sum(
        int(flow["total_backward_packets"])
        for flow in flows
    ) == 49

    assert {
        flow["destination_port"]
        for flow in flows
    } == {"80"}


def test_local_analysis_endpoint(client):
    response = client.get(
        "/api/incidents/dataset/"
        "CIC-AUTO-002/local-analysis"
    )

    assert response.status_code == 200

    payload = response.json()

    assert isinstance(payload, dict)

    # Confirm the endpoint produces a nonempty result.
    assert payload


def test_response_recommendations(client):
    response = client.get(
        "/api/incidents/dataset/"
        "CIC-AUTO-011/recommendations"
    )

    assert response.status_code == 200

    payload = response.json()

    assert isinstance(payload, dict)
    assert payload


def test_markdown_report_download(client):
    response = client.get(
        "/api/incidents/dataset/"
        "CIC-AUTO-011/report"
    )

    assert response.status_code == 200

    assert response.headers["content-type"].startswith(
        "text/markdown"
    )

    assert "CIC-AUTO-011" in response.text

    assert "attachment" in response.headers.get(
        "content-disposition", ""
    ).lower()


def test_pdf_report_download(client):
    response = client.get(
        "/api/incidents/dataset/"
        "CIC-AUTO-011/report/pdf"
    )

    assert response.status_code == 200

    assert response.headers["content-type"].startswith(
        "application/pdf"
    )

    assert response.content.startswith(b"%PDF-")

    assert len(response.content) > 1000

    assert "attachment" in response.headers.get(
        "content-disposition", ""
    ).lower()


@pytest.mark.parametrize(
    "endpoint",
    [
        "/api/incidents/dataset/INVALID-INCIDENT",
        "/api/incidents/dataset/INVALID-INCIDENT/local-analysis",
        "/api/incidents/dataset/INVALID-INCIDENT/recommendations",
        "/api/incidents/dataset/INVALID-INCIDENT/report",
        "/api/incidents/dataset/INVALID-INCIDENT/report/pdf",
    ],
)
def test_invalid_incident_returns_404(client, endpoint):
    response = client.get(endpoint)

    assert response.status_code == 404
