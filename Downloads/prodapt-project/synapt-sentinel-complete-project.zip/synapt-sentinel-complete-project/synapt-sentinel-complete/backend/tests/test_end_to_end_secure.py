"""Security and investigation integration using fake predictions, no trained artifact needed."""
import json
import sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from model_pipeline import FEATURE_COLUMNS


@pytest.fixture
def client(tmp_path, monkeypatch):
    import security_api as auth
    import review_queue as q
    import main
    monkeypatch.setattr(auth,'DB_PATH',tmp_path/'auth.sqlite3')
    monkeypatch.setattr(q,'DB_PATH',tmp_path/'review.sqlite3')
    monkeypatch.setattr(q,'KEY_PATH',tmp_path/'review.audit.key')
    monkeypatch.setattr(auth,'enforce_limit',lambda *args:None)
    monkeypatch.setattr(q,'enforce_limit',lambda *args:None)
    fake=[{'predicted_intrusion':False,'intrusion_score':i/100,
           'attack_type':'BENIGN','anomaly_score':.1} for i in range(100)]
    monkeypatch.setattr(q,'load_model',lambda:object())
    monkeypatch.setattr(q,'predict',lambda artifact,flows:fake)
    auth.create_user('testadmin','secure-password-for-tests','admin')
    auth.create_user('testviewer','secure-password-for-viewer','viewer')
    with TestClient(main.app) as c:
        yield c


def token(c,username,password):
    response=c.post('/api/auth/login',json={'username':username,'password':password})
    assert response.status_code==200,response.text
    return {'Authorization':'Bearer '+response.json()['access_token']}


def test_login_roles_decision_and_audit(client):
    c=client
    assert c.get('/api/review/items').status_code==401
    assert c.post('/api/auth/login',json={'username':'testadmin','password':'wrong'}).status_code==401
    admin=token(c,'testadmin','secure-password-for-tests')
    viewer=token(c,'testviewer','secure-password-for-viewer')
    assert c.get('/api/auth/me',headers=viewer).json()['role']=='viewer'
    flows=[{f:1 for f in FEATURE_COLUMNS} for _ in range(100)]
    payload={'flows':flows,'review_budget':.05}
    assert c.post('/api/review/intake',json=payload,headers=viewer).status_code==403
    assert c.post('/api/review/intake',json={'flows':[{'Destination Port':80}]},headers=admin).status_code==422
    resp=c.post('/api/review/intake',json=payload,headers=admin)
    assert resp.status_code==200,resp.text
    assert resp.json()['review_count']==5
    item_id=resp.json()['items'][0]['id']
    assert c.get('/api/review/items',headers=viewer).status_code==200
    assert c.post(f'/api/review/items/{item_id}/decision',json={'decision':'inconclusive'},headers=viewer).status_code==403
    # No spoofed reviewer field: server assigns it from authenticated session.
    decision=c.post(f'/api/review/items/{item_id}/decision',json={'decision':'inconclusive','note':'Not verified'},headers=admin)
    assert decision.status_code==200
    assert decision.json()['reviewer']=='testadmin'
    assert c.post(f'/api/review/items/{item_id}/decision',json={'decision':'benign'},headers=admin).status_code==409
    detail=c.get(f'/api/review/items/{item_id}',headers=admin).json()
    assert detail['audit_integrity']=='verified'
    assert len(detail['events'])==2
    assert c.post('/api/auth/logout',headers=admin).status_code==200
    assert c.get('/api/review/items',headers=admin).status_code==401


def test_local_workflow_grounding(client):
    c=client
    r=c.get('/api/workflow/readiness')
    assert r.status_code==200
    assert r.json()['indexed_incidents']>=16
    r=c.get('/api/workflow/incident/CIC-AUTO-011')
    assert r.status_code==200,r.text
    item=r.json()
    assert item['dataset_label_is_prediction'] is False
    assert len(item['workflow']['steps'])==4
    assert all(src['origin']=='local_incident' for src in item['evidence'])
    assert c.get('/api/workflow/incident/NOT-FOUND').status_code==404
    assert c.post('/api/incidents/analyze',json={'question':'is this compromised?'}).status_code==503
