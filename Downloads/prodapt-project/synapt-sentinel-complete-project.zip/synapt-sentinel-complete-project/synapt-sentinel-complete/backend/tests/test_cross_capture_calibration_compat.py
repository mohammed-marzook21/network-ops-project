import numpy as np
from sklearn.ensemble import ExtraTreesClassifier
from cross_capture_eval import calibrate_fitted_model


def test_frozen_calibration_does_not_refit_base_model():
    rng = np.random.default_rng(7)
    x = rng.normal(size=(100, 3))
    y = (x[:, 0] + x[:, 1] > 0).astype(int)
    model = ExtraTreesClassifier(n_estimators=10, random_state=7).fit(x[:60], y[:60])
    before = model.predict_proba(x[:10]).copy()
    cal = calibrate_fitted_model(model, x[60:], y[60:])
    assert np.allclose(before, model.predict_proba(x[:10]))
    probs = cal.predict_proba(x[60:])
    assert probs.shape == (40, 2)
    assert np.all(np.isfinite(probs))
    assert np.allclose(probs.sum(axis=1), 1)
