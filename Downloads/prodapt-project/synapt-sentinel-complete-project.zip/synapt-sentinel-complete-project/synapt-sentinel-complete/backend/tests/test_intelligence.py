from pathlib import Path
import pytest
from pydantic import ValidationError
from intelligence import HybridIndex,load_incidents,metadata,passes,indicators,investigate
from intelligence_api import incident_paths, SearchRequest, Filters
from model_pipeline import train, predict

@pytest.fixture(scope='module')
def demo():
    idx=HybridIndex(load_incidents(incident_paths()))
    assert len(idx.incidents)>=16
    return idx

def test_retrieval_respects_attack_filter(demo):
    hits=demo.search('ssh brute force',{'attack_type':'SSH-Patator'},top_k=10)
    assert hits and all(x['attack_type']=='SSH-Patator' for x in hits)
    assert all(x['evidence']['incident_id']==x['incident_id'] for x in hits)

def test_port_filter(demo):
    hits=demo.search('port 22',{'destination_port':22})
    assert hits and all(22 in x['metadata']['ports'] for x in hits)

def test_unknown_metadata_never_matches(demo):
    assert not demo.search('ssh',{'source_ip':'192.0.2.5'})
    assert not demo.search('ssh',{'protocol':'TCP'})
    assert not demo.search('ssh',{'start_time':'2017-01-01T00:00:00'})

def test_input_validation():
    with pytest.raises(ValidationError): SearchRequest(query=' ',top_k=2)
    with pytest.raises(ValidationError): SearchRequest(query='ssh',top_k=1000)
    with pytest.raises(ValidationError): Filters(source_ip='fakeip')
    with pytest.raises(ValidationError): Filters(destination_port=65536)

def test_risk_is_explainable_not_confidence(demo):
    result=indicators(demo.incidents[0])
    assert 0<=result['heuristic_priority_score']<=100
    assert result['priority_method']=='transparent_heuristic_unvalidated'
    assert all(x['weight']>=0 for x in result['signals'])

def test_workflow_and_no_automated_response(demo):
    result=investigate(demo.incidents[0],demo)
    assert [x['agent'] for x in result['steps']]==['detection','analysis','risk_assessment','response_recommendation']
    assert result['execution_status']=='not_executed'
    assert result['requires_analyst_approval']

def test_bad_training_data_is_rejected(tmp_path):
    import pandas as pd
    p=tmp_path/'only_capture.csv'
    pd.DataFrame({'Label':['BENIGN','DDoS'],'Destination Port':[22,80],
                  'Flow Duration':[5,6],'Total Fwd Packets':[1,2],
                  'Total Backward Packets':[1,2]}).to_csv(p,index=False)
    with pytest.raises(ValueError,match='missing'):
        train([p],tmp_path/'output')
