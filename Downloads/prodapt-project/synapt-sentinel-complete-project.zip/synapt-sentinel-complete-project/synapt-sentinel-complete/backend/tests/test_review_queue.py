from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from fastapi import HTTPException
from model_pipeline import FEATURE_COLUMNS
import review_queue as q


def test_budget_and_ranking():
    predictions = [{'predicted_intrusion': False, 'intrusion_score': i / 100} for i in range(100)]
    predictions[99]['predicted_intrusion'] = True
    assert q.rank_candidates(predictions, .03) == [(98, .98), (97, .97), (96, .96)]
    assert q.rank_candidates(predictions[:10], .05) == []
    with pytest.raises(ValueError): q.rank_candidates(predictions, .2)


def test_decision_audit(tmp_path, monkeypatch):
    monkeypatch.setattr(q, 'DB_PATH', tmp_path / 'reviews.db')
    monkeypatch.setattr(q, 'KEY_PATH', tmp_path / 'audit.key')
    fake = [{'predicted_intrusion': False, 'intrusion_score': i/100,
             'attack_type': 'BENIGN', 'anomaly_score': 0.0} for i in range(100)]
    monkeypatch.setattr(q, 'load_model', lambda: object())
    monkeypatch.setattr(q, 'predict', lambda artifact, flows: fake)
    monkeypatch.setattr(q, 'enforce_limit', lambda *args: None)
    features={field: 1 for field in FEATURE_COLUMNS}
    user={'username':'analyst','role':'analyst'}
    result = q.intake(q.Intake(flows=[features] * 100, review_budget=.01),request=None,user=user)
    assert result['review_count'] == 1
    item_id = result['items'][0]['id']
    assert q.get_item(item_id,user=user)['item']['batch_index'] == 99
    assert q.decide(item_id, q.Decision(decision='benign'),user=user)['status'] == 'reviewed'
    assert len(q.get_item(item_id,user=user)['events']) == 2
    assert q.get_item(item_id,user=user)['audit_integrity']=='verified'
    with pytest.raises(HTTPException) as err:
        q.decide(item_id, q.Decision(decision='benign'),user=user)
    assert err.value.status_code == 409
    with q.connect() as db:
        db.execute("UPDATE review_events SET actor='intruder' WHERE event='decision'")
    assert q.get_item(item_id,user=user)['audit_integrity']=='invalid'
