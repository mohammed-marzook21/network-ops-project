import numpy as np
from model_v3_experiment import metrics, threshold_at_fpr, anomaly_percentile


def test_threshold_respects_empirical_budget():
    benign = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.5])
    for budget in [0, .05, .2, .5]:
        threshold = threshold_at_fpr(benign, budget)
        assert np.mean(benign >= threshold) <= budget + 1e-12


def test_anomaly_percentiles():
    values = anomaly_percentile([0., 1., 2.], [0., 1.])
    assert np.allclose(values, [0.5, 1., 1.])


def test_metrics_single_class_auc_undefined():
    m = metrics([0, 0], [.1, .9], .5)
    assert m['roc_auc'] is None and m['fp'] == 1 and m['fpr'] == .5
