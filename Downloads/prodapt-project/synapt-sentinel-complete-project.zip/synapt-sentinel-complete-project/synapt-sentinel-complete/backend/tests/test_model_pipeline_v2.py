import numpy as np
import pandas as pd
import pytest
from model_pipeline import FEATURE_COLUMNS, clean_label, load_sample, train, predict, _split_disjoint

def synthetic(path, labels, offset=0):
    rows=[]
    for i,label in enumerate(labels):
        row={f:float((i+offset)* (j+1) + (i%7)) for j,f in enumerate(FEATURE_COLUMNS)}
        row['Label']=label
        rows.append(row)
    pd.DataFrame(rows).to_csv(path,index=False)

def test_label_cleanup():
    assert clean_label('Web Attack � XSS')=='Web Attack XSS'
    assert clean_label('BENIGN')=='BENIGN'

def test_sampling_caps(tmp_path):
    p=tmp_path/'a.csv'
    synthetic(p,['BENIGN']*50+['DDoS']*30)
    frame,audit=load_sample([p],per_class=12,benign_cap=15,seed=3,chunksize=9)
    assert len(frame)==27
    assert audit['raw_labels']['DDoS']==30

def test_duplicate_disjoint(tmp_path):
    p=tmp_path/'a.csv'
    synthetic(p,['BENIGN']*80+['DDoS']*80)
    df,_=load_sample([p],per_class=80,benign_cap=80)
    clean,tr,va,te,_=_split_disjoint(df,42)
    keys=[set(clean.iloc[ix]['__key__']) for ix in (tr,va,te)]
    assert not keys[0]&keys[1] and not keys[0]&keys[2] and not keys[1]&keys[2]

def test_training_and_prediction(tmp_path):
    p=tmp_path/'a.csv'
    synthetic(p,['BENIGN']*85+['DDoS']*85)
    report=train([p],tmp_path/'models',per_class=85,benign_cap=85,trees=12,importance_rows=20)
    assert report['test_rows']>0
    assert 'macro_f1' in report['multiclass']
    import joblib
    artifact=joblib.load(tmp_path/'models'/'models.joblib')
    flow={f:5.0 for f in FEATURE_COLUMNS}
    result=predict(artifact,[flow])[0]
    assert result['intrusion_score_is_calibrated'] is False
    assert result['anomaly_score_is_probability'] is False
