"""V3.3: compare offline review queues from an existing V3.2 report.

Does not retrain models or alter production artifacts. Assumes V3.2 test labels
were used ONLY for retrospective evaluation, not review ranking.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

METHODS = ('anomaly', 'supervised', 'hybrid')


def compare(report: dict) -> dict:
    budgets = report['settings']['review_budgets']
    rows = []
    for capture in report['captures']:
        if capture.get('status') != 'evaluated':
            continue
        for budget in budgets:
            key = f'{float(budget):.4f}'
            methods = capture['review_by_budget'][key]
            for method in METHODS:
                r = methods[method]
                reviewed = int(r['reviewed'])
                attacks = int(r['rescued_attacks'])
                benign = int(r['benign_reviews'])
                missed = int(r['missed_attacks_before_review'])
                if reviewed != attacks + benign or attacks > missed:
                    raise ValueError(f'Inconsistent V3.2 metrics for {capture["held_out_capture"]}: {method}')
                rows.append({
                    'capture': capture['held_out_capture'], 'budget': float(budget),
                    'method': method, 'reviewed': reviewed, 'attacks_surfaced': attacks,
                    'benign_reviews': benign,
                    'review_precision': attacks / reviewed if reviewed else None,
                    'fraction_of_missed_attacks_surfaced': attacks / missed if missed else None,
                    'attacks_per_100_benign_reviews': 100 * attacks / benign if benign else None,
                    'automated_recall': capture['supervised'].get('recall'),
                    'automated_fpr': capture['supervised'].get('fpr'),
                    'attack_rows': capture['supervised'].get('attack_rows'),
                    'missed_attacks': missed,
                })
    aggregate = []
    for budget in budgets:
        for method in METHODS:
            subset = [r for r in rows if r['budget'] == float(budget) and r['method'] == method]
            reviewed = sum(r['reviewed'] for r in subset)
            attacks = sum(r['attacks_surfaced'] for r in subset)
            benign = sum(r['benign_reviews'] for r in subset)
            missed = sum(r['missed_attacks'] for r in subset)
            aggregate.append({
                'budget': float(budget), 'method': method, 'captures': len(subset),
                'reviewed': reviewed, 'attacks_surfaced': attacks,
                'benign_reviews': benign,
                'review_precision': attacks / reviewed if reviewed else None,
                'fraction_of_missed_attacks_surfaced': attacks / missed if missed else None,
                'attacks_per_100_benign_reviews': 100 * attacks / benign if benign else None,
            })
    return {
        'methodology': 'Post-analysis of V3.2 held-out-capture review queues; no new model fitting or test-label tuning',
        'limitations': [
            'Attacks surfaced for hypothetical analyst review are not confirmed detections',
            'Queue precision uses sampled CIC-IDS2017 prevalence, not real-world alert precision',
            'Aggregate totals pool sampled capture rows and are not deployment-weighted estimates',
            'The same V3.2 evaluation captures must not be used to select a policy and then claim independent validation',
            'Monday contains only benign traffic, so attack recall is undefined',
            'Review budgets apply to all sampled rows in each capture; not online capacity guarantees',
            'V3.2 ranks all held-out flows retrospectively; future production queue requires streaming implementation',
        ],
        'by_capture': rows, 'aggregate': aggregate,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, default=Path(__file__).resolve().parent / 'artifacts' / 'model_v32_escalation' / 'evaluation.json')
    p.add_argument('--output', type=Path, default=Path(__file__).resolve().parent / 'artifacts' / 'model_v33_review_effectiveness' / 'evaluation.json')
    args = p.parse_args()
    result = compare(json.loads(args.input.read_text(encoding='utf-8')))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('V3.3 review effectiveness (sampled capture aggregates):')
    for r in result['aggregate']:
        precision = 'N/A' if r['review_precision'] is None else f'{r["review_precision"]:.3f}'
        print(f'{r["budget"]:.0%} {r["method"]:11s} attacks={r["attacks_surfaced"]:5d} benign_reviews={r["benign_reviews"]:5d} precision={precision}')
    print('Saved:', args.output)


if __name__ == '__main__':
    main()
