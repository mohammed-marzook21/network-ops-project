
PLAYBOOKS = {
    "brute_force": {
        "labels": [
            "SSH-Patator",
            "FTP-Patator",
            "Web Attack - Brute Force",
        ],
        "investigation": [
            "Review relevant authentication logs.",
            "Check failed and successful login patterns.",
            "Correlate network flows with account activity.",
        ],
        "recommendations": [
            "Review rate limiting and account lockout settings.",
            "Enable or verify multi-factor authentication where supported.",
            "Consider source blocking only after evidence review and analyst approval.",
        ],
    },
    "denial_of_service": {
        "labels": [
            "DDoS",
            "DoS GoldenEye",
            "DoS Hulk",
            "DoS Slowhttptest",
            "DoS slowloris",
        ],
        "investigation": [
            "Review traffic volumes and connection patterns.",
            "Check service availability and performance logs.",
            "Correlate observed flows with infrastructure monitoring.",
        ],
        "recommendations": [
            "Review rate limiting and upstream DDoS protection.",
            "Consider traffic filtering after assessing operational impact.",
            "Require analyst approval before disruptive network changes.",
        ],
    },
    "reconnaissance": {
        "labels": ["PortScan"],
        "investigation": [
            "Review destination-port patterns.",
            "Correlate flows with firewall and IDS logs.",
            "Identify whether unexpected services were exposed.",
        ],
        "recommendations": [
            "Review access-control rules and exposed services.",
            "Reduce unnecessary service exposure.",
            "Require approval before firewall modifications.",
        ],
    },
    "web_attack": {
        "labels": [
            "Web Attack - Sql Injection",
            "Web Attack - XSS",
        ],
        "investigation": [
            "Review web-server, application, and WAF logs.",
            "Look for corroborating request and response evidence.",
            "Determine whether exploitation actually occurred.",
        ],
        "recommendations": [
            "Review input validation and output encoding.",
            "Consider targeted WAF rules after analyst review.",
            "Patch confirmed application vulnerabilities.",
        ],
    },
    "potential_compromise": {
        "labels": [
            "Bot",
            "Heartbleed",
            "Infiltration",
        ],
        "investigation": [
            "Review endpoint, application, and network telemetry.",
            "Preserve potentially relevant forensic evidence.",
            "Look for independent indicators of compromise.",
        ],
        "recommendations": [
            "Investigate and remediate confirmed vulnerabilities.",
            "Consider host isolation only with analyst approval.",
            "Validate recovery and monitor for recurrence.",
        ],
    },
}


def generate_recommendations(incident):
    attack_type = incident.get("attack_type", "")

    matched_playbook = None

    for name, playbook in PLAYBOOKS.items():
        if attack_type in playbook["labels"]:
            matched_playbook = (name, playbook)
            break

    if matched_playbook is None:
        return {
            "incident_id": incident.get("incident_id"),
            "attack_type": attack_type,
            "playbook": None,
            "investigation_steps": [
                "Review available incident evidence.",
                "Correlate observations with independent logs.",
            ],
            "recommendations": [
                "Escalate to an analyst for further assessment.",
            ],
            "requires_analyst_approval": True,
            "execution_status": "not_executed",
            "evidence_status": "dataset_label_only",
        }

    name, playbook = matched_playbook

    return {
        "incident_id": incident.get("incident_id"),
        "attack_type": attack_type,
        "playbook": name,
        "investigation_steps": playbook["investigation"],
        "recommendations": playbook["recommendations"],
        "requires_analyst_approval": True,
        "execution_status": "not_executed",
        "evidence_status": "dataset_label_only",
        "disclaimer": (
            "Recommendations are based on the dataset attack "
            "label and are not proof of successful exploitation. "
            "No containment actions have been executed."
        ),
    }
