
import os
import ssl
import uuid
from datetime import datetime, timezone

import httpx
import truststore
from dotenv import load_dotenv

load_dotenv()


class SynaptClient:
    def __init__(self):
        self.mcp_url = os.getenv(
            "SYNAPT_MCP_URL",
            "https://beta.synapt.ai/api/mcp",
        )
        self.token_url = os.getenv(
            "SYNAPT_TOKEN_URL",
            "https://beta.synapt.ai/api/mcp/generate_token",
        )
        self.provider_id = os.getenv(
            "SYNAPT_PROVIDER_ID",
            "sentinel_cyber_incidents_dev",
        )
        self.client_id = os.getenv("SYNAPT_CLIENT_ID")
        self.client_secret = os.getenv("SYNAPT_CLIENT_SECRET")

        self.token = None
        self.expires_at = None

        # Use Windows/system trusted certificates.
        self.ssl_context = truststore.SSLContext(
            ssl.PROTOCOL_TLS_CLIENT
        )

    async def get_token(self):
        """Request a session token from Synapt."""

        if not self.client_id or not self.client_secret:
            raise RuntimeError(
                "Missing Synapt client credentials in .env"
            )

        if self.token and self.expires_at:
            if datetime.now(timezone.utc) < self.expires_at:
                return self.token

        async with httpx.AsyncClient(
            verify=self.ssl_context,
            timeout=60.0,
        ) as client:
            response = await client.post(
                self.token_url,
                json={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                },
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )

            response.raise_for_status()
            data = response.json()

        token = data.get("token")

        if not token:
            raise RuntimeError(
                "Synapt token endpoint returned no token"
            )

        expires_at = data.get("expires_at")
        if not expires_at:
            raise RuntimeError(
                "Synapt token response missing expires_at"
            )

        self.token = token
        self.expires_at = datetime.fromisoformat(
            expires_at.replace("Z", "+00:00")
        )

        return self.token

    @staticmethod
    def parse_mcp_response(response):
        """Parse JSON or MCP Server-Sent Events."""

        content_type = response.headers.get(
            "content-type", ""
        )

        if "text/event-stream" in content_type:
            messages = []
            event_data = []

            for line in response.text.splitlines():
                if line.startswith("data:"):
                    event_data.append(line[5:].strip())

                elif not line.strip() and event_data:
                    import json
                    messages.append(
                        json.loads("\n".join(event_data))
                    )
                    event_data = []

            if event_data:
                import json
                messages.append(
                    json.loads("\n".join(event_data))
                )

            if not messages:
                raise RuntimeError(
                    "Synapt returned an empty SSE response"
                )

            data = messages[-1]

        else:
            data = response.json()

        if "error" in data:
            raise RuntimeError(
                f"Synapt JSON-RPC error: {data['error']}"
            )

        result = data.get("result", data)

        if isinstance(result, dict) and result.get("isError"):
            content = result.get("content", [])
            messages = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict)
            ]
            raise RuntimeError(
                "Synapt MCP tool error: " + " ".join(messages)
            )

        return result

    async def query(self, question: str):
        """Query the Synapt cybersecurity knowledge graph."""

        token = await self.get_token()

        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": "tools/call",
            "params": {
                "name": "trident_query",
                "arguments": {
                    "provider_id": self.provider_id,
                    "question": question,
                },
            },
        }

        async with httpx.AsyncClient(
            verify=self.ssl_context,
            timeout=90.0,
        ) as client:
            response = await client.post(
                self.mcp_url,
                json=payload,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/event-stream",
                },
            )

            response.raise_for_status()

            return self.parse_mcp_response(response)
