"""Explicit artifact-gated prediction API: never substitutes dataset labels."""
from functools import lru_cache
from pathlib import Path
import joblib
from fastapi import APIRouter, HTTPException, Depends
from security_api import permit
from pydantic import BaseModel, Field
from model_pipeline import predict

router=APIRouter(prefix='/api/models',tags=['Predictive models'])
MODEL_FILE=Path(__file__).resolve().parent/'artifacts'/'models'/'models.joblib'

class PredictRequest(BaseModel):
    flows:list[dict]=Field(min_length=1,max_length=100)

@lru_cache(maxsize=1)
def load_model():
    if not MODEL_FILE.is_file(): raise HTTPException(503,'No evaluated trained model artifact. Run model_pipeline.py first.')
    # joblib deserialization is unsafe with untrusted artifacts; use only locally trained ones.
    return joblib.load(MODEL_FILE)

@router.post('/predict')
def model_predict(req:PredictRequest, user=Depends(permit('analyst','admin'))):
    try: results=predict(load_model(),req.flows)
    except ValueError as e: raise HTTPException(422,str(e))
    return {'success':True,'predictions':results,'source':'trained_local_model',
            'evaluation':load_model()['evaluation'], 'requires_analyst_review':True}
