
from pathlib import Path
from datetime import date

DATA_DIR = Path(__file__).resolve().parent / "data"
OUTPUT = DATA_DIR / "mitre_attack_knowledge_pack.md"

TECHNIQUES = [
    {
        "id": "T1110",
        "name": "Brute Force",
        "tactic": "Credential Access",
        "url": "https://attack.mitre.org/techniques/T1110/",
        "labels": [
            "SSH-Patator",
            "FTP-Patator",
            "Web Attack - Brute Force",
        ],
        "relationship": "Contextual mapping",
        "reason": (
            "These dataset categories describe brute-force "
            "activity. The sampled flow records alone do not "
            "prove individual authentication attempts."
        ),
        "investigate": [
            "Review authentication success and failure logs.",
            "Identify affected accounts and services.",
            "Check timestamps, rate patterns, and source addresses "
            "using additional logs where available.",
        ],
    },
    {
        "id": "T1498",
        "name": "Network Denial of Service",
        "tactic": "Impact",
        "url": "https://attack.mitre.org/techniques/T1498/",
        "labels": ["DDoS"],
        "relationship": "Contextual mapping",
        "reason": (
            "The DDoS dataset category is relevant to network "
            "availability attacks. Ten sampled flows cannot "
            "establish network saturation or actual service impact."
        ),
        "investigate": [
            "Review traffic volume and bandwidth utilization.",
            "Check network device counters and service availability.",
            "Correlate flows with firewall and load-balancer logs.",
        ],
    },
    {
        "id": "T1190",
        "name": "Exploit Public-Facing Application",
        "tactic": "Initial Access",
        "url": "https://attack.mitre.org/techniques/T1190/",
        "labels": [
            "Web Attack - Sql Injection",
            "Web Attack - XSS",
        ],
        "relationship": "Conditional mapping",
        "reason": (
            "These categories may be relevant to exploitation "
            "of a public-facing application. The mapping requires "
            "confirmation that a public-facing application was "
            "targeted and exploitation occurred."
        ),
        "investigate": [
            "Review web server, application, and WAF logs.",
            "Check for suspicious requests and application errors.",
            "Look for evidence of successful exploitation.",
        ],
    },
]

INTRO = """# Synapt Sentinel - MITRE ATT&CK Knowledge Pack

Purpose: Provide investigation context for CIC-IDS2017 incidents.

Important interpretation rules:
- MITRE mappings are contextual hypotheses, not confirmed detections.
- Dataset labels are not proof that a technique succeeded.
- Do not infer source IPs, destination IPs, compromised accounts,
  attacker identities, or service impact from missing evidence.
- Do not assign numerical confidence or incident severity solely
  from a dataset label.
- Recommendations require analyst review before disruptive action.

"""


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    lines = [
        INTRO,
        f"Generated: {date.today().isoformat()}",
        "",
    ]

    for technique in TECHNIQUES:
        lines.extend([
            f"## {technique['id']} - {technique['name']}",
            "",
            f"ATT&CK Tactic: {technique['tactic']}",
            f"Official Reference: {technique['url']}",
            f"Mapping Status: {technique['relationship']}",
            "",
            "### Related CIC-IDS2017 Labels",
            "",
        ])

        for label in technique["labels"]:
            lines.append(f"- {label}")

        lines.extend([
            "",
            "### Mapping Rationale",
            "",
            technique["reason"],
            "",
            "### Recommended Investigation",
            "",
        ])

        for step in technique["investigate"]:
            lines.append(f"- {step}")

        lines.extend(["", "---", ""])

    OUTPUT.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    print("MITRE ATT&CK knowledge pack generated.")
    print(f"Techniques included: {len(TECHNIQUES)}")
    print(f"Output: {OUTPUT}")
    print(f"Size: {OUTPUT.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
