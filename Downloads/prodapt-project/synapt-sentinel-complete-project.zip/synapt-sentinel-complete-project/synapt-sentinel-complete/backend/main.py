
import json
import logging
import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from local_analyzer import analyze_local_incident
from response_engine import generate_recommendations
from fastapi.responses import Response
from report_generator import generate_incident_report
from pdf_report_generator import generate_pdf_report

# --------------------------------------------------
# FastAPI application
# --------------------------------------------------

app = FastAPI(
    title="Synapt Sentinel",
    description="AI-Powered Cybersecurity Incident Response Assistant",
    version="0.4.0",
)


logger = logging.getLogger(__name__)


# --------------------------------------------------
# CORS configuration
# --------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174", "http://127.0.0.1:5174",
        "http://localhost:5175", "http://127.0.0.1:5175",
    ] + [x.strip() for x in os.environ.get('SENTINEL_ALLOWED_ORIGINS','').split(',') if x.strip()],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)


# --------------------------------------------------
# Dataset configuration
# --------------------------------------------------

DATA_DIR = Path(__file__).resolve().parent / "data"
GENERATED_DIR = DATA_DIR / "generated_incidents"

# Existing manually prepared incidents.
# Values are full Path objects.
DATASET_INCIDENTS = {
    "CIC-SSH-001": DATA_DIR / "cic_ssh_incident.json",
    "CIC-FTP-001": DATA_DIR / "cic_ftp_incident.json",
}


def discover_generated_incidents():
    """
    Discover generated CIC-IDS2017 incident files.

    Returns a dictionary mapping incident IDs to
    their JSON file paths.
    """

    discovered = {}

    if not GENERATED_DIR.is_dir():
        logger.warning(
            "Generated incident directory not found: %s",
            GENERATED_DIR,
        )
        return discovered

    for incident_file in sorted(
        GENERATED_DIR.glob("*_incident.json")
    ):
        try:
            with incident_file.open(
                "r",
                encoding="utf-8",
            ) as file:
                incident = json.load(file)

            incident_id = incident.get("incident_id")

            if not isinstance(incident_id, str):
                logger.warning(
                    "Missing incident ID in %s",
                    incident_file.name,
                )
                continue

            if not incident_id.startswith("CIC-AUTO-"):
                logger.warning(
                    "Unexpected incident ID in %s: %s",
                    incident_file.name,
                    incident_id,
                )
                continue

            if (
                incident_id in DATASET_INCIDENTS
                or incident_id in discovered
            ):
                logger.warning(
                    "Duplicate incident ID: %s",
                    incident_id,
                )
                continue

            discovered[incident_id] = incident_file

        except (OSError, json.JSONDecodeError):
            logger.exception(
                "Failed to discover incident: %s",
                incident_file,
            )

    return discovered


def get_incident_paths():
    """
    Combine manually prepared incidents with
    automatically generated incidents.

    Generated files are discovered on each request,
    so newly generated incidents do not require
    restarting FastAPI.
    """

    incidents = DATASET_INCIDENTS.copy()
    incidents.update(discover_generated_incidents())

    return incidents


# --------------------------------------------------
# Request models
# --------------------------------------------------

class IncidentRequest(BaseModel):
    question: str = Field(
        min_length=1,
        max_length=2000,
    )


# --------------------------------------------------
# Synapt.AI response processing
# --------------------------------------------------

def extract_analysis(result: dict) -> dict:
    """
    Convert a Synapt MCP response into clean
    dashboard data.
    """

    analysis = result.get("structuredContent")

    # Fallback for text-only MCP responses.
    if not isinstance(analysis, dict):
        for item in result.get("content", []):
            if item.get("type") == "text":
                try:
                    analysis = json.loads(item["text"])
                    break
                except (json.JSONDecodeError, KeyError):
                    continue

    if not isinstance(analysis, dict):
        raise ValueError(
            "No structured analysis returned by Synapt"
        )

    graph = analysis.get("reasoning_subgraph") or {}

    nodes = (
        graph.get("nodes")
        or analysis.get("graph_nodes")
        or []
    )

    edges = graph.get("edges") or []

    indicators = []
    mitigations = []

    for node in nodes:
        label = node.get("label")
        properties = node.get("properties") or {}

        if label == "Indicator":
            indicators.append({
                "name": properties.get("name"),
                "description": properties.get("observable"),
                "confidence": properties.get("confidence"),
            })

        elif label == "Mitigation":
            mitigations.append({
                "name": properties.get("name"),
                "control_type": properties.get("control_type"),
                "requires_approval": properties.get(
                    "requires_approval",
                    False,
                ),
                "confidence": properties.get("confidence"),
            })

    return {
        "query_id": analysis.get("query_id"),
        "answer": analysis.get("answer"),
        "confidence_score": analysis.get(
            "confidence_score"
        ),
        "indicators": indicators,
        "mitigations": mitigations,
        "knowledge_graph": {
            "nodes": nodes,
            "edges": edges,
        },
        "sources": [
            {
                "chunk_id": chunk.get("chunk_id"),
                "text": chunk.get("text"),
                "score": chunk.get("score"),
            }
            for chunk in analysis.get("chunks", [])
        ],
        "procedures": analysis.get(
            "procedures",
            [],
        ),
        "warnings": analysis.get(
            "warnings",
            [],
        ),
    }


# --------------------------------------------------
# Home endpoint
# --------------------------------------------------

@app.get("/")
async def home():
    return {
        "application": "Synapt Sentinel",
        "status": "running",
        "version": "0.4.0",
    }


# --------------------------------------------------
# Health endpoint
# --------------------------------------------------

@app.get("/health")
async def health():
    return {
        "status": "healthy",
    }


# --------------------------------------------------
# Synapt.AI incident analysis endpoint
# --------------------------------------------------

@app.post("/api/incidents/analyze")
async def analyze_incident(request: IncidentRequest):
    """
    Query Synapt.AI for incident analysis.

    Synapt results are external analysis outputs.
    They are not automatically verified against
    local CIC-IDS2017 incident records.
    """

    if os.environ.get('SENTINEL_ENABLE_SYNAPT') != '1':
        raise HTTPException(status_code=503, detail=(
            'Synapt.AI ingestion is not verified. Use /api/workflow/incident/{id} for local investigation. '
            'Enable external calls only after ingestion validation.'))
    try:
        from synapt_client import SynaptClient
        synapt = SynaptClient()
        result = await synapt.query(
            request.question
        )

        return {
            "success": True,
            "provider": synapt.provider_id,
            "analysis": extract_analysis(result),
        }

    except Exception:
        logger.exception(
            "Synapt incident analysis failed"
        )

        raise HTTPException(
            status_code=502,
            detail=(
                "Incident analysis failed. "
                "Check backend logs."
            ),
        )


# --------------------------------------------------
# List all CIC-IDS2017 incidents
# --------------------------------------------------

@app.get("/api/incidents/dataset")
async def list_dataset_incidents():
    """
    List manually prepared and automatically
    generated CIC-IDS2017 incidents.

    Does not contact Synapt.AI.
    """

    incidents = []

    incident_paths = get_incident_paths()

    for incident_id, incident_file in incident_paths.items():

        if not incident_file.is_file():
            logger.warning(
                "Incident file missing: %s",
                incident_file,
            )
            continue

        try:
            with incident_file.open(
                "r",
                encoding="utf-8",
            ) as file:
                incident = json.load(file)

            if incident.get("incident_id") != incident_id:
                logger.warning(
                    "Incident ID mismatch in %s",
                    incident_file,
                )
                continue

            incidents.append({
                "incident_id": incident["incident_id"],
                "attack_type": incident.get(
                    "attack_type"
                ),
                "source": incident.get("source"),
                "record_count": incident.get(
                    "record_count"
                ),
                "severity": incident.get(
                    "severity",
                    "unassessed",
                ),
                "analysis_status": incident.get(
                    "analysis_status",
                    "pending",
                ),
            })

        except (OSError, json.JSONDecodeError):
            logger.exception(
                "Failed to read incident: %s",
                incident_file,
            )

    return {
        "success": True,
        "count": len(incidents),
        "incidents": incidents,
    }


# --------------------------------------------------
# Get an individual CIC-IDS2017 incident
# --------------------------------------------------

@app.get("/api/incidents/dataset/{incident_id}")
async def get_dataset_incident(incident_id: str):
    """
    Return an individual CIC-IDS2017 incident
    and its sampled flow records.

    Read-only endpoint.
    """

    incident_paths = get_incident_paths()

    incident_file = incident_paths.get(
        incident_id
    )

    if incident_file is None:
        raise HTTPException(
            status_code=404,
            detail="Dataset incident not found.",
        )

    if not incident_file.is_file():
        raise HTTPException(
            status_code=404,
            detail="Dataset incident file not found.",
        )

    try:
        with incident_file.open(
            "r",
            encoding="utf-8",
        ) as file:
            incident = json.load(file)

    except (OSError, json.JSONDecodeError):
        logger.exception(
            "Failed to load CIC-IDS2017 incident"
        )

        raise HTTPException(
            status_code=500,
            detail="Failed to load dataset incident.",
        )

    if incident.get("incident_id") != incident_id:
        raise HTTPException(
            status_code=500,
            detail="Dataset incident ID mismatch.",
        )

    return {
        "success": True,
        "incident": incident,
    }

@app.get("/api/incidents/dataset/{incident_id}/local-analysis")
async def get_local_incident_analysis(incident_id: str):
    """
    Calculate descriptive statistics from locally stored
    CIC-IDS2017 incident flows.

    Does not contact Synapt.AI or execute response actions.
    """

    incident_paths = get_incident_paths()
    incident_file = incident_paths.get(incident_id)

    if incident_file is None or not incident_file.is_file():
        raise HTTPException(
            status_code=404,
            detail="Dataset incident not found.",
        )

    try:
        with incident_file.open(
            "r",
            encoding="utf-8",
        ) as file:
            incident = json.load(file)

    except (OSError, json.JSONDecodeError):
        logger.exception(
            "Failed to load incident for local analysis"
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to load dataset incident.",
        )

    if incident.get("incident_id") != incident_id:
        raise HTTPException(
            status_code=500,
            detail="Dataset incident ID mismatch.",
        )

    return {
        "success": True,
        "analysis": analyze_local_incident(incident),
    }

@app.get("/api/incidents/dataset/{incident_id}/recommendations")
async def get_incident_recommendations(incident_id: str):
    """
    Generate local, label-based investigation and
    response recommendations.

    No Synapt.AI calls or containment actions occur.
    """

    incident_paths = get_incident_paths()
    incident_file = incident_paths.get(incident_id)

    if incident_file is None or not incident_file.is_file():
        raise HTTPException(
            status_code=404,
            detail="Dataset incident not found.",
        )

    try:
        with incident_file.open(
            "r",
            encoding="utf-8",
        ) as file:
            incident = json.load(file)

    except (OSError, json.JSONDecodeError):
        logger.exception(
            "Failed to load incident for recommendations"
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to load dataset incident.",
        )

    if incident.get("incident_id") != incident_id:
        raise HTTPException(
            status_code=500,
            detail="Dataset incident ID mismatch.",
        )

    return {
        "success": True,
        "recommendations": generate_recommendations(incident),
    }

@app.get("/api/incidents/dataset/{incident_id}/report")
async def download_incident_report(incident_id: str):
    """
    Generate a Markdown incident investigation report
    using local dataset evidence and recommendations.

    Does not contact Synapt.AI or execute containment.
    """

    incident_paths = get_incident_paths()
    incident_file = incident_paths.get(incident_id)

    if incident_file is None or not incident_file.is_file():
        raise HTTPException(
            status_code=404,
            detail="Dataset incident not found.",
        )

    try:
        with incident_file.open("r", encoding="utf-8") as file:
            incident = json.load(file)

    except (OSError, json.JSONDecodeError):
        logger.exception("Failed to load incident for report")
        raise HTTPException(
            status_code=500,
            detail="Failed to load dataset incident.",
        )

    if incident.get("incident_id") != incident_id:
        raise HTTPException(
            status_code=500,
            detail="Dataset incident ID mismatch.",
        )

    local_analysis = analyze_local_incident(incident)
    recommendations = generate_recommendations(incident)

    report = generate_incident_report(
        incident,
        local_analysis,
        recommendations,
    )

    return Response(
        content=report,
        media_type="text/markdown",
        headers={
            "Content-Disposition": (
                f'attachment; filename="{incident_id}_report.md"'
            ),
            "Cache-Control": "no-store",
        },
    )

@app.get("/api/incidents/dataset/{incident_id}/report/pdf")
async def download_incident_pdf_report(incident_id: str):
    """
    Generate a PDF investigation report from local
    CIC-IDS2017 evidence and response recommendations.

    No Synapt.AI calls or containment actions occur.
    """

    incident_paths = get_incident_paths()
    incident_file = incident_paths.get(incident_id)

    if incident_file is None or not incident_file.is_file():
        raise HTTPException(
            status_code=404,
            detail="Dataset incident not found.",
        )

    try:
        with incident_file.open(
            "r",
            encoding="utf-8",
        ) as file:
            incident = json.load(file)

    except (OSError, json.JSONDecodeError):
        logger.exception(
            "Failed to load incident for PDF report"
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to load dataset incident.",
        )

    if incident.get("incident_id") != incident_id:
        raise HTTPException(
            status_code=500,
            detail="Dataset incident ID mismatch.",
        )

    local_analysis = analyze_local_incident(incident)
    recommendations = generate_recommendations(incident)

    pdf_bytes = generate_pdf_report(
        incident,
        local_analysis,
        recommendations,
    )

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f'attachment; filename="{incident_id}_report.pdf"'
            ),
            "Cache-Control": "no-store",
        },
    )

# Local evidence retrieval is deliberately independent of Synapt ingestion.
from intelligence_api import router as intelligence_router
app.include_router(intelligence_router)

from quality_api import router as quality_router
from model_api import router as model_router
app.include_router(quality_router)
app.include_router(model_router)

# Full-project modules. Synapt ingestion remains independent and disabled by default.
from security_api import router as auth_router
from review_queue import router as review_router
from investigation_api import router as workflow_router
from explain_api import router as explain_router
app.include_router(auth_router)
app.include_router(review_router)
app.include_router(workflow_router)
app.include_router(explain_router)
