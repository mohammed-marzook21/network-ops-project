"""Reproducible retrieval metrics + optional DeepEval for evidence-grounded responses.

Run: python evaluate_quality.py --retrieval
     python evaluate_quality.py --deepeval
The DeepEval mode requires explicit configuration of a judge LLM and network access.
Never substitute synthetic passing scores when judge access is unavailable.
"""
import argparse
import json
from pathlib import Path
from intelligence import HybridIndex, load_incidents, document
from intelligence_api import incident_paths


def retrieval_evaluation(k=5):
    idx=HybridIndex(load_incidents(incident_paths()))
    queries=[]
    for incident in idx.incidents:
        # Test query drawn from reference metadata; not an independent held-out corpus.
        query=f"{incident.get('attack_type','')} incident {incident.get('summary','')}"
        relevance={x['incident_id'] for x in idx.incidents
                   if x['incident_id'] != incident['incident_id'] and x.get('attack_type') == incident.get('attack_type')}
        if not relevance: continue
        hits=idx.search(query,top_k=k,exclude_id=incident['incident_id'])
        retrieved={x['incident_id'] for x in hits}
        queries.append({'query_incident':incident['incident_id'],'relevant':len(relevance),
                        'retrieved_relevant':len(retrieved&relevance),
                        'recall_at_k':len(retrieved&relevance)/len(relevance),
                        'precision_at_k':len(retrieved&relevance)/len(hits) if hits else 0})
    return {'evaluation':'internal_same_corpus_retrieval_smoke_benchmark',
            'k':k,'queries':len(queries),
            'mean_recall_at_k':sum(x['recall_at_k'] for x in queries)/len(queries) if queries else None,
            'mean_precision_at_k':sum(x['precision_at_k'] for x in queries)/len(queries) if queries else None,
            'details':queries,
            'limitations':['Query includes ground-truth label; this does not measure unseen-language retrieval quality',
                           'Only a small set of incident records is available',
                           'Benchmark is not an independent test set']}


def deep_eval():
    """DeepEval answer relevancy, faithfulness, and grounded recommendation safety.

    Real DeepEval calls involve an evaluator model and may incur charges.
    They are intentionally opt-in and never run as a side effect of app startup.
    """
    try:
        from deepeval import evaluate
        from deepeval.test_case import LLMTestCase
        from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric, GEval
        from deepeval.test_case import LLMTestCaseParams
    except ImportError as exc:
        raise RuntimeError('Install optional requirements: pip install -r requirements-evaluation.txt') from exc
    from local_analyzer import analyze_local_incident
    from response_engine import generate_recommendations
    idx=HybridIndex(load_incidents(incident_paths()))
    cases=[]
    for inc in idx.incidents[:5]:
        local=analyze_local_incident(inc)
        rec=generate_recommendations(inc)
        # Structured deterministic system output, not a fabricated LLM result.
        answer=json.dumps({'local_analysis':local,'recommendations':rec})
        evidence=json.dumps({'id':inc['incident_id'],'attack_label':inc.get('attack_type'),
                              'summary':inc.get('summary'),'flows':inc['flows']})
        cases.append(LLMTestCase(input=f'Investigate {inc["incident_id"]}',actual_output=answer,
                                 retrieval_context=[evidence]))
    metrics=[FaithfulnessMetric(threshold=.75),AnswerRelevancyMetric(threshold=.65),
             GEval(name='Incident Response Safety',criteria=(
                  'Rate whether recommendations avoid unapproved containment, do not invent IPs '
                  'or timestamps, distinguish dataset label from proven compromise, and express '
                  'limitations of sampled traffic.'),
                  evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT,LLMTestCaseParams.RETRIEVAL_CONTEXT],
                  threshold=.75)]
    return evaluate(test_cases=cases,metrics=metrics)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--retrieval',action='store_true')
    mode.add_argument('--deepeval',action='store_true')
    args=parser.parse_args()
    if args.retrieval: print(json.dumps(retrieval_evaluation(),indent=2))
    else: print(deep_eval())
