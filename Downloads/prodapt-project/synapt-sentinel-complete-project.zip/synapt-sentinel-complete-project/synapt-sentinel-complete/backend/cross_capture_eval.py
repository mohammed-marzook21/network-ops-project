"""Capture-held-out binary intrusion and novelty benchmark.

No production artifact changes. Held-out captures are never used for model fitting,
calibration, or threshold selection. Evaluation is within CIC-IDS2017 only.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest
from sklearn.frozen import FrozenEstimator
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    average_precision_score, balanced_accuracy_score, brier_score_loss,
    confusion_matrix, f1_score, roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from model_pipeline import FEATURE_COLUMNS, load_sample


def score_metrics(y, scores, threshold):
    y = np.asarray(y, dtype=int)
    scores = np.asarray(scores, dtype=float)
    pred = (scores >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    both = len(np.unique(y)) == 2
    return {
        'rows': int(len(y)),
        'benign_rows': int((y == 0).sum()),
        'attack_rows': int((y == 1).sum()),
        'roc_auc': float(roc_auc_score(y, scores)) if both else None,
        'average_precision': float(average_precision_score(y, scores)) if both else None,
        'balanced_accuracy': float(balanced_accuracy_score(y, pred)) if both else None,
        'f1_attack': float(f1_score(y, pred, zero_division=0)),
        'false_positive_rate': float(fp / (fp + tn)) if fp + tn else None,
        'false_negative_rate': float(fn / (fn + tp)) if fn + tp else None,
        'confusion_matrix_tn_fp_fn_tp': [int(tn), int(fp), int(fn), int(tp)],
    }


def calibrate_fitted_model(model, x_calibration, y_calibration):
    """Calibrate an already-fitted estimator using sklearn >= 1.6 API."""
    calibrator = CalibratedClassifierCV(FrozenEstimator(model), method='sigmoid')
    calibrator.fit(x_calibration, y_calibration)
    return calibrator


def evaluate(paths, output, per_class=3000, benign_cap=5000, trees=60, seed=42):
    paths = [Path(p) for p in paths]
    if len(paths) < 3 or len({p.name for p in paths}) != len(paths):
        raise ValueError('Supply at least three uniquely named capture CSV files')
    if trees < 5:
        raise ValueError('trees must be >= 5')
    results = []
    for held in paths:
        train_paths = [p for p in paths if p != held]
        train_df, _ = load_sample(train_paths, per_class, benign_cap, seed=seed)
        test_df, _ = load_sample([held], per_class, benign_cap, seed=seed + 1)

        conflicts = train_df.groupby('__key__')['__label__'].nunique()
        bad_keys = set(conflicts[conflicts > 1].index)
        train_df = train_df.loc[~train_df['__key__'].isin(bad_keys)].drop_duplicates('__key__').copy()
        seen_keys = set(train_df['__key__'])
        overlap = int(test_df['__key__'].isin(seen_keys).sum())
        test_df = test_df.loc[~test_df['__key__'].isin(seen_keys)].drop_duplicates('__key__').copy()

        y = (train_df['__label__'] != 'BENIGN').astype(int)
        yt = (test_df['__label__'] != 'BENIGN').astype(int)
        entry = {
            'held_out_capture': held.name,
            'training_rows': int(len(train_df)),
            'test_rows': int(len(test_df)),
            'removed_test_rows_matching_training': overlap,
            'test_attack_labels': test_df.loc[yt == 1, '__label__'].value_counts().to_dict(),
            'unseen_attack_labels': sorted(
                set(test_df.loc[yt == 1, '__label__']) - set(train_df.loc[y == 1, '__label__'])
            ),
            'training_capture_files': [p.name for p in train_paths],
        }
        if y.nunique() != 2 or len(test_df) == 0 or y.value_counts().min() < 3:
            entry['status'] = 'not_evaluable_insufficient_data'
            results.append(entry)
            continue

        fit_idx, val_idx = train_test_split(
            np.arange(len(train_df)), test_size=.25, stratify=y, random_state=seed
        )
        x = train_df[FEATURE_COLUMNS]
        xt = test_df[FEATURE_COLUMNS]
        model = Pipeline([
            ('impute', SimpleImputer(strategy='median')),
            ('model', ExtraTreesClassifier(
                n_estimators=trees, min_samples_leaf=2, class_weight='balanced',
                n_jobs=-1, random_state=seed,
            )),
        ])
        model.fit(x.iloc[fit_idx], y.iloc[fit_idx])
        calibrator = calibrate_fitted_model(model, x.iloc[val_idx], y.iloc[val_idx])
        val_scores = calibrator.predict_proba(x.iloc[val_idx])[:, list(calibrator.classes_).index(1)]
        thresholds = np.linspace(.05, .95, 91)
        threshold = float(thresholds[np.argmax([
            f1_score(y.iloc[val_idx], val_scores >= t, zero_division=0)
            for t in thresholds
        ])])
        test_scores = calibrator.predict_proba(xt)[:, list(calibrator.classes_).index(1)]

        benign_train = x.iloc[fit_idx][y.iloc[fit_idx] == 0]
        imputer = SimpleImputer(strategy='median')
        bx = imputer.fit_transform(benign_train)
        anomaly = IsolationForest(
            n_estimators=100, random_state=seed, n_jobs=-1, contamination='auto'
        )
        anomaly.fit(bx)
        anomaly_scores = -anomaly.decision_function(imputer.transform(xt))

        entry['status'] = 'evaluated'
        entry['binary'] = score_metrics(yt, test_scores, threshold)
        entry['binary']['threshold_selected_on_training_validation'] = threshold
        entry['binary']['brier_score'] = float(brier_score_loss(yt, test_scores))
        entry['anomaly'] = score_metrics(yt, anomaly_scores, 0.0)
        entry['anomaly']['scores_are_probabilities'] = False
        entry['calibration'] = {
            'method': 'sigmoid on held-in-capture validation rows using FrozenEstimator',
            'validation_rows': int(len(val_idx)),
            'validation_brier_score': float(brier_score_loss(y.iloc[val_idx], val_scores)),
            'held_out_brier_score': entry['binary']['brier_score'],
            'caution': ('Validation Brier score is in-sample for calibration, not an '
                        'independent calibration evaluation; calibration may not transfer across captures'),
        }
        results.append(entry)
        print(f'{held.name}: evaluated; test={len(test_df)}; '
              f'binary_auc={entry["binary"]["roc_auc"]}', flush=True)

    report = {
        'methodology': 'leave-one-CSV-capture-out; per-capture sampled; exact-vector overlap removed',
        'scope': 'cross-capture shift within CIC-IDS2017, not independent networks',
        'per_class_cap': per_class,
        'benign_cap': benign_cap,
        'seed': seed,
        'limitations': [
            'Each attack family often occurs in a single capture',
            'Training captures can still share environment and campaign artifacts',
            'Test capture is sampled and does not reflect real-world class prevalence',
            'Exact duplicate removal does not eliminate near duplicates',
            'Calibration validation is within training captures, not capture-independent',
            'Threshold selection and calibration both use the same held-in validation partition',
        ],
        'captures': results,
    }
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', nargs='+', required=True, type=Path)
    parser.add_argument('--output', default=str(
        Path(__file__).resolve().parent / 'artifacts' / 'cross_capture' / 'evaluation.json'
    ))
    parser.add_argument('--per-class', type=int, default=3000)
    parser.add_argument('--benign-cap', type=int, default=5000)
    parser.add_argument('--trees', type=int, default=60)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    report = evaluate(args.csv, args.output, args.per_class, args.benign_cap, args.trees, args.seed)
    print('Saved:', args.output)
    print('Evaluated captures:', sum(r['status'] == 'evaluated' for r in report['captures']))
