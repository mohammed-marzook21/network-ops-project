import csv
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"
INPUT_FILE = DATA_DIR / "ssh_patator_sample.csv"
OUTPUT_FILE = DATA_DIR / "cic_ssh_incident.json"


def get_value(row, column):
    return row.get(column, "").strip()


def main():
    flows = []

    with INPUT_FILE.open(
        "r", encoding="utf-8-sig", newline=""
    ) as file:
        reader = csv.DictReader(file)

        for index, row in enumerate(reader, start=1):
            # CIC-IDS2017 column names may contain leading spaces.
            row = {
                key.strip(): value
                for key, value in row.items()
                if key is not None
            }

            flows.append({
                "flow_id": f"FLOW-{index:03d}",
                "destination_port": get_value(
                    row, "Destination Port"
                ),
                "flow_duration": get_value(
                    row, "Flow Duration"
                ),
                "total_forward_packets": get_value(
                    row, "Total Fwd Packets"
                ),
                "total_backward_packets": get_value(
                    row, "Total Backward Packets"
                ),
                "label": get_value(row, "Label"),
            })

    if not flows:
        raise ValueError("No network flows found in the CSV file.")

    labels = sorted({flow["label"] for flow in flows})

    incident = {
        "incident_id": "CIC-SSH-001",
        "source": "CIC-IDS2017",
        "source_file": INPUT_FILE.name,
        "attack_type": "SSH-Patator",
        "record_count": len(flows),
        "dataset_labels": labels,
        "severity": "unassessed",
        "analysis_status": "pending",
        "summary": (
            "A sample of network-flow records labeled "
            "SSH-Patator in the CIC-IDS2017 dataset."
        ),
        "flows": flows,
    }

    with OUTPUT_FILE.open(
        "w", encoding="utf-8"
    ) as file:
        json.dump(incident, file, indent=2)

    print("Incident JSON created successfully!")
    print(f"Incident ID: {incident['incident_id']}")
    print(f"Attack type: {incident['attack_type']}")
    print(f"Total flows: {incident['record_count']}")
    print(f"Saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()