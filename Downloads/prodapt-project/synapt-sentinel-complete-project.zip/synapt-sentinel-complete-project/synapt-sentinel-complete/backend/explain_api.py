"""Per-flow model sensitivity explanations; not causal SHAP values."""
from __future__ import annotations
import math
import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException, Depends
from security_api import permit
from pydantic import BaseModel, Field
from model_api import load_model
from model_pipeline import predict

router=APIRouter(prefix='/api/models',tags=['Predictive models'])

class ExplainRequest(BaseModel):
    flows:list[dict]=Field(min_length=1,max_length=5)


def explain(artifact, flows):
    classifier=artifact.get('binary_classifier')
    if classifier is None:
        raise ValueError('No binary classifier in the trained artifact')
    features=artifact['features']
    x=pd.DataFrame(flows)
    for field in features:
        if field not in x: raise ValueError(f'Missing required numeric feature: {field}')
    x=x[features].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
    if x.isna().all(axis=1).any(): raise ValueError('At least one valid feature required for every flow')
    cls=list(classifier.classes_).index(1)
    baseline=classifier.named_steps['impute'].statistics_
    original=classifier.predict_proba(x)[:,cls]
    output=[]
    for n in range(len(x)):
        row=x.iloc[[n]].copy()
        comparisons=[]
        for k,field in enumerate(features):
            alt=row.copy()
            alt.loc[:,field]=baseline[k]
            alt_score=float(classifier.predict_proba(alt)[:,cls][0])
            comparisons.append({'feature':field,'value':float(row.iloc[0,k]) if pd.notna(row.iloc[0,k]) else None,
                                'replacement_training_median':float(baseline[k]) if math.isfinite(baseline[k]) else None,
                                'score_delta_when_replaced':round(float(original[n]-alt_score),6)})
        comparisons.sort(key=lambda part:-abs(part['score_delta_when_replaced']))
        output.append({'intrusion_score':round(float(original[n]),6),
                       'feature_sensitivities':comparisons,
                       'method':'one_feature_at_a_time_replacement_with_training_median',
                       'limitations':['Not causal attribution or SHAP','Correlated features may change together',
                                      'Binary scores uncalibrated and capture-dependent']})
    return output


@router.post('/explain')
def flow_explanation(req:ExplainRequest, user=Depends(permit('analyst','admin'))):
    try:
        artifact=load_model()
        return {'success':True,'explanations':explain(artifact,req.flows),
                'source':'trained_local_model','requires_analyst_review':True}
    except ValueError as error:
        raise HTTPException(422,str(error))
