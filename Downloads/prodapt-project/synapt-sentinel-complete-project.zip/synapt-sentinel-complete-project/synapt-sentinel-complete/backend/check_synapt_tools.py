import asyncio
import json
import uuid

import httpx

from synapt_client import SynaptClient


async def main():
    synapt = SynaptClient()
    token = await synapt.get_token()

    payload = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "tools/list",
        "params": {},
    }

    async with httpx.AsyncClient(
        verify=synapt.ssl_context,
        timeout=60.0,
    ) as client:
        response = await client.post(
            synapt.mcp_url,
            json=payload,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
            },
        )

        response.raise_for_status()
        result = synapt.parse_mcp_response(response)

    tools = result.get("tools", [])

    print("\nAVAILABLE SYNAPT MCP TOOLS\n")

    for tool in tools:
        print(f"Tool: {tool.get('name')}")
        print(f"Description: {tool.get('description', '')}")
        print("-" * 50)

    print(f"\nTotal tools: {len(tools)}")


if __name__ == "__main__":
    asyncio.run(main())