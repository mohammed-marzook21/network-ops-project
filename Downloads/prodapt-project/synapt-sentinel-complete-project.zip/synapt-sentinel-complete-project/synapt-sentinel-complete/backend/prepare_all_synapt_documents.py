
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"
GENERATED_DIR = DATA_DIR / "generated_incidents"

MANUAL_FILES = [
    DATA_DIR / "cic_ssh_incident.json",
    DATA_DIR / "cic_ftp_incident.json",
]

GENERATED_FILES = sorted(
    GENERATED_DIR.glob("*_incident.json")
)

OUTPUT_FILE = DATA_DIR / "cic_ids2017_knowledge_pack.md"


def main():
    files = MANUAL_FILES + GENERATED_FILES

    sections = [
        "# Synapt Sentinel — CIC-IDS2017 Incident Knowledge Pack",
        "",
        "Source: CIC-IDS2017 MachineLearningCSV dataset.",
        "",
        "This document contains sampled network-flow records.",
        "Attack types are dataset labels, not independent AI detections.",
        "Severity is unassessed unless explicitly established.",
        "No source or destination IP addresses are inferred.",
        "No remediation actions have been executed.",
        "",
    ]

    count = 0

    for path in files:
        if not path.is_file():
            print(f"Skipping missing file: {path.name}")
            continue

        with path.open("r", encoding="utf-8") as file:
            incident = json.load(file)

        incident_id = incident.get("incident_id")
        attack_type = incident.get("attack_type")
        flows = incident.get("flows", [])

        if not incident_id or not isinstance(flows, list):
            print(f"Skipping invalid incident: {path.name}")
            continue

        sections.extend([
            f"## Incident {incident_id}",
            "",
            f"Incident ID: {incident_id}",
            f"Attack Type: {attack_type}",
            f"Dataset Source: {incident.get('source')}",
            f"Original CSV: {incident.get('source_file')}",
            f"Dataset Labels: {incident.get('dataset_labels')}",
            f"Severity: {incident.get('severity', 'unassessed')}",
            f"Analysis Status: {incident.get('analysis_status', 'pending')}",
            f"Sampled Record Count: {len(flows)}",
            "",
            "### Network Flow Evidence",
            "",
        ])

        for flow in flows:
            sections.extend([
                f"Flow ID: {flow.get('flow_id')}",
                f"Destination Port: {flow.get('destination_port')}",
                f"Flow Duration (microseconds): {flow.get('flow_duration')}",
                f"Forward Packets: {flow.get('total_forward_packets')}",
                f"Backward Packets: {flow.get('total_backward_packets')}",
                f"Dataset Label: {flow.get('label')}",
                "",
            ])

        sections.extend([
            "### Evidence Limitations",
            "",
            "These records are samples, not the full incident.",
            "The CSV records used here do not include source or destination IP addresses.",
            "The dataset label does not establish incident severity.",
            "Any defensive recommendation requires contextual review.",
            "",
            "---",
            "",
        ])

        count += 1

    OUTPUT_FILE.write_text(
        "\n".join(sections),
        encoding="utf-8",
    )

    print(f"Incidents included: {count}")
    print(f"Output file: {OUTPUT_FILE}")
    print(f"File size: {OUTPUT_FILE.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
