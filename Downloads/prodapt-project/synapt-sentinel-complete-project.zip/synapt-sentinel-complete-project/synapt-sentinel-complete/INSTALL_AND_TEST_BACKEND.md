# Synapt Sentinel — local intelligence upgrade (engineering milestone)

## Scope and disclosure

This package ADDS a local intelligence API without changing the existing Synapt ingestion/MCP integration or frontend routes. New capabilities: hybrid BM25/LSA retrieval, metadata filters, evidence-linked similarity, retrieval-neighbor attack-type baseline, explainable heuristic ranking, deterministic multi-stage investigation, analyst feedback in SQLite, model training and grouped held-out evaluation scripts, Isolation Forest anomaly detection, optional DeepEval and optional LLM-as-Judge.

**Do not present this as meeting all requirements yet.** A pretrained semantic encoder, validated supervised models trained on sufficiently independent CIC-IDS2017 captures, satisfactory DeepEval/judge results, and integration of new intelligence tools into the redesigned frontend require additional work. Model inference returns HTTP 503, not invented predictions, until a locally trained artifact exists. Judge returns 503 without configuration. Synapt ingestion remains independent and unverified.

## Installation on Windows (PowerShell)

1. Stop FastAPI. Create a Git checkpoint on `master`, and retain `backup/before-ui-redesign`.
2. Extract the package to your project root, **not** inside `backend`:

```powershell
cd C:\Users\mohammed.marzook\Downloads\synapt-sentinel
Expand-Archive .\synapt-sentinel-intelligence-upgrade.zip -DestinationPath . -Force
```

3. From your activated Python virtual environment:

```powershell
python -m pip install -r backend\requirements-intelligence.txt
cd backend
python -m pytest -q
python evaluate_quality.py --retrieval
uvicorn main:app --reload
```

The original backend requirements are preserved; your existing environment needs all original packages, including `truststore`, which is needed by the unchanged Synapt client.

4. Open `http://127.0.0.1:8000/docs` and test:

- `GET /api/intelligence/status`
- `POST /api/intelligence/search` with `{"query":"SSH brute force port 22","top_k":5,"destination_port":22}`
- `GET /api/intelligence/metadata?attack_type=SSH-Patator`
- `GET /api/intelligence/incident/CIC-SSH-001/classification`
- `GET /api/intelligence/incident/CIC-SSH-001/priority`
- `GET /api/intelligence/incident/CIC-SSH-001/investigation`
- `POST /api/quality/feedback` with `{"incident_id":"CIC-SSH-001","verdict":"needs_review","aspect":"classification","comment":"Analyst verification required"}`
- `GET /api/quality/feedback/summary`
- `GET /api/quality/evaluation/status`
- `POST /api/models/predict`: returns 503 until an evaluated artifact is available.

The existing `/api/incidents/*` API contract remains unchanged. No automatic containment is performed.

## Model training: holdout integrity matters

The supplied 16 examples contain only ~160 sampled flows; **do not train and advertise accuracy on this subset**. Supply original, appropriately licensed CIC-IDS2017 labeled flow CSVs with independent capture groups and classes represented on both sides of the holdout. The script rejects groups/classes that cannot be credibly held out. From `backend`:

```powershell
python model_pipeline.py --csv "C:\path\to\capture1.csv" "C:\path\to\capture2.csv" "C:\path\to\capture3.csv" "C:\path\to\capture4.csv" --output artifacts\models
```

The file stem is currently the capture group ID; audit whether files actually represent independent captures. A split by filename does *not* automatically remove all dataset leakage. Inspect `artifacts/models/evaluation.json` before claiming performance. Additional investigation should cover temporally disjoint captures, class imbalance, robust calibration, PR-AUC, confusion matrices, protocol shift, and adversarial robustness. The model uses the full expected CIC-IDS2017 column naming: prediction requests must provide the trained features rather than the limited demo JSON fields.

**Never load downloaded/untrusted `.joblib` files**: Python deserialization is executable. Keep locally trained artifacts private and out of Git.

## Optional LLM evaluation

```powershell
python -m pip install -r requirements-evaluation.txt
$env:OPENAI_API_KEY="YOUR_KEY" # enter locally, never commit
python evaluate_quality.py --deepeval
```

LLM judge endpoint: `POST /api/quality/judge` with `incident_id`, `analysis`, `recommendation`. LLM evaluation may incur costs; require a human reviewer and record actual scores. DeepEval's API evolves; resolve dependency/API mismatches against your installed version, and pin a known-good version after first confirmed run. Evaluator scores are subjective and should not replace human security review.

## Privacy and operational controls

- Local retrieval does not send flows to third-party servers.
- Optional LLM-as-Judge **does send supplied sampled-flow evidence to the configured model provider**; use only approved, sanitized inputs.
- Analyst comments are stored in `backend/artifacts/feedback.sqlite3`; control access and do not include private feedback in Git.
- No source IPs, destination IPs, timestamps, or protocols are invented when fields are missing. Filtering by such unavailable fields yields no matches.
- Response steps always require human approval; execution never occurs.
- Only run the API on localhost until authentication, audit logging, input rate limiting, and role-based access are implemented.

## Git checkpoint

```powershell
cd ..
git status --short
git add backend\main.py backend\intelligence.py backend\intelligence_api.py backend\model_api.py backend\model_pipeline.py backend\quality_api.py backend\evaluate_quality.py backend\requirements-intelligence.txt backend\requirements-evaluation.txt backend\tests\test_intelligence.py INSTALL_AND_TEST_BACKEND.md
git diff --cached --check
git commit -m "Add local hybrid retrieval and intelligence foundation"
```

Do not `git add .` if ZIP files, evaluation artifacts, or secrets are present.
