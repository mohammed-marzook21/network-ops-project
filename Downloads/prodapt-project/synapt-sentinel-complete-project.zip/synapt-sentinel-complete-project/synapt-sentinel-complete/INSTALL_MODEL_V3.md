# Synapt Sentinel Model V3 experimental benchmark

This experiment does **not** replace `backend/artifacts/models/models.joblib`, change `model_api.py`, or integrate into the frontend.

From project root in PowerShell:

```powershell
Expand-Archive -LiteralPath .\synapt-sentinel-model-v3-experiment.zip -DestinationPath . -Force
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests -q
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\model_v3_experiment.py --csv $csvs --per-class 3000 --benign-cap 5000 --trees 60 --fpr-budget 0.05
$r = Get-Content .\backend\artifacts\model_v3_experiment\evaluation.json -Raw | ConvertFrom-Json
$r.captures | ForEach-Object { [PSCustomObject]@{Capture=$_.held_out_capture; SupervisedRecall=$_.supervised.recall; SupervisedFPR=$_.supervised.fpr; FusionRecall=$_.fusion.recall; FusionFPR=$_.fusion.fpr; AnomalyWeight=$_.selected_anomaly_weight} } | Format-List
```

Compare against the **new supervised baseline from the same V3 run**, rather than directly comparing recall with the older V2 benchmark, because thresholds are now selected under a validation FPR budget.

**Interpretation:** A nominal 5% FPR budget applies to training-side validation data, not necessarily the held-out capture. Fusion weights are chosen using training-side validation attack labels; held-out captures remain untouched. The same validation subset is used to select the threshold and fusion weight, so its reported recall is an optimistic tuning diagnostic. Only held-out metrics support generalization comparisons. Sampling and missing flow/session IDs remain limitations.
