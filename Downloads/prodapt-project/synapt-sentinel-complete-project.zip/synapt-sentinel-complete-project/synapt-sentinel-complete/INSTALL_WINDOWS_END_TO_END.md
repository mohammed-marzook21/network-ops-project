# One Windows PowerShell installation and demonstration guide

**Recommended install:** Extract the ZIP into a new, separate folder next to the existing `synapt-sentinel` checkout. **Do not overwrite the known-working Git repository.** The archive contains a complete source snapshot assembled from the available project packages. The user's current local edits might differ from this snapshot; verify before merging.

## 1. Extract and preserve existing data/model

In PowerShell, edit `$zip` to the downloaded archive path:

```powershell
$downloads = Join-Path $HOME 'Downloads'
$zip = Join-Path $downloads 'synapt-sentinel-complete-project.zip'
$new = Join-Path $downloads 'synapt-sentinel-complete'
$old = Join-Path $downloads 'synapt-sentinel'
Expand-Archive -LiteralPath $zip -DestinationPath $downloads -Force
Set-Location $new
```

The ZIP extracts into the `synapt-sentinel-complete` folder. **Do not copy `.env`, secrets, or untrusted `.joblib` files.** Copy your existing trusted V2 model and original dataset CSVs only if available:

```powershell
New-Item -ItemType Directory -Path .\backend\artifacts\models -Force | Out-Null
Copy-Item -Path "$old\backend\artifacts\models\models.joblib" -Destination .\backend\artifacts\models\ -ErrorAction Stop
Copy-Item -Path "$old\backend\artifacts\models\evaluation.json" -Destination .\backend\artifacts\models\ -ErrorAction Stop
Copy-Item -Path "$old\backend\data\*.pcap_ISCX.csv" -Destination .\backend\data\ -ErrorAction Stop
```

If you don't have model artifacts, see **Train V2 if needed** below. Without them, model scoring/intake/explanations return HTTP 503 by design; catalog, RAG and local workflow still run. Data CSVs are not required for the frontend's prepared incident catalog or the backend test suite.

To preserve earlier experimental evidence, optionally copy the following folders only if present:

```powershell
foreach ($sub in @('cross_capture','model_v3_experiment','model_v31_diagnostics','model_v32_escalation','model_v33_review_effectiveness','models_v2_baseline')) {
  if (Test-Path "$old\backend\artifacts\$sub") {
    Copy-Item "$old\backend\artifacts\$sub" .\backend\artifacts\ -Recurse -Force
  }
}
```

## 2. Install backend dependencies and create first analyst

Use Python 3.11 (or the previously verified project environment).

```powershell
py -3.11 -m venv .\backend\.venv
.\backend\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\backend\requirements-full.txt
python .\backend\bootstrap_admin.py --username admin
```

Choose a distinct 12+-character password when prompted. This creates a local **admin** identity in the separate `backend/artifacts/auth.sqlite3` file. Do not put credentials in source code. Analyst/viewer accounts can be created through the authenticated `POST /api/auth/users` admin endpoint in `/docs`. **Never copy your test auth database into a shared public installation.**

Security details: sessions expire after 8 hours, the review API requires authentication, reviewers are server-derived, decisions are one-time, and audit events use a local HMAC chain. Auth and audit databases live in `backend/artifacts/`. Keep the generated `.audit.key` file across restarts and protect it using OS permissions. Existing V4 review records will be migrated without losing them, but **legacy unsigned events remain `legacy_unverified`**.

For deliberate use beyond single-user local tests, set `SENTINEL_AUDIT_KEY` to a securely stored 32+-character secret outside the repo, deploy TLS and an identity provider, and do an external security review. Do not expose this prototype directly to the internet.

## 3. Start the API

In the root with `.venv` activated:

```powershell
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m uvicorn main:app --app-dir .\backend --host 127.0.0.1 --port 8000 --reload
```

Check `http://127.0.0.1:8000/docs` and `GET /api/workflow/readiness`. Synapt external calls intentionally return 503 unless `SENTINEL_ENABLE_SYNAPT=1`. Keep it **disabled** until ingestion has genuinely succeeded.

## 4. Build and start frontend

Open another terminal:

```powershell
Set-Location "$new\frontend"
npm ci
npm run build
npm run dev
```

Open the Vite local URL (commonly 5173 or 5174). Your five pages remain: Overview, Incident Explorer, AI Investigation, Response Center, Reports. AI Investigation has a new **Run local investigation** button independent of Synapt. Incident Explorer and Response Center require sign-in for the Needs Review queue. The session bearer is kept in browser `sessionStorage` until logout/tab close/expiry; it is **not** a production-grade XSS-resistant web-session design.

If Vite selects a different port, explicitly allow its exact origin before starting the backend:

```powershell
$env:SENTINEL_ALLOWED_ORIGINS='http://localhost:5176,http://127.0.0.1:5176'
```

## 5. Run backend tests + retrieval audit

In root PowerShell with `.venv` activated:

```powershell
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests -q
python .\backend\evaluate_quality.py --retrieval
python .\backend\final_audit.py
```

The `final_audit.json` file reports **what is actually present**, not assumed success. The retrieval evaluation is an internal same-corpus smoke benchmark, not independent ground-truth verification.

## 6. Demonstrate real model review intake and one analyst decision

Run the backend and frontend. Log in with your admin account in the Needs Review panel. Then use another PowerShell terminal from root:

```powershell
$csv = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name)[0].FullName
python .\backend\demo_review_intake.py --csv "$csv" --username admin --budget 0.05
```

The demo selects the first 100 **finite, complete, genuine feature rows**, no fabricated fields. It submits 100 flows and will create **up to five** pending items (depending on binary model flags). If it creates zero items, use another capture; the queue does not artificially force a review candidate. On the Response Center screen inspect an item, mark `inconclusive` with note `Demonstration only — no independent verification`, and confirm the item moves to Reviewed with `audit_integrity: verified`. Never call a model score a confirmed incident.

## 7. Train V2 if the artifact is unavailable (optional, slower)

```powershell
$csvs = @(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File | Sort-Object Name | Select-Object -ExpandProperty FullName)
python .\backend\model_pipeline.py --csv $csvs --output .\backend\artifacts\models --per-class 5000 --benign-cap 15000 --trees 60
```

Restart FastAPI after replacing `models.joblib`, because the existing API caches that artifact. **Do not** describe within-corpus V2 metrics as independent performance.

## 8. Optional genuine DeepEval and LLM-as-Judge (NOT automatic)

```powershell
python -m pip install -r .\backend\requirements-evaluation.txt
# Configure the appropriate evaluation service account and API key in this terminal.
# Never commit keys. These runs may incur network/provider charges.
python .\backend\evaluate_quality.py --deepeval *>&1 | Tee-Object .\deepeval_run.log
```

Real judge API: authenticate in `/docs` using `/api/auth/login`; click **Authorize** and provide its bearer token, then call `POST /api/quality/judge` on one known dataset incident. Configure `OPENAI_API_KEY` in the backend's environment and `SENTINEL_JUDGE_MODEL` as desired. Real results must be retained with evaluator version, date, metrics and cost/provider details; a network error or missing key is a **not run**, not a pass. There is **no honest way** to certify real third-party DeepEval/LLM-as-Judge runs without credentials and successful service calls.

## 9. Independent data validation (optional and not provided)

Supply a genuinely different, independently labeled capture CSV with the same CIC feature schema. **Never** recycle the eight CIC-IDS2017 CSVs you already used to select V3/V3.3 strategies and claim it is new validation.

```powershell
python .\backend\validation_external.py --csv C:\path\to\independent_capture.csv
```

The threshold is frozen; compare actual FPR and recall, not just ROC-AUC. Track class prevalence, acquisition conditions and provenance. The evaluation code cannot itself prove independence.

## 10. Export verified review feedback for future learning

```powershell
python .\backend\feedback_export.py --output .\backend\artifacts\review_feedback_export.json
```

This is a traceable learning **candidate export**, not online retraining. Analyst decisions still need verification and duplicate checks before training. The existing `quality_api.py` also persists authenticated incident feedback.

## 11. Synapt.AI ingestion integration — future gate

Keep `SENTINEL_ENABLE_SYNAPT` unset. In a separate development environment:

1. Make the external ingestion job report **nonzero chunks/entities**; inspect the provider's own response rather than success-by-request.
2. Query for a unique, known chunk and verify exact source IDs and content.
3. Add regression tests for correct citations, missing documents, duplicate ingestion, and provider outages.
4. Only after evidence is reproducible, set `SENTINEL_ENABLE_SYNAPT=1` and test the existing external `/api/incidents/analyze` route. Never merge Synapt content into local evidence as though it were independently verified.

## Final academic demonstration sequence

Overview → Incident Explorer sample evidence → AI Investigation local four-stage workflow + source IDs → V2 model prediction / `POST /api/models/explain` via Swagger → authenticated intake → Response Center inconclusive decision → audit trail → Reports PDF → `final_audit.json` → present cross-capture limitations. All response controls are **advisory only**.
