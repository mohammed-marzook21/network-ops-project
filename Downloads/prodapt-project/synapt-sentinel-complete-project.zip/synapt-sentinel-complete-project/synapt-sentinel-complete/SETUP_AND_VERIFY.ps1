# Run from an unzipped synapt-sentinel-complete folder.
# Does not overwrite an existing project checkout, API secrets, or trained model.
param(
  [string]$ExistingProject = (Join-Path (Split-Path $PSScriptRoot -Parent) 'synapt-sentinel'),
  [switch]$SkipNpm
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host '[1/6] Checking trusted local assets...' -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path '.\backend\artifacts\models' | Out-Null
$trusted = Join-Path $ExistingProject 'backend\artifacts\models'
foreach ($name in @('models.joblib','evaluation.json')) {
  $source = Join-Path $trusted $name
  $dest = Join-Path '.\backend\artifacts\models' $name
  if ((Test-Path $source) -and !(Test-Path $dest)) {
    Copy-Item $source $dest
    Write-Host "Copied trusted local $name (load joblib only if this is YOUR trained artifact)"
  }
}
$csvs = @(Get-ChildItem -Path (Join-Path $ExistingProject 'backend\data') -Filter '*.pcap_ISCX.csv' -File -ErrorAction SilentlyContinue)
foreach ($f in $csvs) {
  $dest = Join-Path '.\backend\data' $f.Name
  if (!(Test-Path $dest)) { Copy-Item $f.FullName $dest }
}
Write-Host "Local capture CSV files available: $(@(Get-ChildItem .\backend\data -Filter '*.pcap_ISCX.csv' -File).Count)"
Write-Host '[2/6] Creating Python 3.11 environment...' -ForegroundColor Cyan
if (!(Test-Path '.\backend\.venv\Scripts\python.exe')) {
  & py -3.11 -m venv '.\backend\.venv'
  if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 venv creation failed' }
}
$python = (Resolve-Path '.\backend\.venv\Scripts\python.exe').Path
& $python -m pip install -r '.\backend\requirements-full.txt'
if ($LASTEXITCODE -ne 0) { throw 'Backend dependency installation failed' }
$env:PYTHONPATH = (Resolve-Path '.\backend').Path
Write-Host '[3/6] Initializing local admin account if no auth database exists...' -ForegroundColor Cyan
if (!(Test-Path '.\backend\artifacts\auth.sqlite3')) {
  & $python '.\backend\bootstrap_admin.py' --username admin
  if ($LASTEXITCODE -ne 0) { throw 'Admin bootstrap failed' }
} else { Write-Host 'Preserving existing auth database; admin bootstrap skipped.' }
Write-Host '[4/6] Running backend regression tests...' -ForegroundColor Cyan
& $python -m pytest '.\backend\tests' -q
if ($LASTEXITCODE -ne 0) { throw 'Backend tests failed; do not call integration complete' }
Write-Host '[5/6] Writing evidence/audit manifest...' -ForegroundColor Cyan
& $python '.\backend\final_audit.py' --output '.\backend\artifacts\final_audit.json'
if ($LASTEXITCODE -ne 0) { throw 'Final audit failed' }
if (!$SkipNpm) {
  Write-Host '[6/6] Building frontend...' -ForegroundColor Cyan
  Push-Location '.\frontend'
  try {
    & npm ci
    if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
    & npm run build
    if ($LASTEXITCODE -ne 0) { throw 'Vite build failed' }
  } finally { Pop-Location }
} else { Write-Host 'Frontend installation skipped by request; run npm ci and npm run build manually.' }
Write-Host 'Setup checks completed. Open two terminals and run START_BACKEND.ps1 + START_FRONTEND.ps1.' -ForegroundColor Green
Write-Host 'Synapt.AI ingestion and real external evaluator credentials are intentionally NOT assumed.'
