# Synapt Sentinel V3.3 — Review Effectiveness

This package analyzes the existing V3.2 `evaluation.json` without retraining or changing the production model/API.

## Windows PowerShell

From `C:\Users\mohammed.marzook\Downloads\synapt-sentinel` with `backend\.venv` activated:

```powershell
Expand-Archive -LiteralPath .\synapt-sentinel-model-v33-review-effectiveness.zip -DestinationPath . -Force
$env:PYTHONPATH = (Resolve-Path .\backend).Path
python -m pytest .\backend\tests\test_model_v33_review_effectiveness.py -q
python .\backend\model_v33_review_effectiveness.py
```

Input: `backend\artifacts\model_v32_escalation\evaluation.json`
Output: `backend\artifacts\model_v33_review_effectiveness\evaluation.json`

## Inspect results

```powershell
$r = Get-Content .\backend\artifacts\model_v33_review_effectiveness\evaluation.json -Raw | ConvertFrom-Json
$r.aggregate | Format-Table budget, method, reviewed, attacks_surfaced, benign_reviews, review_precision, attacks_per_100_benign_reviews -AutoSize
$r.by_capture | Where-Object { $_.budget -eq 0.05 } | Format-Table capture, method, attacks_surfaced, benign_reviews, review_precision -AutoSize
```

**Interpretation:** attacks_surfaced counts labelled attacks *selected for hypothetical review*, not confirmed analyst detections. Review precision is retrospective and sensitive to sampled attack prevalence. The evaluation set has already informed model iteration, so these are exploratory findings rather than independent evidence of deployment performance. Do not select the best method on these captures and then claim its performance as independent validation.
